#pragma once

#include <cstdint>
#include <map>
#include <stdexcept>
#include <string>
#include <utility>
#include <variant>
#include <vector>

namespace xnv {

// A parsed XNV value. Objects deliberately use a map so callers can access
// values with data.asObject().at("server").asObject().at("port").
struct Value {
    using Array = std::vector<Value>;
    using Object = std::map<std::string, Value>;
    using Storage = std::variant<std::nullptr_t, bool, std::int64_t, double,
                                 std::string, Array, Object>;

    Storage data;

    Value() : data(nullptr) {}
    Value(std::nullptr_t) : data(nullptr) {}
    Value(bool value) : data(value) {}
    Value(std::int64_t value) : data(value) {}
    Value(double value) : data(value) {}
    Value(std::string value) : data(std::move(value)) {}
    Value(const char* value) : data(std::string(value)) {}
    Value(Array value) : data(std::move(value)) {}
    Value(Object value) : data(std::move(value)) {}

    bool isObject() const;
    bool isArray() const;
    const Object& asObject() const;
    Object& asObject();
    const Array& asArray() const;
    Array& asArray();
};

class ParseError : public std::runtime_error {
public:
    ParseError(std::string filename, std::size_t line, std::size_t column,
               std::string kind, std::string message);

    const std::string& filename() const noexcept { return filename_; }
    std::size_t line() const noexcept { return line_; }
    std::size_t column() const noexcept { return column_; }
    const std::string& kind() const noexcept { return kind_; }

private:
    static std::string makeWhat(const std::string& filename, std::size_t line,
                                std::size_t column, const std::string& kind,
                                const std::string& message);
    std::string filename_;
    std::size_t line_;
    std::size_t column_;
    std::string kind_;
};

// filename is optional, but is included in every ParseError when supplied.
Value parseXNV(const std::string& source, const std::string& filename = "<string>");
Value parseXNVFile(const std::string& path);

// XNV documents always have an object at the top level.
std::string stringifyXNV(const Value& value);

} // namespace xnv
