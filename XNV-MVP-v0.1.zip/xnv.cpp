#include "xnv.hpp"

#include <cctype>
#include <fstream>
#include <iomanip>
#include <limits>
#include <sstream>
#include <utility>

namespace xnv {

bool Value::isObject() const { return std::holds_alternative<Object>(data); }
bool Value::isArray() const { return std::holds_alternative<Array>(data); }
const Value::Object& Value::asObject() const { return std::get<Object>(data); }
Value::Object& Value::asObject() { return std::get<Object>(data); }
const Value::Array& Value::asArray() const { return std::get<Array>(data); }
Value::Array& Value::asArray() { return std::get<Array>(data); }

std::string ParseError::makeWhat(const std::string& filename, std::size_t line,
                                 std::size_t column, const std::string& kind,
                                 const std::string& message) {
    std::ostringstream out;
    out << "XNV Parse Error\nFile: " << filename << "\nLine: " << line
        << "\nColumn: " << column << "\nError: " << kind
        << "\nMessage: " << message;
    return out.str();
}

ParseError::ParseError(std::string filename, std::size_t line, std::size_t column,
                       std::string kind, std::string message)
    : std::runtime_error(makeWhat(filename, line, column, kind, message)),
      filename_(std::move(filename)), line_(line), column_(column), kind_(std::move(kind)) {}

namespace {

enum class TokenType {
    Identifier, String, Integer, Float,
    Equal, Colon, LBracket, RBracket, LBrace, RBrace, Comma,
    Newline, Indent, Dedent, End
};

struct Token {
    TokenType type;
    std::string text;
    std::size_t line;
    std::size_t column;
};

class Lexer {
public:
    Lexer(const std::string& source, std::string filename)
        : source_(source), filename_(std::move(filename)) {}

    std::vector<Token> tokenize() {
        while (pos_ < source_.size()) {
            if (atLineStart_) {
                lexLineStart();
                if (pos_ >= source_.size()) break;
                if (atLineStart_) continue; // blank or comment-only line
            }

            const char ch = source_[pos_];
            if (ch == ' ' || ch == '\t') {
                advance();
            } else if (ch == '\r' || ch == '\n') {
                emitNewline();
            } else if (ch == '/' && peek() == '/') {
                while (pos_ < source_.size() && source_[pos_] != '\r' && source_[pos_] != '\n') advance();
            } else if (ch == '"') {
                lexString();
            } else if (isKeyStart(ch)) {
                lexIdentifier();
            } else if (std::isdigit(static_cast<unsigned char>(ch)) ||
                       (ch == '-' && std::isdigit(static_cast<unsigned char>(peek())))) {
                lexNumber();
            } else {
                const std::size_t tokenLine = line_, tokenColumn = column_;
                TokenType type;
                switch (ch) {
                    case '=': type = TokenType::Equal; break;
                    case ':': type = TokenType::Colon; break;
                    case '[': type = TokenType::LBracket; ++arrayDepth_; break;
                    case ']':
                        if (arrayDepth_ == 0) error("Syntax Error", "Unexpected ']'");
                        type = TokenType::RBracket; --arrayDepth_; break;
                    case '{': type = TokenType::LBrace; break;
                    case '}': type = TokenType::RBrace; break;
                    case ',': type = TokenType::Comma; break;
                    default: error("Invalid Character", std::string("Unexpected character '") + ch + "'");
                }
                tokens_.push_back({type, std::string(1, ch), tokenLine, tokenColumn});
                advance();
            }
        }
        if (arrayDepth_ != 0) error("Syntax Error", "Unclosed array");
        while (indents_.size() > 1) {
            tokens_.push_back({TokenType::Dedent, "", line_, column_});
            indents_.pop_back();
        }
        tokens_.push_back({TokenType::End, "", line_, column_});
        return tokens_;
    }

private:
    const std::string& source_;
    std::string filename_;
    std::vector<Token> tokens_;
    std::vector<std::size_t> indents_{0};
    std::size_t pos_ = 0, line_ = 1, column_ = 1;
    std::size_t arrayDepth_ = 0;
    bool atLineStart_ = true;

    char peek() const { return pos_ + 1 < source_.size() ? source_[pos_ + 1] : '\0'; }
    static bool isKeyStart(char ch) { return std::isalpha(static_cast<unsigned char>(ch)) || ch == '_'; }
    static bool isKeyPart(char ch) {
        return std::isalnum(static_cast<unsigned char>(ch)) || ch == '_' || ch == '-';
    }

    [[noreturn]] void error(const std::string& kind, const std::string& message) const {
        throw ParseError(filename_, line_, column_, kind, message);
    }

    void advance() { ++pos_; ++column_; }

    void emitNewline() {
        const std::size_t oldLine = line_, oldColumn = column_;
        if (source_[pos_] == '\r') {
            ++pos_;
            if (pos_ < source_.size() && source_[pos_] == '\n') ++pos_;
        } else {
            ++pos_;
        }
        ++line_;
        column_ = 1;
        atLineStart_ = true;
        tokens_.push_back({TokenType::Newline, "", oldLine, oldColumn});
    }

    void lexLineStart() {
        const std::size_t startColumn = column_;
        std::size_t spaces = 0;
        bool hasTabs = false;
        while (pos_ < source_.size() && (source_[pos_] == ' ' || source_[pos_] == '\t')) {
            if (source_[pos_] == '\t') hasTabs = true;
            else ++spaces;
            advance();
        }
        if (pos_ >= source_.size()) return;
        if (source_[pos_] == '\r' || source_[pos_] == '\n') { emitNewline(); return; }
        if (source_[pos_] == '/' && peek() == '/') {
            while (pos_ < source_.size() && source_[pos_] != '\r' && source_[pos_] != '\n') advance();
            if (pos_ < source_.size()) emitNewline();
            return;
        }
        if (hasTabs) {
            throw ParseError(filename_, line_, startColumn, "Invalid Indentation",
                             "Tabs are not allowed for indentation");
        }
        atLineStart_ = false;
        // Indentation is meaningful only for document objects. Array contents use
        // brackets/braces and may be freely indented for readability.
        if (arrayDepth_ != 0) return;
        const std::size_t current = indents_.back();
        if (spaces > current) {
            indents_.push_back(spaces);
            tokens_.push_back({TokenType::Indent, "", line_, 1});
        } else if (spaces < current) {
            while (indents_.size() > 1 && spaces < indents_.back()) {
                indents_.pop_back();
                tokens_.push_back({TokenType::Dedent, "", line_, 1});
            }
            if (spaces != indents_.back()) {
                throw ParseError(filename_, line_, startColumn, "Invalid Indentation",
                                 "Indentation does not match any enclosing object");
            }
        }
    }

    void lexIdentifier() {
        const std::size_t start = pos_, tokenLine = line_, tokenColumn = column_;
        while (pos_ < source_.size() && isKeyPart(source_[pos_])) advance();
        const std::string text = source_.substr(start, pos_ - start);
        // Keep reserved words as identifiers. Their meaning is decided by the
        // parser only in a value position, so `true = "a valid key"` remains valid.
        tokens_.push_back({TokenType::Identifier, text, tokenLine, tokenColumn});
    }

    void lexNumber() {
        const std::size_t start = pos_, tokenLine = line_, tokenColumn = column_;
        if (source_[pos_] == '-') advance();
        while (pos_ < source_.size() && std::isdigit(static_cast<unsigned char>(source_[pos_]))) advance();
        TokenType type = TokenType::Integer;
        if (pos_ < source_.size() && source_[pos_] == '.') {
            type = TokenType::Float;
            advance();
            if (pos_ >= source_.size() || !std::isdigit(static_cast<unsigned char>(source_[pos_]))) {
                error("Invalid Number", "A decimal point must be followed by digits");
            }
            while (pos_ < source_.size() && std::isdigit(static_cast<unsigned char>(source_[pos_]))) advance();
        }
        tokens_.push_back({type, source_.substr(start, pos_ - start), tokenLine, tokenColumn});
    }

    void lexString() {
        const std::size_t tokenLine = line_, tokenColumn = column_;
        advance(); // opening quote
        std::string value;
        while (pos_ < source_.size() && source_[pos_] != '"') {
            const char ch = source_[pos_];
            if (ch == '\r' || ch == '\n') error("Unterminated String", "Strings cannot span lines");
            if (ch != '\\') { value += ch; advance(); continue; }
            advance();
            if (pos_ >= source_.size()) error("Unterminated String", "String ends after an escape character");
            const char escaped = source_[pos_];
            switch (escaped) {
                case '"': value += '"'; break;
                case '\\': value += '\\'; break;
                case 'n': value += '\n'; break;
                case 't': value += '\t'; break;
                case 'r': value += '\r'; break;
                default: error("Invalid Escape", std::string("Unsupported escape sequence \\") + escaped + "'");
            }
            advance();
        }
        if (pos_ >= source_.size()) error("Unterminated String", "Expected closing quote");
        advance(); // closing quote
        tokens_.push_back({TokenType::String, std::move(value), tokenLine, tokenColumn});
    }
};

class Parser {
public:
    Parser(std::vector<Token> tokens, std::string filename)
        : tokens_(std::move(tokens)), filename_(std::move(filename)) {}

    Value parseDocument() {
        Value::Object root = parseObjectBody(TokenType::End);
        expect(TokenType::End, "Expected end of document");
        return root;
    }

private:
    std::vector<Token> tokens_;
    std::string filename_;
    std::size_t current_ = 0;

    const Token& current() const { return tokens_[current_]; }
    const Token& previous() const { return tokens_[current_ - 1]; }
    bool at(TokenType type) const { return current().type == type; }
    bool match(TokenType type) { if (!at(type)) return false; ++current_; return true; }
    [[noreturn]] void errorHere(const std::string& kind, const std::string& message) const {
        throw ParseError(filename_, current().line, current().column, kind, message);
    }
    [[noreturn]] void errorAt(const Token& token, const std::string& kind, const std::string& message) const {
        throw ParseError(filename_, token.line, token.column, kind, message);
    }
    void expect(TokenType type, const std::string& message) {
        if (!match(type)) errorHere("Syntax Error", message);
    }
    void skipNewlines() { while (match(TokenType::Newline)) {} }

    Value::Object parseObjectBody(TokenType closing) {
        Value::Object object;
        skipNewlines();
        while (!at(closing)) {
            if (at(TokenType::End)) errorHere("Syntax Error", "Unexpected end of document");
            if (at(TokenType::Dedent)) {
                if (closing == TokenType::Dedent) break;
                errorHere("Invalid Indentation", "Unexpected dedent");
            }
            if (!at(TokenType::Identifier)) {
                errorHere("Invalid Key", "Expected a key beginning with a letter or underscore");
            }
            const Token key = current();
            ++current_;
            Value value;
            if (match(TokenType::Equal)) {
                value = parseValue();
                consumeStatementEnd(closing);
            } else if (match(TokenType::Colon)) {
                if (!match(TokenType::Newline)) errorHere("Syntax Error", "Expected a newline after ':'");
                skipNewlines();
                expect(TokenType::Indent, "Expected an indented object after ':'");
                value = parseObjectBody(TokenType::Dedent);
                expect(TokenType::Dedent, "Expected end of indented object");
                skipNewlines();
            } else {
                errorAt(current(), "Syntax Error", "Expected '=' or ':' after key");
            }
            if (object.find(key.text) != object.end()) {
                errorAt(key, "Duplicate Key", "Key '" + key.text + "' already exists in this object");
            }
            object.emplace(key.text, std::move(value));
        }
        return object;
    }

    void consumeStatementEnd(TokenType closing) {
        if (match(TokenType::Newline)) { skipNewlines(); return; }
        if (at(closing) || at(TokenType::Dedent) || at(TokenType::End)) return;
        errorHere("Syntax Error", "Expected end of line after value");
    }

    Value parseValue() {
        const Token token = current();
        if (match(TokenType::String)) return token.text;
        if (at(TokenType::Identifier) && token.text == "true") { ++current_; return true; }
        if (at(TokenType::Identifier) && token.text == "false") { ++current_; return false; }
        if (at(TokenType::Identifier) && token.text == "null") { ++current_; return nullptr; }
        if (match(TokenType::Integer)) {
            try { return static_cast<std::int64_t>(std::stoll(token.text)); }
            catch (...) { errorAt(token, "Invalid Number", "Integer is out of range"); }
        }
        if (match(TokenType::Float)) {
            try { return std::stod(token.text); }
            catch (...) { errorAt(token, "Invalid Number", "Float is out of range"); }
        }
        if (match(TokenType::LBracket)) return parseArray();
        if (match(TokenType::LBrace)) return parseBracedObject();
        if (at(TokenType::Identifier)) errorHere("Invalid Value", "Bare identifiers are not values; strings must use double quotes");
        errorHere("Invalid Value", "Expected a string, number, boolean, null, array, or object");
    }

    Value parseArray() {
        Value::Array array;
        skipNewlines();
        if (match(TokenType::RBracket)) return array;
        while (true) {
            array.push_back(parseValue());
            if (match(TokenType::Comma)) {
                skipNewlines();
                if (at(TokenType::RBracket)) errorHere("Syntax Error", "Trailing commas are not allowed");
                continue;
            }
            if (match(TokenType::Newline)) {
                skipNewlines();
                if (match(TokenType::RBracket)) return array;
                // Newlines separate elements in multiline arrays, as in object arrays.
                continue;
            }
            if (match(TokenType::RBracket)) return array;
            errorHere("Syntax Error", "Expected ',', newline, or ']' after array value");
        }
    }

    Value parseBracedObject() {
        Value::Object object = parseObjectBody(TokenType::RBrace);
        expect(TokenType::RBrace, "Expected '}' to close object");
        return object;
    }
};

std::string escapeString(const std::string& input) {
    std::string output;
    for (char ch : input) {
        switch (ch) {
            case '"': output += "\\\""; break;
            case '\\': output += "\\\\"; break;
            case '\n': output += "\\n"; break;
            case '\t': output += "\\t"; break;
            case '\r': output += "\\r"; break;
            default: output += ch; break;
        }
    }
    return output;
}

bool isScalar(const Value& value) { return !value.isArray() && !value.isObject(); }

std::string renderValue(const Value& value, int indent);

std::string renderObjectEntries(const Value::Object& object, int indent) {
    std::ostringstream out;
    const std::string padding(static_cast<std::size_t>(indent), ' ');
    for (const auto& entry : object) {
        if (entry.second.isObject()) {
            const auto& nested = entry.second.asObject();
            if (nested.empty()) out << padding << entry.first << " = {}\n";
            else out << padding << entry.first << ":\n" << renderObjectEntries(nested, indent + 2);
        } else {
            out << padding << entry.first << " = " << renderValue(entry.second, indent) << "\n";
        }
    }
    return out.str();
}

std::string renderValue(const Value& value, int indent) {
    if (std::holds_alternative<std::nullptr_t>(value.data)) return "null";
    if (const auto* boolean = std::get_if<bool>(&value.data)) return *boolean ? "true" : "false";
    if (const auto* integer = std::get_if<std::int64_t>(&value.data)) return std::to_string(*integer);
    if (const auto* floating = std::get_if<double>(&value.data)) {
        std::ostringstream out;
        out << std::setprecision(std::numeric_limits<double>::max_digits10) << *floating;
        return out.str();
    }
    if (const auto* string = std::get_if<std::string>(&value.data)) return "\"" + escapeString(*string) + "\"";
    if (const auto* object = std::get_if<Value::Object>(&value.data)) {
        if (object->empty()) return "{}";
        std::ostringstream out;
        out << "{\n" << renderObjectEntries(*object, indent + 2)
            << std::string(static_cast<std::size_t>(indent), ' ') << '}';
        return out.str();
    }
    const auto& array = std::get<Value::Array>(value.data);
    if (array.empty()) return "[]";
    bool allScalars = true;
    for (const Value& element : array) allScalars = allScalars && isScalar(element);
    if (allScalars) {
        std::ostringstream out;
        out << '[';
        for (std::size_t i = 0; i < array.size(); ++i) {
            if (i) out << ", ";
            out << renderValue(array[i], indent);
        }
        out << ']';
        return out.str();
    }
    std::ostringstream out;
    out << "[\n";
    for (const Value& element : array) {
        out << std::string(static_cast<std::size_t>(indent + 2), ' ')
            << renderValue(element, indent + 2) << "\n";
    }
    out << std::string(static_cast<std::size_t>(indent), ' ') << ']';
    return out.str();
}

} // namespace

Value parseXNV(const std::string& source, const std::string& filename) {
    Lexer lexer(source, filename);
    Parser parser(lexer.tokenize(), filename);
    return parser.parseDocument();
}

Value parseXNVFile(const std::string& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) throw std::runtime_error("Could not open XNV file: " + path);
    std::ostringstream buffer;
    buffer << input.rdbuf();
    std::string source = buffer.str();
    // UTF-8 BOM is accepted at the start of a UTF-8 file.
    if (source.size() >= 3 && static_cast<unsigned char>(source[0]) == 0xEF &&
        static_cast<unsigned char>(source[1]) == 0xBB && static_cast<unsigned char>(source[2]) == 0xBF) {
        source.erase(0, 3);
    }
    return parseXNV(source, path);
}

std::string stringifyXNV(const Value& value) {
    if (!value.isObject()) throw std::invalid_argument("XNV documents must have an object at the top level");
    return renderObjectEntries(value.asObject(), 0);
}

} // namespace xnv
