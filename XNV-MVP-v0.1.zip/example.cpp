#include "xnv.hpp"

#include <iostream>

int main() {
    const xnv::Value config = xnv::parseXNV(R"(
// XNV configuration
app:
  name = "MyApp"
  version = 1.0
  enabled = true

server:
  host = "localhost"
  port = 8080

features = ["logging", "cache", "network"]
)", "example.xnv");

    const auto& root = config.asObject();
    std::cout << std::get<std::string>(root.at("app").asObject().at("name").data) << '\n';
    std::cout << std::get<std::int64_t>(root.at("server").asObject().at("port").data) << '\n';
    std::cout << xnv::stringifyXNV(config);
}
