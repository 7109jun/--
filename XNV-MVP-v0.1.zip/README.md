# XNV MVP v0.1 (C++)

XNV is a small UTF-8 configuration format: typed like JSON, indented like YAML,
and simple like an `.env` file. This implementation is deliberately limited to
the MVP specification.

## Files

- `xnv.hpp` — public value tree, error type, and API
- `xnv.cpp` — lexer, parser, serializer, and file reader
- `example.cpp` — a small usage example
- `tests.cpp` — normal-input and error-input coverage

## API

```cpp
#include "xnv.hpp"

xnv::Value config = xnv::parseXNV(source, "config.xnv");
xnv::Value fromFile = xnv::parseXNVFile("config.xnv");
std::string text = xnv::stringifyXNV(config);

const auto& root = config.asObject();
auto port = std::get<std::int64_t>(root.at("server").asObject().at("port").data);
```

`Value::data` contains exactly one of `nullptr`, `bool`, `std::int64_t`,
`double`, `std::string`, `Value::Array`, or `Value::Object`.

## Supported syntax

```xnv
// Comments start with // outside strings.
app:
  name = "MyApp"
  version = 1.0
  enabled = true

server:
  host = "localhost"
  port = 8080

features = ["logging", "cache", "network"]
users = [
  {
    name = "Alice"
    age = 20
  }
  {
    name = "Bob"
    age = 21
  }
]
```

- Values: string, integer, float, `true`, `false`, `null`, array, object.
- Keys begin with a letter or `_`; remaining characters may be letters, digits,
  `_`, or `-`.
- Indentation builds document objects. Any consistent number of spaces works;
  two spaces are recommended. Tabs in indentation are rejected.
- Array values use commas on a line or line breaks in multiline arrays. Braced
  objects may be used inside arrays.
- LF and CRLF files work. `parseXNVFile` also accepts a leading UTF-8 BOM.
- Escapes in strings: `\"`, `\\`, `\n`, `\t`, `\r`.

## Errors

`ParseError` provides filename, line, column, kind, and a message. Its `what()`
text is already formatted for display.

## Intentional MVP limits

- No variable references, environment-variable substitution, imports,
  expressions, functions, schemas, custom types, dates, binary data,
  encryption, or compression.
- Strings must use double quotes; bare words other than `true`, `false`, and
  `null` are errors.
- Number syntax is decimal integer or decimal float only (no exponent syntax).
- Indented objects are the normal object notation. `{ ... }` is provided for
  objects in arrays and for serializing an empty object; nested objects there
  should use braces as well.
