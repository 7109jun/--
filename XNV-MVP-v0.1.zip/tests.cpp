#include "xnv.hpp"

#include <cassert>
#include <functional>
#include <iostream>
#include <string>

namespace {

const xnv::Value& field(const xnv::Value& object, const std::string& key) {
    return object.asObject().at(key);
}

void expectParseError(const std::string& source, const std::string& kind) {
    try {
        (void)xnv::parseXNV(source, "invalid.xnv");
        assert(false && "Expected ParseError");
    } catch (const xnv::ParseError& error) {
        assert(error.kind() == kind);
        assert(error.line() >= 1);
        assert(error.column() >= 1);
        assert(error.filename() == "invalid.xnv");
    }
}

void testValuesAndWhitespace() {
    const auto doc = xnv::parseXNV(R"(

name = "XNV"
integer=8080
float = 3.14
enabled = true
disabled = false
empty = null
)");
    assert(std::get<std::string>(field(doc, "name").data) == "XNV");
    assert(std::get<std::int64_t>(field(doc, "integer").data) == 8080);
    assert(std::get<double>(field(doc, "float").data) == 3.14);
    assert(std::get<bool>(field(doc, "enabled").data));
    assert(!std::get<bool>(field(doc, "disabled").data));
    assert(std::holds_alternative<std::nullptr_t>(field(doc, "empty").data));
}

void testObjectsArraysAndComments() {
    const auto doc = xnv::parseXNV(R"(
// A comment
server:
  host = "localhost" // this is a comment
  network:
    port = 8080
message = "Hello // World"
items = [1, 2, 3]
nested = [[1, 2], [3, 4]]
users = [
  {
    name = "Alice"
    age = 20
  }
  {
    name = "Bob"
    age = 21
  }
]
)");
    assert(std::get<std::int64_t>(field(field(doc, "server"), "network").asObject().at("port").data) == 8080);
    assert(std::get<std::string>(field(doc, "message").data) == "Hello // World");
    assert(field(doc, "nested").asArray()[1].asArray()[0].data == xnv::Value(std::int64_t(3)).data);
    assert(field(doc, "users").asArray().size() == 2);
    assert(std::get<std::string>(field(doc, "users").asArray()[1].asObject().at("name").data) == "Bob");
}

void testEscapesAndLineEndings() {
    const auto escaped = xnv::parseXNV("value = \"a\\\\b\\\"c\\n\\t\\r\"\n");
    assert(std::get<std::string>(field(escaped, "value").data) == "a\\b\"c\n\t\r");
    const auto crlf = xnv::parseXNV("name = \"CRLF\"\r\nport = 80\r\n");
    assert(std::get<std::string>(field(crlf, "name").data) == "CRLF");
}

void testErrors() {
    expectParseError("name = \"one\"\nname = \"two\"\n", "Duplicate Key");
    expectParseError("name \"missing equals\"\n", "Syntax Error");
    expectParseError("123name = \"bad\"\n", "Invalid Key");
    expectParseError("root:\n  child = 1\n bad = 2\n", "Invalid Indentation");
    expectParseError("name = \"bad\\q\"\n", "Invalid Escape");
    expectParseError("value = True\n", "Invalid Value");
    expectParseError("items = [1, 2,]\n", "Syntax Error");
}

void testRoundTrip() {
    const auto original = xnv::parseXNV("app:\n  name = \"XNV\"\nports = [80, 443]\n");
    const auto reparsed = xnv::parseXNV(xnv::stringifyXNV(original));
    assert(std::get<std::string>(field(field(reparsed, "app"), "name").data) == "XNV");
    assert(field(reparsed, "ports").asArray().size() == 2);
}

} // namespace

int main() {
    testValuesAndWhitespace();
    testObjectsArraysAndComments();
    testEscapesAndLineEndings();
    testErrors();
    testRoundTrip();
    std::cout << "All XNV tests passed.\n";
}
