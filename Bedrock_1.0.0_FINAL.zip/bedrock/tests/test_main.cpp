#include "bedrock/compiler/compiler.hpp"
#include "bedrock/compiler/lexer.hpp"
#include "bedrock/compiler/parser.hpp"
#include "bedrock/jit/x64_jit.hpp"
#include <cassert>
#include <iostream>
static bedrock::compiler::Program parse(const char*s){bedrock::compiler::Lexer l(s);bedrock::compiler::Parser p(l.scan());return p.parse();}
int main(){
 auto p=parse("import http; fn add(a:Int,b:Int)->Int { return a+b; } server S { listen 18080; route GET \"/\" { return \"ok\"; } }");
 auto cp=bedrock::compiler::Compiler().compile(std::move(p));assert(cp.program.servers.size()==1);assert(cp.modules.contains("http"));bedrock::jit::X64Jit j;auto fn=j.compile(cp.program.functions[0]);assert(fn(2,3,0,0)==5);std::cout<<"ALL TESTS PASSED\n";
}
