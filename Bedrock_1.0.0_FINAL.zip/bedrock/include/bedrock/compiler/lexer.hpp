#pragma once
#include "token.hpp"
#include <string>
#include <vector>
#include <stdexcept>

namespace bedrock::compiler {
struct LexError : std::runtime_error { using std::runtime_error::runtime_error; };
class Lexer {
  std::string src_; std::size_t p_=0; SourcePos pos_{};
public:
  explicit Lexer(std::string source):src_(std::move(source)){}
  std::vector<Token> scan();
private:
  char peek(std::size_t n=0) const; char get(); void ws(); Token ident(); Token number(); Token string();
};
}
