#pragma once
#include "ast.hpp"
#include "token.hpp"
#include <stdexcept>
#include <vector>

namespace bedrock::compiler {
struct ParseError:std::runtime_error{using std::runtime_error::runtime_error;};
class Parser{
 std::vector<Token> t_; std::size_t p_=0;
public:
 explicit Parser(std::vector<Token> t):t_(std::move(t)){}
 Program parse();
private:
 bool is(TokenKind)const; bool match(TokenKind); const Token& expect(TokenKind,const char*); [[noreturn]] void fail(const std::string&)const;
 Function parse_fn(); Server parse_server(); Route parse_route(); ExprPtr expression(); ExprPtr term(); ExprPtr factor();
};
}
