#pragma once
#include <string>
#include <cstddef>

namespace bedrock::compiler {

enum class TokenKind {
  End, Identifier, Number, String,
  LParen, RParen, LBrace, RBrace, LBracket, RBracket,
  Colon, Comma, Dot, Arrow,
  Plus, Minus, Star, Slash, Equal, Semicolon,
  KwImport, KwFn, KwReturn, KwServer, KwRoute, KwListen,
  KwStatus, KwType, KwLet, KwAsync,
  KwGET, KwPOST, KwPUT, KwDELETE, KwPATCH, KwHEAD, KwOPTIONS
};

struct SourcePos { std::size_t line=1, column=1, offset=0; };
struct Token { TokenKind kind; std::string text; SourcePos pos; };

const char* token_name(TokenKind k);

}
