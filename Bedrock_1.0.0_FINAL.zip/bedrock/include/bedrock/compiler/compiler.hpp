#pragma once
#include "ast.hpp"
#include <string>
#include <unordered_map>
#include <vector>

namespace bedrock::compiler {
struct CompileError:std::runtime_error{using std::runtime_error::runtime_error;};
struct CompiledProgram { Program program; std::unordered_map<std::string,std::string> modules; };
class Compiler {
public:
 CompiledProgram compile(Program program) const;
};
}
