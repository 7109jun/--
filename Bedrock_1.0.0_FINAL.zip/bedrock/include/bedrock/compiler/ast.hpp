#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace bedrock::compiler {
struct Expr { virtual ~Expr() = default; };
using ExprPtr = std::unique_ptr<Expr>;
struct IntExpr : Expr { int64_t value; explicit IntExpr(int64_t v): value(v) {} };
struct StringExpr : Expr { std::string value; explicit StringExpr(std::string v): value(std::move(v)) {} };
struct VarExpr : Expr { std::string name; explicit VarExpr(std::string n): name(std::move(n)) {} };
struct BinaryExpr : Expr { char op; ExprPtr lhs, rhs; BinaryExpr(char o, ExprPtr a, ExprPtr b): op(o), lhs(std::move(a)), rhs(std::move(b)) {} };

struct Route {
    std::string method;
    std::string path;
    std::string response_body;
    int status = 200;
    std::string content_type = "text/plain; charset=utf-8";
    std::vector<std::pair<std::string,std::string>> headers;
};
struct Function { std::string name; std::vector<std::string> params; ExprPtr body; };
struct Server {
    std::string name;
    int port = 8080;
    int threads = 0;
    std::vector<Route> routes;
};
struct Program { std::vector<std::string> imports; std::vector<Function> functions; std::vector<Server> servers; };
}
