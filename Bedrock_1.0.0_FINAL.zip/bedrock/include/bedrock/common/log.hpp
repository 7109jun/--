#pragma once
#include <mutex>
#include <string_view>
namespace bedrock::log {
enum class Level{Info,Warn,Error,Debug};
void write(Level,std::string_view);
}
