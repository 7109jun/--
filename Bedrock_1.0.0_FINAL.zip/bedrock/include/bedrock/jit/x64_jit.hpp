#pragma once
#include "bedrock/compiler/ast.hpp"
#include <cstdint>
#include <cstddef>
#include <memory>
#include <vector>

namespace bedrock::jit {
class X64Jit {
public:
 using Fn = int64_t(*)(int64_t,int64_t,int64_t,int64_t);
 X64Jit(); ~X64Jit(); X64Jit(const X64Jit&)=delete; X64Jit& operator=(const X64Jit&)=delete;
 Fn compile(const compiler::Function& fn);
private:
 struct Block{void* mem=nullptr;std::size_t size=0;}; std::vector<Block> blocks_;
};
}
