#pragma once
#include <atomic>
#include <condition_variable>
#include <cstddef>
#include <functional>
#include <mutex>
#include <queue>
#include <thread>
#include <vector>

namespace bedrock::runtime {
class ThreadPool {
 std::vector<std::thread> workers_; std::queue<std::function<void()>> jobs_; std::mutex m_; std::condition_variable cv_; std::atomic<bool> stop_{false};
 void worker();
public:
 explicit ThreadPool(std::size_t n); ~ThreadPool(); ThreadPool(const ThreadPool&)=delete; ThreadPool& operator=(const ThreadPool&)=delete;
 void submit(std::function<void()> job);
 std::size_t size()const{return workers_.size();}
};
}
