#pragma once
#include <cstddef>
#include <string>
#include <vector>
namespace bedrock::runtime {
struct ModuleInfo { std::string name; std::size_t footprint; std::string description; };
class ModuleRegistry {
public:
    ModuleRegistry();
    const ModuleInfo* find(const std::string& name) const;
    std::vector<ModuleInfo> all() const;
    bool available(const std::string& name) const;
};
}
