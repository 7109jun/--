#pragma once
#include "bedrock/compiler/ast.hpp"
#include "thread_pool.hpp"
#include <atomic>
#include <cstddef>
#include <map>
#include <string>
#include <utility>
#include <vector>
namespace bedrock::runtime {
struct HttpRequest {
    std::string method, target, version, body;
    std::map<std::string,std::string,std::less<>> headers;
    std::map<std::string,std::string,std::less<>> query;
    std::map<std::string,std::string,std::less<>> params;
};
struct HttpResponse {
    int status = 200;
    std::string content_type = "text/plain; charset=utf-8";
    std::string body;
    std::vector<std::pair<std::string,std::string>> headers;
    std::string serialize() const;
};
class HttpServer {
    std::string name_;
    int port_;
    std::size_t threads_;
    std::vector<compiler::Route> routes_;
    std::atomic<bool> stopping_{false};
    std::atomic<std::uint64_t> requests_{0};
#ifdef _WIN32
    using Socket = std::uintptr_t;
#else
    using Socket = int;
#endif
    Socket listen_fd_{};
    ThreadPool pool_;
    std::size_t max_header_bytes_ = 128 * 1024;
    std::size_t max_body_bytes_ = 16 * 1024 * 1024;
    void accept_loop();
    void client(Socket s);
    bool parse_request(Socket s, HttpRequest& req) const;
    HttpResponse dispatch(HttpRequest& req) const;
public:
    HttpServer(std::string name, int port, std::size_t threads, std::vector<compiler::Route> routes);
    ~HttpServer();
    void run();
    void stop();
    std::uint64_t requests() const { return requests_.load(); }
};
std::string status_text(int code);
std::string lower_ascii(std::string s);
}
