#include "bedrock/jit/x64_jit.hpp"
#include "bedrock/compiler/compiler.hpp"
#include <cstring>
#include <stdexcept>
#include <unordered_map>
#ifdef _WIN32
#include <windows.h>
#else
#include <sys/mman.h>
#include <unistd.h>
#endif
namespace bedrock::jit {
static void* alloc_exec(std::size_t n){
#ifdef _WIN32
 return VirtualAlloc(nullptr,n,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
#else
 void*p=mmap(nullptr,n,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);return p==MAP_FAILED?nullptr:p;
#endif
}
static void make_exec(void*p,std::size_t n){
#ifdef _WIN32
 DWORD old{};VirtualProtect(p,n,PAGE_EXECUTE_READ,&old);FlushInstructionCache(GetCurrentProcess(),p,n);
#else
 mprotect(p,n,PROT_READ|PROT_EXEC);
 __builtin___clear_cache((char*)p,(char*)p+n);
#endif
}
static void release_exec(void*p,std::size_t n){
#ifdef _WIN32
 (void)n;VirtualFree(p,0,MEM_RELEASE);
#else
 munmap(p,n);
#endif
}
X64Jit::X64Jit()=default;X64Jit::~X64Jit(){for(auto&b:blocks_)release_exec(b.mem,b.size);}
struct Emitter {
    std::vector<unsigned char> c;
    void u8(unsigned char x){ c.push_back(x); }
    void u32(std::uint32_t x){ for(int i=0;i<4;i++) u8((unsigned char)((x>>(i*8))&255)); }
    void u64(std::uint64_t x){ for(int i=0;i<8;i++) u8((unsigned char)((x>>(i*8))&255)); }
    void rexw_mov_mem_rsp(int slot){
        // mov rax, [rbp - 8*slot]
        (void)slot;
    }
    void expr(const compiler::Expr* e, const std::unordered_map<std::string,int>& slots){
        using namespace compiler;
        if(auto n=dynamic_cast<const IntExpr*>(e)){
            u8(0x48); u8(0xB8); u64((std::uint64_t)n->value); return;
        }
        if(auto v=dynamic_cast<const VarExpr*>(e)){
            auto it=slots.find(v->name); if(it==slots.end()) throw std::runtime_error("unknown variable");
            int disp = -8 * (it->second + 1);
            // mov rax, [rbp+disp8] => 48 8B 45 xx
            u8(0x48); u8(0x8B); u8(0x45); u8((unsigned char)(std::int8_t)disp); return;
        }
        if(auto b=dynamic_cast<const BinaryExpr*>(e)){
            expr(b->lhs.get(),slots); u8(0x50); // push lhs
            expr(b->rhs.get(),slots); u8(0x5B); // pop lhs -> rbx
            switch(b->op){
                case '+': u8(0x48);u8(0x01);u8(0xD8); break; // add rax, rbx
                case '-': u8(0x48);u8(0x29);u8(0xC3); u8(0x48);u8(0x89);u8(0xD8); break; // rbx-=rax; rax=rbx
                case '*': u8(0x48);u8(0x0F);u8(0xAF);u8(0xC3); break; // imul rax, rbx
                case '/': u8(0x48);u8(0x93); u8(0x48);u8(0x99); u8(0x48);u8(0xF7);u8(0xFB); break; // xchg rax,rbx; cqo; idiv rbx
                default: throw std::runtime_error("unsupported JIT operator");
            }
            return;
        }
        throw std::runtime_error("unsupported JIT expression");
    }
};

X64Jit::Fn X64Jit::compile(const compiler::Function& fn){
    if(fn.params.size()>4) throw std::runtime_error("too many parameters");
    Emitter e;
    // Prologue: establish frame and reserve 32 bytes (4 x int64 locals).
    e.u8(0x55);                 // push rbp
    e.u8(0x48); e.u8(0x89); e.u8(0xE5); // mov rbp,rsp
    e.u8(0x48); e.u8(0x83); e.u8(0xEC); e.u8(0x20); // sub rsp,32
    e.u8(0x53);                 // save callee-saved rbx

#ifdef _WIN32
    // Windows x64: RCX,RDX,R8,R9
    const unsigned char stores[4][4] = {
        {0x48,0x89,0x4D,0xF8}, {0x48,0x89,0x55,0xF0},
        {0x4C,0x89,0x45,0xE8}, {0x4C,0x89,0x4D,0xE0}
    };
#else
    // System V AMD64: RDI,RSI,RDX,RCX
    const unsigned char stores[4][4] = {
        {0x48,0x89,0x7D,0xF8}, {0x48,0x89,0x75,0xF0},
        {0x48,0x89,0x55,0xE8}, {0x48,0x89,0x4D,0xE0}
    };
#endif
    std::unordered_map<std::string,int> slots;
    for(std::size_t i=0;i<fn.params.size();++i){
        slots[fn.params[i]]=(int)i;
        for(unsigned char b:stores[i]) e.u8(b);
    }
    e.expr(fn.body.get(),slots);
    e.u8(0x5B); // restore rbx
    e.u8(0x48); e.u8(0x83); e.u8(0xC4); e.u8(0x20); // add rsp,32
    e.u8(0x5D); // pop rbp
    e.u8(0xC3); // ret
    void* mem=alloc_exec(e.c.size());
    if(!mem) throw std::bad_alloc();
    std::memcpy(mem,e.c.data(),e.c.size()); make_exec(mem,e.c.size());
    blocks_.push_back({mem,e.c.size()});
    return reinterpret_cast<Fn>(mem);
}

}
