#include "bedrock/common/log.hpp"
#include <chrono>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <mutex>
namespace bedrock::log {
void write(Level l, std::string_view s) {
  static std::mutex m;
  std::lock_guard g(m);
  auto now = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
  std::tm tm{};
#ifdef _WIN32
  localtime_s(&tm, &now);
#else
  localtime_r(&now, &tm);
#endif
  const char* n = l==Level::Info ? "INFO" : l==Level::Warn ? "WARN" : l==Level::Error ? "ERROR" : "DEBUG";
  std::cerr << std::put_time(&tm, "[%Y-%m-%d %H:%M:%S]") << " [" << n << "] " << s << '\n';
}
}
