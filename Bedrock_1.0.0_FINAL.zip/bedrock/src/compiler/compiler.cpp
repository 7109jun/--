#include "bedrock/compiler/compiler.hpp"
#include "bedrock/runtime/module.hpp"
#include <algorithm>
#include <unordered_set>
namespace bedrock::compiler {
static void check_expr(const Expr* e,const std::unordered_set<std::string>& vars){if(auto v=dynamic_cast<const VarExpr*>(e)){if(!vars.contains(v->name))throw CompileError("unknown variable: "+v->name);}else if(auto b=dynamic_cast<const BinaryExpr*>(e)){check_expr(b->lhs.get(),vars);check_expr(b->rhs.get(),vars);}}
CompiledProgram Compiler::compile(Program p)const{runtime::ModuleRegistry reg;std::unordered_set<std::string>seen;for(auto&m:p.imports){if(!seen.insert(m).second)throw CompileError("duplicate import: "+m);if(!reg.find(m))throw CompileError("unknown module: "+m);}for(auto&f:p.functions){if(f.params.size()>4)throw CompileError("function "+f.name+" exceeds the current JIT arity limit (4)");std::unordered_set<std::string>vars;for(auto&a:f.params)if(!vars.insert(a).second)throw CompileError("duplicate parameter: "+a);check_expr(f.body.get(),vars);}for(auto&s:p.servers){if(std::find(p.imports.begin(),p.imports.end(),"http")==p.imports.end())throw CompileError("server declarations require: import http");if(s.port<1||s.port>65535)throw CompileError("invalid port in server "+s.name);for(auto&r:s.routes){if(r.path.empty()||r.path[0]!='/')throw CompileError("route path must start with '/'");if(r.status<100||r.status>599)throw CompileError("invalid HTTP status");}}CompiledProgram cp{std::move(p),{}};for(auto&m:cp.program.imports){auto*x=reg.find(m);cp.modules[m]=std::to_string(x->footprint);}return cp;}
}
