#include "bedrock/runtime/thread_pool.hpp"
#include <stdexcept>
namespace bedrock::runtime {
ThreadPool::ThreadPool(std::size_t n){if(n==0)n=1;workers_.reserve(n);for(std::size_t i=0;i<n;i++)workers_.emplace_back([this]{worker();});}
ThreadPool::~ThreadPool(){stop_=true;cv_.notify_all();for(auto& t:workers_)if(t.joinable())t.join();}
void ThreadPool::submit(std::function<void()> j){{std::lock_guard g(m_);if(stop_)throw std::runtime_error("thread pool stopped");jobs_.push(std::move(j));}cv_.notify_one();}
void ThreadPool::worker(){for(;;){std::function<void()> job;{std::unique_lock l(m_);cv_.wait(l,[this]{return stop_||!jobs_.empty();});if(stop_&&jobs_.empty())return;job=std::move(jobs_.front());jobs_.pop();}try{job();}catch(...){}}}
}
