#include "bedrock/runtime/module.hpp"
#include <algorithm>
namespace bedrock::runtime {
ModuleRegistry::ModuleRegistry() = default;
const ModuleInfo* ModuleRegistry::find(const std::string& name) const {
    static const std::vector<ModuleInfo> mods = {
        {"http",        96 * 1024,  "HTTP/1.1 server, request/response and routing"},
        {"websocket",   38 * 1024,  "WebSocket handshake/runtime primitives"},
        {"json",        22 * 1024,  "JSON serialization helpers"},
        {"crypto",      64 * 1024,  "Hashing and cryptographic primitives"},
        {"database",    72 * 1024,  "Database interfaces and connection-pool primitives"},
        {"filesystem",  18 * 1024,  "Filesystem and streaming I/O"},
        {"env",          4 * 1024,  "Environment/config access"},
        {"process",      8 * 1024,  "Process, signal and graceful-shutdown support"},
        {"compression", 24 * 1024,  "Compression interfaces"},
        {"metrics",     16 * 1024,  "Counters, gauges and request metrics"},
        {"logging",     12 * 1024,  "Structured logging"},
    };
    auto it = std::find_if(mods.begin(), mods.end(), [&](const auto& x){ return x.name == name; });
    return it == mods.end() ? nullptr : &*it;
}
std::vector<ModuleInfo> ModuleRegistry::all() const {
    static const std::vector<ModuleInfo> mods = {
        {"http",96*1024,"HTTP/1.1 server, request/response and routing"},
        {"websocket",38*1024,"WebSocket handshake/runtime primitives"},
        {"json",22*1024,"JSON serialization helpers"},
        {"crypto",64*1024,"Hashing and cryptographic primitives"},
        {"database",72*1024,"Database interfaces and connection-pool primitives"},
        {"filesystem",18*1024,"Filesystem and streaming I/O"},
        {"env",4*1024,"Environment/config access"},
        {"process",8*1024,"Process, signal and graceful-shutdown support"},
        {"compression",24*1024,"Compression interfaces"},
        {"metrics",16*1024,"Counters, gauges and request metrics"},
        {"logging",12*1024,"Structured logging"},
    };
    return mods;
}
bool ModuleRegistry::available(const std::string& name) const { return find(name) != nullptr; }
}
