#include "bedrock/runtime/http.hpp"
#include "bedrock/common/log.hpp"
#include <algorithm>
#include <cctype>
#include <cstring>
#include <functional>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string_view>
#ifdef _WIN32
#define NOMINMAX
#include <winsock2.h>
#include <ws2tcpip.h>
using NativeSocket = SOCKET; static constexpr NativeSocket INVALID_FD = INVALID_SOCKET;
#else
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>
using NativeSocket = int; static constexpr NativeSocket INVALID_FD = -1;
#endif
namespace bedrock::runtime {
std::string lower_ascii(std::string s){ for(char& c:s)c=(char)std::tolower((unsigned char)c); return s; }
std::string status_text(int c){switch(c){case 200:return "OK";case 201:return "Created";case 202:return "Accepted";case 204:return "No Content";case 400:return "Bad Request";case 401:return "Unauthorized";case 403:return "Forbidden";case 404:return "Not Found";case 405:return "Method Not Allowed";case 408:return "Request Timeout";case 413:return "Payload Too Large";case 415:return "Unsupported Media Type";case 422:return "Unprocessable Content";case 429:return "Too Many Requests";case 500:return "Internal Server Error";case 501:return "Not Implemented";case 502:return "Bad Gateway";case 503:return "Service Unavailable";default:return "Status";}}
std::string HttpResponse::serialize() const {
    std::ostringstream o;
    o << "HTTP/1.1 " << status << ' ' << status_text(status) << "\r\n";
    o << "Content-Type: " << content_type << "\r\n";
    o << "Content-Length: " << body.size() << "\r\n";
    o << "Connection: close\r\n";
    o << "Server: Bedrock/1.0.0\r\n";
    for (const auto& [k,v] : headers) o << k << ": " << v << "\r\n";
    o << "\r\n" << body;
    return o.str();
}
static void close_socket(NativeSocket s){ if(s==INVALID_FD)return;
#ifdef _WIN32
 closesocket(s);
#else
 close(s);
#endif
}
#ifdef _WIN32
static void init_net(){ static std::once_flag f; std::call_once(f,[]{ WSADATA w{}; if(WSAStartup(MAKEWORD(2,2),&w)!=0) throw std::runtime_error("WSAStartup failed"); }); }
#endif
static std::string url_decode(std::string_view in){ std::string out; out.reserve(in.size()); for(size_t i=0;i<in.size();++i){ char c=in[i]; if(c=='+'){out+=' ';} else if(c=='%' && i+2<in.size()){auto hex=[](char x)->int{if(x>='0'&&x<='9')return x-'0';if(x>='a'&&x<='f')return x-'a'+10;if(x>='A'&&x<='F')return x-'A'+10;return -1;};int a=hex(in[i+1]),b=hex(in[i+2]);if(a>=0&&b>=0){out+=(char)((a<<4)|b);i+=2;}else out+=c;}else out+=c;} return out; }
static void parse_query(const std::string& target,std::map<std::string,std::string,std::less<>>& q){ auto p=target.find('?'); if(p==std::string::npos)return; std::string_view s(target.data()+p+1,target.size()-p-1); while(!s.empty()){auto a=s.find('&');auto part=s.substr(0,a);auto eq=part.find('=');auto k=eq==std::string_view::npos?part:part.substr(0,eq);auto v=eq==std::string_view::npos?std::string_view{}:part.substr(eq+1);if(!k.empty())q[url_decode(k)]=url_decode(v);if(a==std::string_view::npos)break;s.remove_prefix(a+1);} }
static bool route_match(const compiler::Route& r, const std::string& path, std::map<std::string,std::string,std::less<>>& params){
    if(r.path==path)return true;
    size_t i=0,j=0; while(i<r.path.size()&&j<path.size()){
        if(r.path[i]==':') { size_t a=i+1; while(i<r.path.size()&&r.path[i]!='/')++i; std::string name=r.path.substr(a,i-a); size_t b=j; while(j<path.size()&&path[j]!='/')++j; if(b==j)return false; params[name]=url_decode(std::string_view(path).substr(b,j-b)); }
        else if(r.path[i]=='*' && i+1==r.path.size()){ params["wildcard"]=url_decode(std::string_view(path).substr(j)); return true; }
        else { if(r.path[i++]!=path[j++])return false; }
        if(i<r.path.size() && r.path[i]=='/' && j<path.size() && path[j]=='/') {++i;++j;}
    }
    return i==r.path.size()&&j==path.size();
}
HttpServer::HttpServer(std::string n,int p,std::size_t t,std::vector<compiler::Route> r):name_(std::move(n)),port_(p),threads_(t?t:std::max(2u,std::thread::hardware_concurrency())),routes_(std::move(r)),pool_(threads_){
#ifdef _WIN32
init_net();
#endif
}
HttpServer::~HttpServer(){stop();}
void HttpServer::stop(){
    bool expected=false;
    if(stopping_.compare_exchange_strong(expected,true)){
        NativeSocket s=(NativeSocket)listen_fd_;
        if(s!=INVALID_FD){
#ifdef _WIN32
            shutdown(s, SD_BOTH);
#else
            shutdown(s, SHUT_RDWR);
#endif
            close_socket(s);
        }
    }
}
bool HttpServer::parse_request(NativeSocket s,HttpRequest& req) const {
    std::string data; char buf[8192]; size_t header_end=std::string::npos;
    while((header_end=data.find("\r\n\r\n"))==std::string::npos){int n=(int)recv(s,buf,sizeof(buf),0);if(n<=0)return false;data.append(buf,buf+n);if(data.size()>max_header_bytes_)return false;}
    std::string h=data.substr(0,header_end);req.body=data.substr(header_end+4);
    std::istringstream in(h); std::string line; if(!std::getline(in,line))return false; if(!line.empty()&&line.back()=='\r')line.pop_back(); std::istringstream first(line); if(!(first>>req.method>>req.target>>req.version))return false;
    if(req.version!="HTTP/1.1"&&req.version!="HTTP/1.0")return false;
    while(std::getline(in,line)){if(!line.empty()&&line.back()=='\r')line.pop_back();auto c=line.find(':');if(c==std::string::npos)continue;std::string k=lower_ascii(line.substr(0,c));std::string v=line.substr(c+1);while(!v.empty()&&std::isspace((unsigned char)v.front()))v.erase(v.begin());req.headers[k]=v;}
    parse_query(req.target,req.query);
    auto it=req.headers.find("content-length"); if(it!=req.headers.end()){size_t need=0;try{need=std::stoull(it->second);}catch(...){return false;}if(need>max_body_bytes_)return false;while(req.body.size()<need){int n=(int)recv(s,buf,sizeof(buf),0);if(n<=0)return false;req.body.append(buf,buf+n);}if(req.body.size()>need)req.body.resize(need);}else if(req.body.size()>max_body_bytes_)return false;
    return true;
}
HttpResponse HttpServer::dispatch(HttpRequest& req) const {
    std::string path=req.target; if(auto q=path.find('?');q!=std::string::npos)path.resize(q);
    bool exists=false;
    for(const auto& r:routes_){std::map<std::string,std::string,std::less<>> params;if(!route_match(r,path,params))continue;exists=true;if(r.method!=req.method)continue;req.params=std::move(params);return {r.status,r.content_type,r.response_body,r.headers};}
    return {exists?405:404,"text/plain; charset=utf-8",exists?"Method Not Allowed":"Not Found",{}};
}
static bool send_all(NativeSocket s,const char* data,size_t n){while(n){int chunk=(int)std::min<size_t>(n,1u<<20);int w=send(s,data,chunk,0);if(w<=0)return false;data+=w;n-=w;}return true;}
void HttpServer::client(NativeSocket s){HttpRequest r;if(parse_request(s,r)){++requests_;auto resp=dispatch(r);auto txt=resp.serialize();(void)send_all(s,txt.data(),txt.size());}close_socket(s);}
void HttpServer::accept_loop(){while(!stopping_){sockaddr_in a{};
#ifdef _WIN32
int alen=sizeof(a);
#else
socklen_t alen=sizeof(a);
#endif
NativeSocket c=accept((NativeSocket)listen_fd_,(sockaddr*)&a,&alen);if(c==INVALID_FD){if(stopping_)break;continue;}try{pool_.submit([this,c]{client(c);});}catch(...){close_socket(c);}}}
void HttpServer::run(){NativeSocket s=socket(AF_INET,SOCK_STREAM,0);if(s==INVALID_FD)throw std::runtime_error("socket() failed");int yes=1;setsockopt(s,SOL_SOCKET,SO_REUSEADDR,(const char*)&yes,sizeof(yes));sockaddr_in a{};a.sin_family=AF_INET;a.sin_addr.s_addr=htonl(INADDR_ANY);a.sin_port=htons((uint16_t)port_);if(bind(s,(sockaddr*)&a,sizeof(a))<0){close_socket(s);throw std::runtime_error("bind() failed on port "+std::to_string(port_));}if(listen(s,512)<0){close_socket(s);throw std::runtime_error("listen() failed");}listen_fd_=(Socket)s;log::write(log::Level::Info,name_+" listening on http://127.0.0.1:"+std::to_string(port_));accept_loop();}
}
