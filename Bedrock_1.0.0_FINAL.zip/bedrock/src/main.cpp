#include "bedrock/compiler/compiler.hpp"
#include "bedrock/compiler/lexer.hpp"
#include "bedrock/compiler/parser.hpp"
#include "bedrock/common/log.hpp"
#include "bedrock/jit/x64_jit.hpp"
#include "bedrock/runtime/http.hpp"
#include "bedrock/runtime/module.hpp"
#include <algorithm>
#include <atomic>
#include <csignal>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

namespace { std::atomic<bool> g_stop{false}; void on_signal(int){g_stop=true;} }
static std::string read_file(const std::string& p){std::ifstream f(p,std::ios::binary);if(!f)throw std::runtime_error("cannot open: "+p);std::ostringstream s;s<<f.rdbuf();return s.str();}
static void usage(){std::cout<<R"(Bedrock 1.0.0 — server programming language

Usage:
  bedrock run <file.bed> [--port N]
  bedrock check <file.bed>
  bedrock jit <file.bed> <function>
  bedrock modules
  bedrock version
  bedrock doctor

Core design:
  JIT runtime + server-first standard modules + static typing.
)";}
static bedrock::compiler::Program load(const std::string& p){bedrock::compiler::Lexer l(read_file(p));bedrock::compiler::Parser parser(l.scan());return parser.parse();}
static int override_port(int argc,char**argv,int port){for(int i=3;i+1<argc;++i)if(std::string(argv[i])=="--port")return std::stoi(argv[i+1]);return port;}
int main(int argc,char**argv){
 try{
  if(argc<2){usage();return 1;}
  std::string cmd=argv[1];
  if(cmd=="version"){std::cout<<"Bedrock 1.0.0\n";return 0;}
  if(cmd=="modules"){
   bedrock::runtime::ModuleRegistry r;for(const auto&m:r.all())std::cout<<m.name<<"\t"<<m.footprint<<" bytes\t"<<m.description<<"\n";return 0;
  }
  if(cmd=="doctor"){
   bedrock::runtime::ModuleRegistry r;std::cout<<"Bedrock doctor\n"<<"  modules: "<<r.all().size()<<" available\n"<<"  JIT: x86-64\n"<<"  HTTP: HTTP/1.1\n"<<"  C++ ABI: native\n";return 0;
  }
  if((cmd=="run"||cmd=="check"||cmd=="jit")&&argc<3){usage();return 1;}
  auto program=load(argv[2]);
  auto cp=bedrock::compiler::Compiler().compile(std::move(program));
  if(cmd=="check"){
   std::cout<<"OK: valid Bedrock program\n";std::size_t total=0;for(auto&[n,b]:cp.modules){auto x=std::stoull(b);total+=x;std::cout<<"  import "<<n<<" -> "<<b<<" bytes\n";}std::cout<<"Imported module footprint: "<<total<<" bytes\n";return 0;
  }
  if(cmd=="jit"){
   if(argc<4) throw std::runtime_error("jit requires a function name");
   auto it=std::find_if(cp.program.functions.begin(),cp.program.functions.end(),[&](auto&f){return f.name==argv[3];});
   if(it==cp.program.functions.end()) throw std::runtime_error("function not found: "+std::string(argv[3]));
   bedrock::jit::X64Jit j; auto fn=j.compile(*it);
   std::cout<<"JIT compiled: "<<it->name<<"\n"<<"Sample (2,3,4,5): "<<fn(2,3,4,5)<<"\n";
   return 0;
  }
  if(cmd=="run"){
   std::signal(SIGINT,on_signal);std::signal(SIGTERM,on_signal);
   std::vector<std::unique_ptr<bedrock::runtime::HttpServer>> servers;std::vector<std::thread> workers;
   for(auto s:cp.program.servers){int port=override_port(argc,argv,s.port);servers.emplace_back(std::make_unique<bedrock::runtime::HttpServer>(s.name,port,s.threads,s.routes));}
   if(servers.empty()){std::cout<<"Program loaded; no server declarations.\n";return 0;}
   for(auto&srv:servers)workers.emplace_back([&srv]{try{srv->run();}catch(const std::exception&e){bedrock::log::write(bedrock::log::Level::Error,e.what());g_stop=true;}});
   while(!g_stop.load())std::this_thread::sleep_for(std::chrono::milliseconds(100));
   for(auto&srv:servers) srv->stop();
   for(auto&t:workers) if(t.joinable()) t.join();
   return 0;
  }
  usage();return 1;
 }catch(const std::exception&e){bedrock::log::write(bedrock::log::Level::Error,e.what());return 2;}
}
