# Bedrock 1.0.0

Bedrock is a server-first programming language implemented in C++20. Its runtime uses a native x86-64 JIT for arithmetic functions and a multithreaded HTTP/1.1 server runtime.

## Design

- JIT execution rather than a traditional interpreter
- Static type syntax with a small, readable grammar
- Server-first standard modules
- `import` selects runtime capabilities used by a program
- HTTP routing with exact paths, `:parameter` segments and `*` wildcard
- Thread-pool based request handling
- Graceful shutdown on SIGINT/SIGTERM
- Request query parsing, headers and body limits
- Configurable server port and worker count

## Language

```bedrock
import http;
import json;

fn add(a: Int, b: Int) -> Int {
    return a + b;
}

server API {
    listen 8080;
    async 4;

    route GET "/" {
        return "Hello from Bedrock";
    }

    route GET "/users/:id" {
        return "user";
    }
}
```

## CLI

```text
bedrock run app.bed
bedrock run app.bed --port 8081
bedrock check app.bed
bedrock jit app.bed add
bedrock modules
bedrock doctor
```

## Build

Linux/macOS:

```bash
./build.sh
```

Windows MinGW:

```bat
build.bat
```

Or use CMake directly:

```bash
cmake -S . -B build
cmake --build build --config Release
ctest --test-dir build --output-on-failure
```

## Module model

The core runtime is intentionally small. Modules describe optional server capabilities such as HTTP, WebSocket, JSON, crypto, database, filesystem, process, compression, metrics and logging. `bedrock check` reports the selected module footprint.

## Current protocol boundary

The included network runtime implements HTTP/1.1 request parsing and responses, not HTTP/2 or TLS termination. HTTPS can be placed behind a reverse proxy or added as a future native transport module without changing the Bedrock language surface.
