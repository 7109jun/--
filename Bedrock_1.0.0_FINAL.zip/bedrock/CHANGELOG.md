# Changelog

## 1.0.0
- Reworked project layout into compiler/runtime/JIT/module layers.
- Added native x86-64 JIT execution with ABI-safe prologue/epilogue.
- Added HTTP/1.1 server with worker pool.
- Added query parsing and path parameters.
- Added request-size limits and case-insensitive request headers.
- Added graceful shutdown.
- Added HEAD/OPTIONS route tokens.
- Added custom route response headers.
- Added CLI `doctor` command.
- Added expanded standard module registry.
- Added CTest coverage for lexer/parser/compiler/JIT/module behavior.
