#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct { uint8_t op,dst,src,res; uint64_t imm; } Ins;
enum {OP_NOP,OP_MOVI,OP_MOV,OP_ADD,OP_SUB,OP_MUL,OP_DIV,OP_MOD,OP_AND,OP_OR,OP_XOR,OP_SHL,OP_SHR,OP_CMP,OP_JMP,OP_JZ,OP_JNZ,OP_JG,OP_JL,OP_JGE,OP_JLE,OP_PUSH,OP_POP,OP_LOAD,OP_STORE,OP_CALL,OP_RET,OP_BIT_GET,OP_BIT_SET,OP_BIT_CLR,OP_BIT_TOG,OP_PRINT,OP_PRINT_STR,OP_FMOVI,OP_FMOV,OP_FADD,OP_FSUB,OP_FMUL,OP_FDIV,OP_FCMP,OP_FPRINT,OP_HALT};
static void die(const char*s){fprintf(stderr,"riscv64: %s\n",s);exit(1);}
static const char *regs[] = {"t0","t1","t2","t3","t4","t5","t6","a0","a1","a2","a3","a4","a5","a6","a7","s0"};
static const char *fregs[] = {"ft0","ft1","ft2","ft3","ft4","ft5","ft6","fa0","fa1","fa2","fa3","fa4","fa5","fa6","fa7","fs0"};
static void reg(FILE*f,int r){fprintf(f,"%s",r<16?regs[r]:"t6");}
static void freg(FILE*f,int r){fprintf(f,"%s",r<16?fregs[r]:"ft6");}
static int load(const char*p,Ins*c,size_t*m){FILE*f=fopen(p,"rb");if(!f)return 0;uint8_t h[16];if(fread(h,1,16,f)!=16||memcmp(h,"ASMV",4)){fclose(f);return 0;}uint32_t v;memcpy(&v,h+4,4);if(v!=3){fclose(f);return 0;}uint64_t n;memcpy(&n,h+8,8);if(n>*m){fclose(f);return 0;}if(fread(c,sizeof(*c),n,f)!=n){fclose(f);return 0;}*m=(size_t)n;fclose(f);return 1;}
static void emit(FILE*f,const Ins*x){
 switch(x->op){
 case OP_NOP:break;
 case OP_MOVI:fprintf(f,"    li ");reg(f,x->dst);fprintf(f,", %llu\n",(unsigned long long)x->imm);break;
 case OP_MOV:fprintf(f,"    mv ");reg(f,x->dst);fprintf(f,", ");reg(f,x->src);fputc('\n',f);break;
 case OP_ADD:case OP_SUB:case OP_MUL:case OP_AND:case OP_OR:case OP_XOR:case OP_SHL:case OP_SHR:{const char*n=x->op==OP_ADD?"add":x->op==OP_SUB?"sub":x->op==OP_MUL?"mul":x->op==OP_AND?"and":x->op==OP_OR?"or":x->op==OP_XOR?"xor":x->op==OP_SHL?"sll":"srl";fprintf(f,"    %s ",n);reg(f,x->dst);fprintf(f,", ");reg(f,x->dst);fprintf(f,", ");reg(f,x->src);fputc('\n',f);break;}
 case OP_DIV:case OP_MOD:{const char*n=x->op==OP_DIV?"div":"rem";fprintf(f,"    %s ",n);reg(f,x->dst);fprintf(f,", ");reg(f,x->dst);fprintf(f,", ");reg(f,x->src);fputc('\n',f);break;}
 case OP_CMP:fprintf(f,"    sub t6, ");reg(f,x->dst);fprintf(f,", ");reg(f,x->src);fputs("\n",f);break;
 case OP_JMP:fprintf(f,"    j I%llu\n",(unsigned long long)x->imm);break;
 case OP_JZ:fprintf(f,"    beqz t6, I%llu\n",(unsigned long long)x->imm);break;
 case OP_JNZ:fprintf(f,"    bnez t6, I%llu\n",(unsigned long long)x->imm);break;
 case OP_JG:fprintf(f,"    bgt t6, zero, I%llu\n",(unsigned long long)x->imm);break;
 case OP_JL:fprintf(f,"    blt t6, zero, I%llu\n",(unsigned long long)x->imm);break;
 case OP_JGE:fprintf(f,"    bge t6, zero, I%llu\n",(unsigned long long)x->imm);break;
 case OP_JLE:fprintf(f,"    blez t6, I%llu\n",(unsigned long long)x->imm);break;
 case OP_PUSH:fprintf(f,"    addi sp, sp, -8\n    sd ");reg(f,x->dst);fprintf(f,", 0(sp)\n");break;
 case OP_POP:fprintf(f,"    ld ");reg(f,x->dst);fprintf(f,", 0(sp)\n    addi sp, sp, 8\n");break;
 case OP_LOAD:fprintf(f,"    add t6, s10, ");reg(f,x->src);fprintf(f,"\n");if(x->imm==1)fprintf(f,"    lbu ");else if(x->imm==2)fprintf(f,"    lhu ");else if(x->imm==4)fprintf(f,"    lwu ");else if(x->imm==8)fprintf(f,"    ld ");else die("invalid load size");reg(f,x->dst);fprintf(f,", 0(t6)\n");break;
 case OP_STORE:fprintf(f,"    add t6, s10, ");reg(f,x->dst);fprintf(f,"\n");if(x->imm==1)fprintf(f,"    sb ");else if(x->imm==2)fprintf(f,"    sh ");else if(x->imm==4)fprintf(f,"    sw ");else if(x->imm==8)fprintf(f,"    sd ");else die("invalid store size");reg(f,x->src);fprintf(f,", 0(t6)\n");break;
 case OP_CALL:fprintf(f,"    call I%llu\n",(unsigned long long)x->imm);break;
 case OP_RET:fprintf(f,"    ret\n");break;
 case OP_BIT_GET:fprintf(f,"    srli t6, ");reg(f,x->src);fprintf(f,", %llu\n    andi ",(unsigned long long)x->imm);reg(f,x->dst);fprintf(f,", t6, 1\n");break;
 case OP_BIT_SET:fprintf(f,"    li t6, 1\n    slli t6, t6, %llu\n    or ",(unsigned long long)x->imm);reg(f,x->dst);fprintf(f,", ");reg(f,x->dst);fprintf(f,", t6\n");break;
 case OP_BIT_CLR:fprintf(f,"    li t6, 1\n    slli t6, t6, %llu\n    not t6, t6\n    and ",(unsigned long long)x->imm);reg(f,x->dst);fprintf(f,", ");reg(f,x->dst);fprintf(f,", t6\n");break;
 case OP_BIT_TOG:fprintf(f,"    li t6, 1\n    slli t6, t6, %llu\n    xor ",(unsigned long long)x->imm);reg(f,x->dst);fprintf(f,", ");reg(f,x->dst);fprintf(f,", t6\n");break;
 case OP_FMOVI:fprintf(f,"    li t6, %llu\n    fmv.d.x ",(unsigned long long)x->imm);freg(f,x->dst);fprintf(f,", t6\n");break;
 case OP_FMOV:fprintf(f,"    fmv.d ");freg(f,x->dst);fprintf(f,", ");freg(f,x->src);fputc('\n',f);break;
 case OP_FADD:case OP_FSUB:case OP_FMUL:case OP_FDIV:{const char*n=x->op==OP_FADD?"fadd.d":x->op==OP_FSUB?"fsub.d":x->op==OP_FMUL?"fmul.d":"fdiv.d";fprintf(f,"    %s ",n);freg(f,x->dst);fprintf(f,", ");freg(f,x->dst);fprintf(f,", ");freg(f,x->src);fputc('\n',f);break;}
 case OP_FCMP:fprintf(f,"    feq.d t6, ");freg(f,x->dst);fprintf(f,", ");freg(f,x->src);fputs("\n",f);break;
 case OP_PRINT:fprintf(f,"    call asmthon_print_i64\n");break;
 case OP_PRINT_STR:fprintf(f,"    addi a0, s10, %llu\n    call asmthon_print_str\n",(unsigned long long)x->imm);break;
 case OP_FPRINT:fprintf(f,"    call asmthon_print_f64\n");break;
 case OP_HALT:fprintf(f,"    ret\n");break;
 default:die("unsupported opcode");
 }}
int main(int ac,char**av){if(ac<3){fprintf(stderr,"usage: asmthon-riscv64 in.avm out.s\n");return 2;}Ins*c=calloc(8192,sizeof(*c));size_t n=8192;if(!c||!load(av[1],c,&n))die("invalid avm");FILE*f=fopen(av[2],"w");if(!f)die("cannot open output");fputs(".bss\n.align 3\nvm_memory: .zero 65536\n.text\n.globl asmthon_main\n.extern asmthon_print_i64\n.extern asmthon_print_f64\n.extern asmthon_print_str\nasmthon_main:\n    la s10, vm_memory\n",f);for(size_t i=0;i<n;i++){fprintf(f,"I%zu:\n",i);emit(f,&c[i]);}fputs("    ret\n",f);fclose(f);free(c);return 0;}
