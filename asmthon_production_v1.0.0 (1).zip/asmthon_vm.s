.intel_syntax noprefix
.global _start

# ============================================================
# Asmthon VM v0.2
# x86-64 Linux / GNU as Intel syntax
#
# .avm v3:
#   0..3   magic = ASMV
#   4..7   version = 2
#   8..15  instruction count
#   16..   16-byte instructions
# ============================================================

.equ SYS_READ,0
.equ SYS_WRITE,1
.equ SYS_OPEN,2
.equ SYS_CLOSE,3
.equ SYS_EXIT,60
.equ O_RDONLY,0

.equ REG_COUNT,16
.equ DATA_STACK_SIZE,4096
.equ CALL_STACK_SIZE,4096
.equ CALL_FRAME_QWORDS,17
.equ MEMORY_SIZE,65536
.equ MAX_CODE,8192
.equ FILEBUF_SIZE,MAX_CODE*16+16

.equ OP_NOP,0
.equ OP_MOVI,1
.equ OP_MOV,2
.equ OP_ADD,3
.equ OP_SUB,4
.equ OP_MUL,5
.equ OP_DIV,6
.equ OP_MOD,7
.equ OP_AND,8
.equ OP_OR,9
.equ OP_XOR,10
.equ OP_SHL,11
.equ OP_SHR,12
.equ OP_CMP,13
.equ OP_JMP,14
.equ OP_JZ,15
.equ OP_JNZ,16
.equ OP_JG,17
.equ OP_JL,18
.equ OP_JGE,19
.equ OP_JLE,20
.equ OP_PUSH,21
.equ OP_POP,22
.equ OP_LOAD,23
.equ OP_STORE,24
.equ OP_CALL,25
.equ OP_RET,26
.equ OP_BIT_GET,27
.equ OP_BIT_SET,28
.equ OP_BIT_CLR,29
.equ OP_BIT_TOG,30
.equ OP_PRINT,31
.equ OP_PRINT_STR,32
.equ OP_FMOVI,33
.equ OP_FMOV,34
.equ OP_FADD,35
.equ OP_FSUB,36
.equ OP_FMUL,37
.equ OP_FDIV,38
.equ OP_FCMP,39
.equ OP_FPRINT,40
.equ OP_HALT,41
.equ OP_HOST_ARG,42
.equ OP_HOST_READ_FILE,43
.equ OP_HOST_STRLEN,44
.equ OP_HOST_BC_RESET,45
.equ OP_HOST_BC_EMIT,46
.equ OP_HOST_BC_SET_IMM,47
.equ OP_HOST_BC_SAVE,48
.equ OP_COUNT,49

.equ FLAG_EQ,1
.equ FLAG_GT,2
.equ FLAG_LT,4

.section .bss
.lcomm regs,REG_COUNT*8
.lcomm data_stack,DATA_STACK_SIZE*8
.lcomm call_stack,CALL_STACK_SIZE*8
.lcomm memory,MEMORY_SIZE
.lcomm file_buf,FILEBUF_SIZE
.lcomm code_base,8
.lcomm code_count,8
.lcomm ip,8
.lcomm data_sp,8
.lcomm call_sp,8
.lcomm flags,8
.lcomm print_buf,32
.lcomm negative_flag,8
.lcomm host_code,MAX_CODE*16
.lcomm host_count,8
.lcomm host_argv,8
.lcomm host_argc,8
.lcomm host_tmp,FILEBUF_SIZE

.section .rodata
f64_fmt: .asciz "%.17g\n"
magic: .ascii "ASMV"
error_msg: .ascii "Asmthon VM error\n"
.equ error_len,.-error_msg
newline: .byte 10
minus: .byte '-'

.extern snprintf

.section .text

_start:
    mov rax,[rsp]
    cmp rax,2
    jb vm_error

    mov rax,[rsp]
    mov [host_argc],rax
    lea rax,[rsp+8]
    mov [host_argv],rax

    mov rdi,[rsp+16]
    call load_file
    test eax,eax
    jnz vm_error

    xor eax,eax
    mov [ip],rax
    mov [data_sp],rax
    mov [call_sp],rax
    mov [flags],rax

    lea rdi,[regs]
    xor eax,eax
    mov ecx,REG_COUNT
    rep stosq

    call execute

    mov eax,SYS_EXIT
    xor edi,edi
    syscall

# ------------------------------------------------------------
# load_file
# ------------------------------------------------------------
load_file:
    push r12
    push r13

    mov eax,SYS_OPEN
    xor esi,esi
    xor edx,edx
    syscall
    test rax,rax
    js .bad
    mov r12,rax

    xor eax,eax
    mov rdi,r12
    lea rsi,[file_buf]
    mov edx,FILEBUF_SIZE
    syscall
    test rax,rax
    js .close_bad
    mov r13,rax

    mov eax,SYS_CLOSE
    mov rdi,r12
    syscall

    cmp r13,16
    jb .bad_ret

    cmp dword ptr [file_buf],0x564D5341
    jne .bad_ret
    cmp dword ptr [file_buf+4],3
    jne .bad_ret

    mov rax,[file_buf+8]
    cmp rax,MAX_CODE
    ja .bad_ret

    mov [code_count],rax
    shl rax,4
    add rax,16
    cmp rax,r13
    jne .bad_ret

    lea rax,[file_buf+16]
    mov [code_base],rax

    xor eax,eax
    pop r13
    pop r12
    ret

.close_bad:
    mov eax,SYS_CLOSE
    mov rdi,r12
    syscall
.bad:
.bad_ret:
    mov eax,1
    pop r13
    pop r12
    ret


# ------------------------------------------------------------
# host_read_file(path)
# Copies a text file into VM memory at 0 and adds NUL.
# Returns pointer 0.
# ------------------------------------------------------------
host_read_file_impl:
    push r12
    push r13
    push r14
    mov r12,rdi
    mov eax,SYS_OPEN
    xor esi,esi
    xor edx,edx
    syscall
    test rax,rax
    js .rh_bad
    mov r13,rax
    xor eax,eax
    mov rdi,r13
    lea rsi,[memory]
    mov edx,MEMORY_SIZE-1
    syscall
    test rax,rax
    js .rh_close_bad
    mov r14,rax
    mov byte ptr [memory+r14],0
    mov eax,SYS_CLOSE
    mov rdi,r13
    syscall
    xor eax,eax
    mov rax,0
    pop r14
    pop r13
    pop r12
    ret
.rh_close_bad:
    mov eax,SYS_CLOSE
    mov rdi,r13
    syscall
.rh_bad:
    mov eax,1
    pop r14
    pop r13
    pop r12
    ret

# ------------------------------------------------------------
# host_save_code(path)
# ------------------------------------------------------------
host_save_code:
    push r12
    push r13
    mov r12,rdi
    mov eax,SYS_OPEN
    mov rdi,r12
    mov esi,577
    mov edx,420
    syscall
    test rax,rax
    js .hs_bad
    mov r13,rax
    sub rsp,16
    mov dword ptr [rsp],0x564D5341
    mov dword ptr [rsp+4],3
    mov rax,[host_count]
    mov [rsp+8],rax
    mov eax,SYS_WRITE
    mov rdi,r13
    mov rsi,rsp
    mov edx,16
    syscall
    cmp rax,16
    jne .hs_close_bad
    mov rax,[host_count]
    shl rax,4
    mov rdx,rax
    mov eax,SYS_WRITE
    mov rdi,r13
    lea rsi,[host_code]
    syscall
    cmp rax,rdx
    jne .hs_close_bad
    mov eax,SYS_CLOSE
    mov rdi,r13
    syscall
    add rsp,16
    xor eax,eax
    pop r13
    pop r12
    ret
.hs_close_bad:
    mov eax,SYS_CLOSE
    mov rdi,r13
    syscall
    add rsp,16
.hs_bad:
    mov eax,1
    pop r13
    pop r12
    ret

# ------------------------------------------------------------
# execute
# ------------------------------------------------------------
execute:
execute_next:
    mov rax,[ip]
    cmp rax,[code_count]
    jae vm_error
    shl rax,4
    mov rbx,[code_base]
    add rbx,rax

    movzx r12d,byte ptr [rbx]
    movzx r13d,byte ptr [rbx+1]
    movzx r14d,byte ptr [rbx+2]
    mov r15,[rbx+8]

    inc qword ptr [ip]
    cmp r12d,OP_COUNT
    jae vm_error
    jmp qword ptr [dispatch_table+r12*8]

# ------------------------------------------------------------
# dispatch table
# ------------------------------------------------------------
.section .rodata
.align 8
dispatch_table:
    .quad op_nop
    .quad op_movi
    .quad op_mov
    .quad op_add
    .quad op_sub
    .quad op_mul
    .quad op_div
    .quad op_mod
    .quad op_and
    .quad op_or
    .quad op_xor
    .quad op_shl
    .quad op_shr
    .quad op_cmp
    .quad op_jmp
    .quad op_jz
    .quad op_jnz
    .quad op_jg
    .quad op_jl
    .quad op_jge
    .quad op_jle
    .quad op_push
    .quad op_pop
    .quad op_load
    .quad op_store
    .quad op_call
    .quad op_ret
    .quad op_bit_get
    .quad op_bit_set
    .quad op_bit_clr
    .quad op_bit_tog
    .quad op_print
    .quad op_print_str
    .quad op_fmovi
    .quad op_fmov
    .quad op_fadd
    .quad op_fsub
    .quad op_fmul
    .quad op_fdiv
    .quad op_fcmp
    .quad op_fprint
    .quad op_halt
    .quad op_host_arg
    .quad op_host_read_file
    .quad op_host_strlen
    .quad op_host_bc_reset
    .quad op_host_bc_emit
    .quad op_host_bc_set_imm
    .quad op_host_bc_save

.section .text

# ------------------------------------------------------------
# Arithmetic / data
# ------------------------------------------------------------
op_nop:
    jmp execute_next

op_movi:
    cmp r13d,REG_COUNT
    jae vm_error
    mov [regs+r13*8],r15
    jmp execute_next

op_mov:
    cmp r13d,REG_COUNT
    jae vm_error
    cmp r14d,REG_COUNT
    jae vm_error
    mov rax,[regs+r14*8]
    mov [regs+r13*8],rax
    jmp execute_next

op_add:
    cmp r13d,REG_COUNT
    jae vm_error
    cmp r14d,REG_COUNT
    jae vm_error
    mov rax,[regs+r13*8]
    add rax,[regs+r14*8]
    mov [regs+r13*8],rax
    jmp execute_next

op_sub:
    cmp r13d,REG_COUNT
    jae vm_error
    cmp r14d,REG_COUNT
    jae vm_error
    mov rax,[regs+r13*8]
    sub rax,[regs+r14*8]
    mov [regs+r13*8],rax
    jmp execute_next

op_mul:
    cmp r13d,REG_COUNT
    jae vm_error
    cmp r14d,REG_COUNT
    jae vm_error
    mov rax,[regs+r13*8]
    imul rax,[regs+r14*8]
    mov [regs+r13*8],rax
    jmp execute_next

op_div:
    cmp r13d,REG_COUNT
    jae vm_error
    cmp r14d,REG_COUNT
    jae vm_error
    mov rax,[regs+r13*8]
    mov rcx,[regs+r14*8]
    test rcx,rcx
    jz vm_error
    mov r11,0x8000000000000000
    cmp rax,r11
    jne op_div_ok
    cmp rcx,-1
    je vm_error
op_div_ok:
    cqo
    idiv rcx
    mov [regs+r13*8],rax
    jmp execute_next

op_mod:
    cmp r13d,REG_COUNT
    jae vm_error
    cmp r14d,REG_COUNT
    jae vm_error
    mov rax,[regs+r13*8]
    mov rcx,[regs+r14*8]
    test rcx,rcx
    jz vm_error
    mov r11,0x8000000000000000
    cmp rax,r11
    jne op_mod_normal
    cmp rcx,-1
    jne op_mod_normal
    xor edx,edx
    mov [regs+r13*8],rdx
    jmp execute_next
op_mod_normal:
    cqo
    idiv rcx
    mov [regs+r13*8],rdx
    jmp execute_next

op_and:
    mov rax,[regs+r13*8]
    and rax,[regs+r14*8]
    mov [regs+r13*8],rax
    jmp execute_next

op_or:
    mov rax,[regs+r13*8]
    or rax,[regs+r14*8]
    mov [regs+r13*8],rax
    jmp execute_next

op_xor:
    mov rax,[regs+r13*8]
    xor rax,[regs+r14*8]
    mov [regs+r13*8],rax
    jmp execute_next

op_shl:
    mov rax,[regs+r13*8]
    mov rcx,[regs+r14*8]
    cmp rcx,63
    ja vm_error
    shl rax,cl
    mov [regs+r13*8],rax
    jmp execute_next

op_shr:
    mov rax,[regs+r13*8]
    mov rcx,[regs+r14*8]
    cmp rcx,63
    ja vm_error
    shr rax,cl
    mov [regs+r13*8],rax
    jmp execute_next

# ------------------------------------------------------------
# Compare / branches
# ------------------------------------------------------------
op_cmp:
    cmp r13d,REG_COUNT
    jae vm_error
    cmp r14d,REG_COUNT
    jae vm_error
    mov rax,[regs+r13*8]
    mov rcx,[regs+r14*8]
    cmp rax,rcx
    mov qword ptr [flags],0
    je .eq
    jg .gt
    mov qword ptr [flags],FLAG_LT
    jmp execute_next
.eq:
    mov qword ptr [flags],FLAG_EQ
    jmp execute_next
.gt:
    mov qword ptr [flags],FLAG_GT
    jmp execute_next

op_jmp:
    call validate_target
    mov [ip],r15
    jmp execute_next

op_jz:
    test qword ptr [flags],FLAG_EQ
    jz execute_next
    call validate_target
    mov [ip],r15
    jmp execute_next

op_jnz:
    test qword ptr [flags],FLAG_EQ
    jnz execute_next
    call validate_target
    mov [ip],r15
    jmp execute_next

op_jg:
    test qword ptr [flags],FLAG_GT
    jz execute_next
    call validate_target
    mov [ip],r15
    jmp execute_next

op_jl:
    test qword ptr [flags],FLAG_LT
    jz execute_next
    call validate_target
    mov [ip],r15
    jmp execute_next

op_jge:
    mov rax,[flags]
    test rax,FLAG_GT
    jnz op_jge_take
    test rax,FLAG_EQ
    jz execute_next
op_jge_take:
    call validate_target
    mov [ip],r15
    jmp execute_next

op_jle:
    mov rax,[flags]
    test rax,FLAG_LT
    jnz op_jle_take
    test rax,FLAG_EQ
    jz execute_next
op_jle_take:
    call validate_target
    mov [ip],r15
    jmp execute_next

validate_target:
    cmp r15,[code_count]
    jae vm_error
    ret

# ------------------------------------------------------------
# Data stack
# ------------------------------------------------------------
op_push:
    cmp r13d,REG_COUNT
    jae vm_error
    mov rax,[data_sp]
    cmp rax,DATA_STACK_SIZE
    jae vm_error
    mov rcx,[regs+r13*8]
    mov [data_stack+rax*8],rcx
    inc rax
    mov [data_sp],rax
    jmp execute_next

op_pop:
    cmp r13d,REG_COUNT
    jae vm_error
    mov rax,[data_sp]
    test rax,rax
    jz vm_error
    dec rax
    mov [data_sp],rax
    mov rcx,[data_stack+rax*8]
    mov [regs+r13*8],rcx
    jmp execute_next

# ------------------------------------------------------------
# Memory
# dst/src/operand:
#   LOAD  dst = memory[src], size operand 1/2/4/8
#   STORE memory[dst] = src, size operand 1/2/4/8
# ------------------------------------------------------------
op_load:
    cmp r13d,REG_COUNT
    jae vm_error
    cmp r14d,REG_COUNT
    jae vm_error
    mov rax,[regs+r14*8]
    mov rcx,r15
    cmp rcx,1
    je op_load_b
    cmp rcx,2
    je op_load_w
    cmp rcx,4
    je op_load_d
    cmp rcx,8
    je op_load_q
    jmp vm_error
op_load_b:
    cmp rax,MEMORY_SIZE-1
    ja vm_error
    movzx rcx,byte ptr [memory+rax]
    mov [regs+r13*8],rcx
    jmp execute_next
op_load_w:
    cmp rax,MEMORY_SIZE-2
    ja vm_error
    movzx rcx,word ptr [memory+rax]
    mov [regs+r13*8],rcx
    jmp execute_next
op_load_d:
    cmp rax,MEMORY_SIZE-4
    ja vm_error
    mov ecx,dword ptr [memory+rax]
    mov [regs+r13*8],rcx
    jmp execute_next
op_load_q:
    cmp rax,MEMORY_SIZE-8
    ja vm_error
    mov rcx,[memory+rax]
    mov [regs+r13*8],rcx
    jmp execute_next

op_store:
    cmp r13d,REG_COUNT
    jae vm_error
    cmp r14d,REG_COUNT
    jae vm_error
    mov rax,[regs+r13*8]
    mov rcx,[regs+r14*8]
    mov rdx,r15
    cmp rdx,1
    je op_store_b
    cmp rdx,2
    je op_store_w
    cmp rdx,4
    je op_store_d
    cmp rdx,8
    je op_store_q
    jmp vm_error
op_store_b:
    cmp rax,MEMORY_SIZE-1
    ja vm_error
    mov byte ptr [memory+rax],cl
    jmp execute_next
op_store_w:
    cmp rax,MEMORY_SIZE-2
    ja vm_error
    mov word ptr [memory+rax],cx
    jmp execute_next
op_store_d:
    cmp rax,MEMORY_SIZE-4
    ja vm_error
    mov dword ptr [memory+rax],ecx
    jmp execute_next
op_store_q:
    cmp rax,MEMORY_SIZE-8
    ja vm_error
    mov [memory+rax],rcx
    jmp execute_next

# ------------------------------------------------------------
# Calls / returns
# ------------------------------------------------------------
op_call:
    cmp r13d,16
    ja vm_error
    mov rax,[call_sp]
    mov rcx,CALL_FRAME_QWORDS
    imul rax,rcx
    add rax,CALL_FRAME_QWORDS
    cmp rax,CALL_STACK_SIZE
    ja vm_error
    call validate_target
    mov rbx,[call_sp]
    imul rbx,CALL_FRAME_QWORDS
    lea rbx,[call_stack+rbx*8]
    mov rcx,[ip]
    mov [rbx],rcx
    xor eax,eax
.op_call_save:
    mov rcx,[regs+rax*8]
    mov [rbx+8+rax*8],rcx
    inc eax
    cmp eax,REG_COUNT
    jb .op_call_save
    inc qword ptr [call_sp]
    mov [ip],r15
    jmp execute_next

op_ret:
    mov rax,[call_sp]
    test rax,rax
    jz op_halt
    dec rax
    mov [call_sp],rax
    imul rax,CALL_FRAME_QWORDS
    lea rbx,[call_stack+rax*8]
    mov r15,[regs]
    mov rcx,[rbx]
    cmp rcx,[code_count]
    jae vm_error
    mov rax,1
.op_ret_restore:
    mov rdx,[rbx+8+rax*8]
    mov [regs+rax*8],rdx
    inc rax
    cmp rax,REG_COUNT
    jb .op_ret_restore
    mov [regs],r15
    mov [ip],rcx
    jmp execute_next

# ------------------------------------------------------------
# Bits
# ------------------------------------------------------------
op_bit_get:
    cmp r13d,REG_COUNT
    jae vm_error
    cmp r14d,REG_COUNT
    jae vm_error
    cmp r15,63
    ja vm_error
    mov rax,[regs+r14*8]
    mov rcx,r15
    shr rax,cl
    and eax,1
    mov [regs+r13*8],rax
    jmp execute_next

op_bit_set:
    cmp r13d,REG_COUNT
    jae vm_error
    cmp r15,63
    ja vm_error
    mov rax,1
    mov rcx,r15
    shl rax,cl
    or [regs+r13*8],rax
    jmp execute_next

op_bit_clr:
    cmp r13d,REG_COUNT
    jae vm_error
    cmp r15,63
    ja vm_error
    mov rax,1
    mov rcx,r15
    shl rax,cl
    not rax
    and [regs+r13*8],rax
    jmp execute_next

op_bit_tog:
    cmp r13d,REG_COUNT
    jae vm_error
    cmp r15,63
    ja vm_error
    mov rax,1
    mov rcx,r15
    shl rax,cl
    xor [regs+r13*8],rax
    jmp execute_next

# ------------------------------------------------------------
# Output
# ------------------------------------------------------------
op_print:
    cmp r13d,REG_COUNT
    jae vm_error
    mov rax,[regs+r13*8]
    call print_i64
    jmp execute_next

print_i64:
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push r8
    push r9
    push r10

    xor r8d,r8d
    test rax,rax
    jns .positive
    mov r8d,1
    neg rax                    # works for INT64_MIN as unsigned magnitude
.positive:
    lea rsi,[print_buf+31]
    xor ecx,ecx
    test rax,rax
    jnz .digits
    dec rsi
    mov byte ptr [rsi],'0'
    mov ecx,1
    jmp .ready
.digits:
    xor edx,edx
    mov ebx,10
    div rbx
    add dl,'0'
    dec rsi
    mov [rsi],dl
    inc ecx
    test rax,rax
    jnz .digits
.ready:
    mov r9,rsi                # number start
    mov r10,rcx               # number length

    test r8,r8
    jz .write_number
    mov eax,SYS_WRITE
    mov edi,1
    lea rsi,[minus]
    mov edx,1
    syscall
    mov rsi,r9
    mov rdx,r10
.write_number:
    mov eax,SYS_WRITE
    mov edi,1
    mov rdx,r10
    syscall

    mov eax,SYS_WRITE
    mov edi,1
    lea rsi,[newline]
    mov edx,1
    syscall

    pop r10
    pop r9
    pop r8
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    ret

op_print_str:
    mov rdi,r15
    cmp rdi,MEMORY_SIZE-1
    ja vm_error
    lea rsi,memory[rdi]
    xor edx,edx
.ps_len:
    cmp rdx,MEMORY_SIZE
    jae vm_error
    cmp byte ptr [rsi+rdx],0
    je .ps_write
    inc rdx
    jmp .ps_len
.ps_write:
    mov eax,SYS_WRITE
    mov edi,1
    syscall
    mov eax,SYS_WRITE
    mov edi,1
    lea rsi,newline
    mov edx,1
    syscall
    jmp execute_next

op_fmovi:
    cmp r13d,REG_COUNT
    jae vm_error
    mov rax,r15
    mov [regs+r13*8],rax
    jmp execute_next

op_fmov:
    cmp r13d,REG_COUNT
    jae vm_error
    cmp r14d,REG_COUNT
    jae vm_error
    mov rax,[regs+r14*8]
    mov [regs+r13*8],rax
    jmp execute_next

op_fadd:
    movq xmm0,[regs+r13*8]
    movq xmm1,[regs+r14*8]
    addsd xmm0,xmm1
    movq rax,xmm0
    mov [regs+r13*8],rax
    jmp execute_next

op_fsub:
    movq xmm0,[regs+r13*8]
    movq xmm1,[regs+r14*8]
    subsd xmm0,xmm1
    movq rax,xmm0
    mov [regs+r13*8],rax
    jmp execute_next

op_fmul:
    movq xmm0,[regs+r13*8]
    movq xmm1,[regs+r14*8]
    mulsd xmm0,xmm1
    movq rax,xmm0
    mov [regs+r13*8],rax
    jmp execute_next

op_fdiv:
    movq xmm0,[regs+r13*8]
    movq xmm1,[regs+r14*8]
    divsd xmm0,xmm1
    movq rax,xmm0
    mov [regs+r13*8],rax
    jmp execute_next

op_fcmp:
    movq xmm0,[regs+r13*8]
    movq xmm1,[regs+r14*8]
    ucomisd xmm0,xmm1
    mov qword ptr [flags],0
    je .feq
    ja .fgt
    jb .flt
    jmp execute_next
.feq:
    mov qword ptr [flags],FLAG_EQ
    jmp execute_next
.fgt:
    mov qword ptr [flags],FLAG_GT
    jmp execute_next
.flt:
    mov qword ptr [flags],FLAG_LT
    jmp execute_next

op_fprint:
    cmp r13d,REG_COUNT
    jae vm_error
    movq xmm0,[regs+r13*8]
    lea rdi,[print_buf]
    mov esi,32
    lea rdx,[f64_fmt]
    mov eax,1
    sub rsp,8
    call snprintf
    add rsp,8
    test eax,eax
    js vm_error
    mov edx,eax
    mov eax,SYS_WRITE
    mov edi,1
    lea rsi,[print_buf]
    syscall
    jmp execute_next


# ------------------------------------------------------------
# Host/bootstrap services
# ------------------------------------------------------------
op_host_arg:
    mov rax,[regs]
    add rax,2
    cmp rax,[host_argc]
    jae vm_error
    mov rcx,[host_argv]
    mov rax,[rcx+rax*8]
    mov [regs],rax
    jmp execute_next

op_host_read_file:
    mov rdi,[regs]
    call host_read_file_impl
    test eax,eax
    jnz vm_error
    mov [regs],rax
    jmp execute_next

op_host_strlen:
    mov rdi,[regs]
    cmp rdi,MEMORY_SIZE-1
    ja vm_error
    xor rcx,rcx
.hslen:
    cmp rcx,MEMORY_SIZE
    jae vm_error
    cmp byte ptr [memory+rdi+rcx],0
    je .hsdone
    inc rcx
    jmp .hslen
.hsdone:
    mov [regs],rcx
    jmp execute_next

op_host_bc_reset:
    xor eax,eax
    mov [host_count],rax
    jmp execute_next

op_host_bc_emit:
    mov rax,[host_count]
    cmp rax,MAX_CODE
    jae vm_error
    shl rax,4
    lea rbx,[host_code+rax]
    mov rcx,[regs]
    mov byte ptr [rbx],cl
    mov rcx,[regs+8]
    mov byte ptr [rbx+1],cl
    mov rcx,[regs+16]
    mov byte ptr [rbx+2],cl
    mov qword ptr [rbx+8],0
    mov rcx,[regs+24]
    mov qword ptr [rbx+8],rcx
    mov rax,[host_count]
    inc rax
    mov [host_count],rax
    dec rax
    mov [regs],rax
    jmp execute_next

op_host_bc_set_imm:
    mov rax,[regs]
    cmp rax,[host_count]
    jae vm_error
    shl rax,4
    lea rbx,[host_code+rax]
    mov rcx,[regs+8]
    mov qword ptr [rbx+8],rcx
    jmp execute_next

op_host_bc_save:
    mov rdi,[regs]
    call host_save_code
    test eax,eax
    jnz vm_error
    xor eax,eax
    mov [regs],rax
    jmp execute_next

op_halt:
    mov eax,SYS_EXIT
    xor edi,edi
    syscall

vm_error:
    mov eax,SYS_WRITE
    mov edi,2
    lea rsi,[error_msg]
    mov edx,error_len
    syscall
    mov eax,SYS_EXIT
    mov edi,1
    syscall
