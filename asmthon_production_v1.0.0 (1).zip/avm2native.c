#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define MAX_INS 131072
#define MAGIC "ASMV"
#define VERSION 3
#define REG_COUNT 16
#define STACK_SIZE 4096
#define MEMORY_SIZE 65536

enum { OP_NOP,OP_MOVI,OP_MOV,OP_ADD,OP_SUB,OP_MUL,OP_DIV,OP_MOD,OP_AND,OP_OR,OP_XOR,OP_SHL,OP_SHR,OP_CMP,OP_JMP,OP_JZ,OP_JNZ,OP_JG,OP_JL,OP_JGE,OP_JLE,OP_PUSH,OP_POP,OP_LOAD,OP_STORE,OP_CALL,OP_RET,OP_BIT_GET,OP_BIT_SET,OP_BIT_CLR,OP_BIT_TOG,OP_PRINT,OP_PRINT_STR,OP_FMOVI,OP_FMOV,OP_FADD,OP_FSUB,OP_FMUL,OP_FDIV,OP_FCMP,OP_FPRINT,OP_HALT,OP_HOST_ARG,OP_HOST_READ_FILE,OP_HOST_STRLEN,OP_HOST_BC_RESET,OP_HOST_BC_EMIT,OP_HOST_BC_SET_IMM,OP_HOST_BC_SAVE,OP_COUNT };

typedef struct { uint8_t op,dst,src,res; uint64_t imm; } Ins;

static void die(const char *m){ fprintf(stderr,"avm2native: %s\n",m); exit(1); }
static void load_program(const char *path, Ins **out, size_t *count){
    FILE *f=fopen(path,"rb"); if(!f)die("cannot open input");
    uint8_t hdr[16]; if(fread(hdr,1,16,f)!=16)die("short header");
    if(memcmp(hdr,MAGIC,4)!=0)die("bad magic");
    uint32_t version; memcpy(&version,hdr+4,4); if(version!=VERSION)die("unsupported bytecode version");
    uint64_t n; memcpy(&n,hdr+8,8); if(!n||n>MAX_INS)die("invalid instruction count");
    Ins *c=calloc((size_t)n,sizeof(*c)); if(!c)die("out of memory");
    if(fread(c,sizeof(*c),(size_t)n,f)!=(size_t)n)die("truncated bytecode");
    fclose(f); *out=c; *count=(size_t)n;
}

static void prologue(FILE *o){
    fputs(".section .text\n.extern snprintf\n.global _start\n\n",o);
    fputs("_start:\n    call I0\n    mov $60, %eax\n    xor %edi, %edi\n    syscall\n\n",o);
}
static void bss(FILE *o){
    fprintf(o,
        ".section .bss\n.align 16\n"
        "vm_regs: .zero %d\n"
        "vm_stack: .zero %d\n"
        "vm_callstack: .zero %d\n"
        "vm_sp: .quad 0\n"
        "vm_call_sp: .quad 0\n"
        "vm_flags: .quad 0\n"
        "vm_return_temp: .quad 0\n"
        "vm_memory: .zero %d\n"
        "print_buf: .zero 32\n\n",
        REG_COUNT*8, STACK_SIZE*8, 4096*17*8, MEMORY_SIZE);
}

static void load_reg(FILE *o,int r,const char *tmp){ fprintf(o,"    mov vm_regs+%d(%%rip), %s\n",r*8,tmp); }
static void store_reg(FILE *o,int r,const char *src){ fprintf(o,"    mov %s, vm_regs+%d(%%rip)\n",src,r*8); }
static void jlabel(FILE *o,uint64_t n){ fprintf(o,"I%llu",(unsigned long long)n); }

static int print_seq;
static void emit_print(FILE *o){
    int id=print_seq++;
    fprintf(o,
"    lea print_buf+31(%%rip), %%rsi\n"
"    xor %%ecx, %%ecx\n"
"    xor %%r8d, %%r8d\n"
"    test %%rax, %%rax\n"
"    jns .Lpn%d_positive\n"
"    mov $1, %%r8d\n"
"    neg %%rax\n"
".Lpn%d_positive:\n"
"    test %%rax, %%rax\n"
"    jnz .Lpn%d_digits\n"
"    dec %%rsi\n"
"    movb $'0', (%%rsi)\n"
"    mov $1, %%edx\n"
"    jmp .Lpn%d_sign\n"
".Lpn%d_digits:\n"
"    xor %%edx, %%edx\n"
"    mov $10, %%ebx\n"
".Lpn%d_digit_loop:\n"
"    xor %%edx, %%edx\n"
"    div %%rbx\n"
"    addb $'0', %%dl\n"
"    dec %%rsi\n"
"    mov %%dl, (%%rsi)\n"
"    inc %%ecx\n"
"    test %%rax, %%rax\n"
"    jnz .Lpn%d_digit_loop\n"
"    mov %%ecx, %%edx\n"
".Lpn%d_sign:\n"
"    test %%r8d, %%r8d\n"
"    jz .Lpn%d_write\n"
"    dec %%rsi\n"
"    movb $'-', (%%rsi)\n"
"    inc %%edx\n"
".Lpn%d_write:\n"
"    mov $1, %%eax\n"
"    mov $1, %%edi\n"
"    syscall\n"
"    mov $1, %%eax\n"
"    mov $1, %%edi\n"
"    lea .nl(%%rip), %%rsi\n"
"    mov $1, %%edx\n"
"    syscall\n",
        id,id,id,id,id,id,id,id,id,id);
}

static void emit_print_str(FILE *o,uint64_t addr){
    int id=print_seq++;
    fprintf(o,
        "    lea vm_memory+%llu(%%rip), %%rsi\n"
        "    xor %%edx, %%edx\n"
        ".Lps%d_len:\n"
        "    cmp $65536, %%rdx\n"
        "    jae .trap\n"
        "    cmpb $0, (%%rsi,%%rdx,1)\n"
        "    je .Lps%d_write\n"
        "    inc %%rdx\n"
        "    jmp .Lps%d_len\n"
        ".Lps%d_write:\n"
        "    mov $1, %%eax\n"
        "    mov $1, %%edi\n"
        "    syscall\n"
        "    mov $1, %%eax\n"
        "    mov $1, %%edi\n"
        "    lea .nl(%%rip), %%rsi\n"
        "    mov $1, %%edx\n"
        "    syscall\n",
        (unsigned long long)addr,id,id,id,id);
}

static int ret_label_seq=0;
static void emit_ins(FILE *o,const Ins *in){
    switch(in->op){
    case OP_NOP: break;
    case OP_MOVI: fprintf(o,"    mov $%lld, %%rax\n",(long long)in->imm); store_reg(o,in->dst,"%rax"); break;
    case OP_MOV: load_reg(o,in->src,"%rax"); store_reg(o,in->dst,"%rax"); break;
    case OP_ADD: load_reg(o,in->dst,"%rax"); load_reg(o,in->src,"%rcx"); fputs("    add %rcx, %rax\n",o); store_reg(o,in->dst,"%rax"); break;
    case OP_SUB: load_reg(o,in->dst,"%rax"); load_reg(o,in->src,"%rcx"); fputs("    sub %rcx, %rax\n",o); store_reg(o,in->dst,"%rax"); break;
    case OP_MUL: load_reg(o,in->dst,"%rax"); load_reg(o,in->src,"%rcx"); fputs("    imul %rcx, %rax\n",o); store_reg(o,in->dst,"%rax"); break;
    case OP_DIV: load_reg(o,in->dst,"%rax"); load_reg(o,in->src,"%rcx"); fputs("    test %rcx, %rcx\n    jz .trap\n    cqo\n    idiv %rcx\n",o); store_reg(o,in->dst,"%rax"); break;
    case OP_MOD: load_reg(o,in->dst,"%rax"); load_reg(o,in->src,"%rcx"); fputs("    test %rcx, %rcx\n    jz .trap\n    cqo\n    idiv %rcx\n",o); store_reg(o,in->dst,"%rdx"); break;
    case OP_AND: load_reg(o,in->dst,"%rax"); load_reg(o,in->src,"%rcx"); fputs("    and %rcx, %rax\n",o); store_reg(o,in->dst,"%rax"); break;
    case OP_OR: load_reg(o,in->dst,"%rax"); load_reg(o,in->src,"%rcx"); fputs("    or %rcx, %rax\n",o); store_reg(o,in->dst,"%rax"); break;
    case OP_XOR: load_reg(o,in->dst,"%rax"); load_reg(o,in->src,"%rcx"); fputs("    xor %rcx, %rax\n",o); store_reg(o,in->dst,"%rax"); break;
    case OP_SHL: load_reg(o,in->dst,"%rax"); load_reg(o,in->src,"%rcx"); fputs("    cmp $63, %rcx\n    ja .trap\n    mov %cl, %cl\n    shl %cl, %rax\n",o); store_reg(o,in->dst,"%rax"); break;
    case OP_SHR: load_reg(o,in->dst,"%rax"); load_reg(o,in->src,"%rcx"); fputs("    cmp $63, %rcx\n    ja .trap\n    shr %cl, %rax\n",o); store_reg(o,in->dst,"%rax"); break;
    case OP_CMP: load_reg(o,in->dst,"%rax"); load_reg(o,in->src,"%rcx"); fputs("    cmp %rcx, %rax\n    mov $0, %rdx\n    je 1f\n    jg 2f\n    mov $4, %rdx\n    jmp 3f\n1:  mov $1, %rdx\n    jmp 3f\n2:  mov $2, %rdx\n3:\n    mov %rdx, vm_flags(%rip)\n",o); break;
    case OP_JMP: fputs("    jmp ",o); jlabel(o,in->imm); fputc('\n',o); break;
    case OP_JZ: fputs("    cmpq $1, vm_flags(%rip)\n    je ",o); jlabel(o,in->imm); fputc('\n',o); break;
    case OP_JNZ: fputs("    cmpq $1, vm_flags(%rip)\n    jne ",o); jlabel(o,in->imm); fputc('\n',o); break;
    case OP_JG: fputs("    cmpq $2, vm_flags(%rip)\n    je ",o); jlabel(o,in->imm); fputc('\n',o); break;
    case OP_JL: fputs("    cmpq $4, vm_flags(%rip)\n    je ",o); jlabel(o,in->imm); fputc('\n',o); break;
    case OP_JGE: fputs("    cmpq $2, vm_flags(%rip)\n    je ",o); jlabel(o,in->imm); fputs("\n    cmpq $1, vm_flags(%rip)\n    je ",o); jlabel(o,in->imm); fputc('\n',o); break;
    case OP_JLE: fputs("    cmpq $4, vm_flags(%rip)\n    je ",o); jlabel(o,in->imm); fputs("\n    cmpq $1, vm_flags(%rip)\n    je ",o); jlabel(o,in->imm); fputc('\n',o); break;
    case OP_PUSH: load_reg(o,in->dst,"%rax"); fputs("    mov vm_sp(%rip), %rcx\n    cmp $4096, %rcx\n    jae .trap\n    mov %rax, vm_stack(,%rcx,8)\n    inc %rcx\n    mov %rcx, vm_sp(%rip)\n",o); break;
    case OP_POP: fputs("    mov vm_sp(%rip), %rcx\n    test %rcx, %rcx\n    jz .trap\n    dec %rcx\n    mov %rcx, vm_sp(%rip)\n    mov vm_stack(,%rcx,8), %rax\n",o); store_reg(o,in->dst,"%rax"); break;
    case OP_LOAD:
        load_reg(o,in->src,"%rax"); fprintf(o,"    cmp $%llu, %%rax\n    ja .trap\n",(unsigned long long)(MEMORY_SIZE-(in->imm>0?in->imm:8)));
        if(in->imm==1) fputs("    movzbq vm_memory(%rax), %rcx\n",o); else if(in->imm==2) fputs("    movzwq vm_memory(%rax), %rcx\n",o); else if(in->imm==4) fputs("    movl vm_memory(%rax), %ecx\n",o); else if(in->imm==8) fputs("    mov vm_memory(%rax), %rcx\n",o); else {fputs("    jmp .trap\n",o); break;} store_reg(o,in->dst,"%rcx"); break;
    case OP_STORE:
        load_reg(o,in->dst,"%rax"); fprintf(o,"    cmp $%llu, %%rax\n    ja .trap\n",(unsigned long long)(MEMORY_SIZE-(in->imm>0?in->imm:8)));
        load_reg(o,in->src,"%rcx"); if(in->imm==1) fputs("    mov %cl, vm_memory(%rax)\n",o); else if(in->imm==2) fputs("    mov %cx, vm_memory(%rax)\n",o); else if(in->imm==4) fputs("    mov %ecx, vm_memory(%rax)\n",o); else if(in->imm==8) fputs("    mov %rcx, vm_memory(%rax)\n",o); else fputs("    jmp .trap\n",o); break;
    case OP_CALL:
        fputs("    mov vm_call_sp(%rip), %rcx\n    cmp $4096, %rcx\n    jae .trap\n    imul $17, %rcx, %rax\n    lea vm_callstack(%rip), %r8\n    lea (%r8,%rax,8), %r8\n",o);
        for(int r=0;r<16;r++) fprintf(o,"    mov vm_regs+%d(%%rip), %%rdx\n    mov %%rdx, %d(%%r8)\n",r*8,8+r*8);
        fputs("    incq vm_call_sp(%rip)\n    call ",o); jlabel(o,in->imm); fputs("\n",o); break;
    case OP_RET: {
        int rid=ret_label_seq++;
        fprintf(o,"    mov vm_regs(%%rip), %%rax\n    mov %%rax, vm_return_temp(%%rip)\n    mov vm_call_sp(%%rip), %%rcx\n    test %%rcx, %%rcx\n    jz .Lnative_main_ret_%d\n    dec %%rcx\n    mov %%rcx, vm_call_sp(%%rip)\n    imul $17, %%rcx, %%rax\n    lea vm_callstack(%%rip), %%r8\n    lea (%%r8,%%rax,8), %%r8\n",rid);
        for(int r=1;r<16;r++) fprintf(o,"    mov %d(%%r8), %%rdx\n    mov %%rdx, vm_regs+%d(%%rip)\n",8+r*8,r*8);
        fprintf(o,"    mov vm_return_temp(%%rip), %%rax\n    mov %%rax, vm_regs(%%rip)\n    ret\n.Lnative_main_ret_%d:\n    ret\n",rid);
        break; }
    case OP_BIT_GET: load_reg(o,in->src,"%rax"); fprintf(o,"    mov $%llu, %%rcx\n    shr %%cl, %%rax\n    and $1, %%rax\n",(unsigned long long)in->imm); store_reg(o,in->dst,"%rax"); break;
    case OP_BIT_SET: load_reg(o,in->dst,"%rax"); fprintf(o,"    mov $1, %%rcx\n    shl $%llu, %%rcx\n    or %%rcx, %%rax\n",(unsigned long long)in->imm); store_reg(o,in->dst,"%rax"); break;
    case OP_BIT_CLR: load_reg(o,in->dst,"%rax"); fprintf(o,"    mov $1, %%rcx\n    shl $%llu, %%rcx\n    not %%rcx\n    and %%rcx, %%rax\n",(unsigned long long)in->imm); store_reg(o,in->dst,"%rax"); break;
    case OP_BIT_TOG: load_reg(o,in->dst,"%rax"); fprintf(o,"    mov $1, %%rcx\n    shl $%llu, %%rcx\n    xor %%rcx, %%rax\n",(unsigned long long)in->imm); store_reg(o,in->dst,"%rax"); break;
    case OP_PRINT: load_reg(o,in->dst,"%rax"); emit_print(o); break;
    case OP_PRINT_STR: emit_print_str(o,in->imm); break;
    case OP_FMOVI: fprintf(o,"    movabs $%llu, %%rax\n",(unsigned long long)in->imm); store_reg(o,in->dst,"%rax"); break;
    case OP_FMOV: load_reg(o,in->src,"%rax"); store_reg(o,in->dst,"%rax"); break;
    case OP_FADD: load_reg(o,in->dst,"%rax"); load_reg(o,in->src,"%rcx"); fputs("    movq %rax, %xmm0\n    movq %rcx, %xmm1\n    addsd %xmm1, %xmm0\n    movq %xmm0, %rax\n",o); store_reg(o,in->dst,"%rax"); break;
    case OP_FSUB: load_reg(o,in->dst,"%rax"); load_reg(o,in->src,"%rcx"); fputs("    movq %rax, %xmm0\n    movq %rcx, %xmm1\n    subsd %xmm1, %xmm0\n    movq %xmm0, %rax\n",o); store_reg(o,in->dst,"%rax"); break;
    case OP_FMUL: load_reg(o,in->dst,"%rax"); load_reg(o,in->src,"%rcx"); fputs("    movq %rax, %xmm0\n    movq %rcx, %xmm1\n    mulsd %xmm1, %xmm0\n    movq %xmm0, %rax\n",o); store_reg(o,in->dst,"%rax"); break;
    case OP_FDIV: load_reg(o,in->dst,"%rax"); load_reg(o,in->src,"%rcx"); fputs("    movq %rax, %xmm0\n    movq %rcx, %xmm1\n    divsd %xmm1, %xmm0\n    movq %xmm0, %rax\n",o); store_reg(o,in->dst,"%rax"); break;
    case OP_FCMP: load_reg(o,in->dst,"%rax"); load_reg(o,in->src,"%rcx"); fputs("    movq %rax, %xmm0\n    movq %rcx, %xmm1\n    ucomisd %xmm1, %xmm0\n    mov $0, %rdx\n    je 1f\n    ja 2f\n    jb 3f\n    jmp 4f\n1:  mov $1, %rdx\n    jmp 4f\n2:  mov $2, %rdx\n    jmp 4f\n3:  mov $4, %rdx\n4:  mov %rdx, vm_flags(%rip)\n",o); break;
    case OP_FPRINT: load_reg(o,in->dst,"%rax"); fputs("    movq %rax, %xmm0\n    lea print_buf(%rip), %rdi\n    mov $32, %esi\n    lea .f64fmt(%rip), %rdx\n    mov $1, %eax\n    sub $8, %rsp\n    call snprintf\n    add $8, %rsp\n    mov %eax, %edx\n    mov $1, %eax\n    mov $1, %edi\n    lea print_buf(%rip), %rsi\n    syscall\n",o); break;
    case OP_HALT: fputs("    ret\n",o); break;
    case OP_HOST_ARG: case OP_HOST_READ_FILE: case OP_HOST_STRLEN: case OP_HOST_BC_RESET: case OP_HOST_BC_EMIT: case OP_HOST_BC_SET_IMM: case OP_HOST_BC_SAVE:
        die("host/bootstrap opcode requires the VM backend"); break;
    default: fputs("    jmp .trap\n",o); break;
    }
}

int main(int argc,char**argv){
    if(argc!=3){fprintf(stderr,"usage: avm2native input.avm output.s\n");return 2;}
    Ins *code; size_t n; load_program(argv[1],&code,&n);
    FILE *o=fopen(argv[2],"w"); if(!o)die("cannot open output");
    bss(o); prologue(o);
    for(size_t i=0;i<n;i++){
        fprintf(o,"I%zu:\n",i);
        emit_ins(o,&code[i]);
    }
    fputs("\n.trap:\n    mov $60, %eax\n    mov $1, %edi\n    syscall\n\n.section .rodata\n.nl: .byte 10\n.f64fmt: .asciz \"%.17g\\n\"\n",o);
    fclose(o); free(code); return 0;
}
