#!/usr/bin/env bash
set -euo pipefail
CFLAGS='-std=c11 -O3 -Wall -Wextra -Wpedantic -Werror'
cc $CFLAGS asmthonc.c -o asmthonc
cc $CFLAGS avm2native.c -o avm2native
as --64 asmthon_vm.s -o asmthon_vm.o
gcc -nostartfiles -no-pie asmthon_vm.o -lc -o asmthon-vm
cc $CFLAGS asmthon_ssa.c -o asmthon-ssa
cc $CFLAGS asmthon_arm64.c -o asmthon-arm64
cc $CFLAGS asmthon_riscv64.c -o asmthon-riscv64
cc $CFLAGS asmthon_opt.c -o asmthon-opt
