#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

#define MAX_CODE 8192

typedef struct { unsigned char op,dst,src,res; uint64_t imm; } Ins;
enum {OP_NOP,OP_MOVI,OP_MOV,OP_ADD,OP_SUB,OP_MUL,OP_DIV,OP_MOD,OP_AND,OP_OR,OP_XOR,OP_SHL,OP_SHR,OP_CMP,OP_JMP,OP_JZ,OP_JNZ,OP_JG,OP_JL,OP_JGE,OP_JLE,OP_PUSH,OP_POP,OP_LOAD,OP_STORE,OP_CALL,OP_RET,OP_BIT_GET,OP_BIT_SET,OP_BIT_CLR,OP_BIT_TOG,OP_PRINT,OP_PRINT_STR,OP_FMOVI,OP_FMOV,OP_FADD,OP_FSUB,OP_FMUL,OP_FDIV,OP_FCMP,OP_FPRINT,OP_HALT,OP_HOST_ARG,OP_HOST_READ_FILE,OP_HOST_STRLEN,OP_HOST_BC_RESET,OP_HOST_BC_EMIT,OP_HOST_BC_SET_IMM,OP_HOST_BC_SAVE};
static void die(const char*s){fprintf(stderr,"opt: %s\n",s);exit(1);}
static int terminator(unsigned op){return op==OP_JMP||op==OP_RET||op==OP_HALT;}
static int branch(unsigned op){return op>=OP_JMP&&op<=OP_JLE;}
static int barrier(const Ins*x){switch(x->op){case OP_JMP:case OP_JZ:case OP_JNZ:case OP_JG:case OP_JL:case OP_JGE:case OP_JLE:case OP_CALL:case OP_RET:case OP_LOAD:case OP_STORE:case OP_PUSH:case OP_POP:case OP_PRINT:case OP_PRINT_STR:case OP_FCMP:case OP_FPRINT:case OP_HOST_ARG:case OP_HOST_READ_FILE:case OP_HOST_STRLEN:case OP_HOST_BC_RESET:case OP_HOST_BC_EMIT:case OP_HOST_BC_SET_IMM:case OP_HOST_BC_SAVE: return 1;default:return 0;}}
static double u64_to_f64(uint64_t u){double x;memcpy(&x,&u,8);return x;}
static uint64_t f64_to_u64(double x){uint64_t u;memcpy(&u,&x,8);return u;}
static void optimize_block(Ins*c,size_t lo,size_t hi){
    int64_t ik[16]={0}; uint64_t fk[16]={0};
    unsigned char known[16]={0}, fknown[16]={0};
    for(size_t i=lo;i<hi;i++){
        Ins*x=&c[i];
        if(x->op==OP_NOP) continue;
        if(x->op==OP_MOV && x->dst==x->src){ x->op=OP_NOP; continue; }
        if(x->op==OP_MOVI){ known[x->dst]=1; fknown[x->dst]=0; ik[x->dst]=(int64_t)x->imm; continue; }
        if(x->op==OP_FMOVI){ fknown[x->dst]=1; known[x->dst]=0; fk[x->dst]=x->imm; continue; }
        if(x->op==OP_MOV){
            if(known[x->src]){ x->op=OP_MOVI; x->imm=(uint64_t)ik[x->src]; known[x->dst]=1; fknown[x->dst]=0; ik[x->dst]=ik[x->src]; }
            else if(fknown[x->src]){ x->op=OP_FMOVI; x->imm=fk[x->src]; fknown[x->dst]=1; known[x->dst]=0; fk[x->dst]=fk[x->src]; }
            else { known[x->dst]=known[x->src]; fknown[x->dst]=fknown[x->src]; ik[x->dst]=ik[x->src]; fk[x->dst]=fk[x->src]; }
            continue;
        }
        if(x->op==OP_FMOV){
            if(fknown[x->src]){ x->op=OP_FMOVI; x->imm=fk[x->src]; fknown[x->dst]=1; known[x->dst]=0; fk[x->dst]=fk[x->src]; }
            else { fknown[x->dst]=0; known[x->dst]=0; }
            continue;
        }
        if(x->op==OP_ADD||x->op==OP_SUB||x->op==OP_MUL||x->op==OP_DIV||x->op==OP_MOD||x->op==OP_AND||x->op==OP_OR||x->op==OP_XOR||x->op==OP_SHL||x->op==OP_SHR){
            if(known[x->dst]&&known[x->src]){
                uint64_t a=(uint64_t)ik[x->dst],b=(uint64_t)ik[x->src],v=0; int ok=1;
                switch(x->op){
                    case OP_ADD:v=a+b;break; case OP_SUB:v=a-b;break; case OP_MUL:v=a*b;break;
                    case OP_AND:v=a&b;break; case OP_OR:v=a|b;break; case OP_XOR:v=a^b;break;
                    case OP_SHL:if(b>63)ok=0;else v=a<<b;break; case OP_SHR:if(b>63)ok=0;else v=a>>b;break;
                    case OP_DIV:if(b==0||((int64_t)a==INT64_MIN&&(int64_t)b==-1))ok=0;else v=(uint64_t)((int64_t)a/(int64_t)b);break;
                    case OP_MOD:if(b==0||((int64_t)a==INT64_MIN&&(int64_t)b==-1))ok=0;else v=(uint64_t)((int64_t)a%(int64_t)b);break;
                    default:ok=0;break;
                }
                if(ok){ x->op=OP_MOVI; x->imm=v; known[x->dst]=1; fknown[x->dst]=0; ik[x->dst]=(int64_t)v; continue; }
            }
            if(x->op==OP_ADD && known[x->src] && ik[x->src]==0) { x->op=OP_MOV; known[x->dst]=known[x->src]; fknown[x->dst]=fknown[x->src]; ik[x->dst]=ik[x->src]; fk[x->dst]=fk[x->src]; continue; }
            if(x->op==OP_SUB && known[x->src] && ik[x->src]==0) { x->op=OP_MOV; known[x->dst]=known[x->src]; fknown[x->dst]=fknown[x->src]; ik[x->dst]=ik[x->src]; fk[x->dst]=fk[x->src]; continue; }
            if(x->op==OP_MUL && known[x->src] && ik[x->src]==1) { x->op=OP_MOV; known[x->dst]=1; fknown[x->dst]=0; continue; }
            if(x->op==OP_MUL && known[x->src] && ik[x->src]==0) { x->op=OP_MOVI; x->imm=0; known[x->dst]=1; fknown[x->dst]=0; ik[x->dst]=0; continue; }
            if(x->op==OP_OR && known[x->src] && ik[x->src]==0) { x->op=OP_MOV; continue; }
            if(x->op==OP_XOR && known[x->src] && ik[x->src]==0) { x->op=OP_MOVI; x->imm=0; known[x->dst]=1; fknown[x->dst]=0; ik[x->dst]=0; continue; }
            known[x->dst]=0; fknown[x->dst]=0; continue;
        }
        if(x->op==OP_FADD||x->op==OP_FSUB||x->op==OP_FMUL||x->op==OP_FDIV){
            if(fknown[x->dst]&&fknown[x->src]){
                double a=u64_to_f64(fk[x->dst]), b=u64_to_f64(fk[x->src]), r=0.0;
                switch(x->op){case OP_FADD:r=a+b;break;case OP_FSUB:r=a-b;break;case OP_FMUL:r=a*b;break;case OP_FDIV:r=a/b;break;default:break;}
                x->op=OP_FMOVI; x->imm=f64_to_u64(r); fk[x->dst]=x->imm; fknown[x->dst]=1; known[x->dst]=0; continue;
            }
            fknown[x->dst]=0; known[x->dst]=0; continue;
        }
        if(x->op==OP_BIT_GET){ known[x->dst]=0; fknown[x->dst]=0; continue; }
        if(x->op==OP_BIT_SET||x->op==OP_BIT_CLR||x->op==OP_BIT_TOG){ known[x->dst]=0; fknown[x->dst]=0; continue; }
        if(x->op==OP_CMP||x->op==OP_FCMP){ for(int r=0;r<16;r++){known[r]=fknown[r]=0;} continue; }
        if(barrier(x)){ for(int r=0;r<16;r++){known[r]=fknown[r]=0;} continue; }
    }
}
static void find_leaders(const Ins*c,size_t n,unsigned char*leader){leader[0]=1;for(size_t i=0;i<n;i++){if(branch(c[i].op)&&(c[i].imm<n))leader[c[i].imm]=1;if(branch(c[i].op)||terminator(c[i].op)){if(i+1<n)leader[i+1]=1;}}}
static void remove_nops(Ins*c,size_t*n){
    size_t old=*n,w=0;
    uint32_t *map=(uint32_t*)malloc(old*sizeof(*map));
    uint32_t *next=(uint32_t*)malloc((old+1)*sizeof(*next));
    if(!map||!next) die("out of memory while remapping branches");
    next[old]=(uint32_t)old;
    uint32_t live=(uint32_t)old;
    for(size_t r=old;r-->0;){
        if(c[r].op!=OP_NOP) live=(uint32_t)r;
        next[r]=live;
    }
    for(size_t r=0;r<old;r++){
        if(c[r].op!=OP_NOP) map[r]=(uint32_t)w++;
        else map[r]=UINT32_MAX;
    }
    for(size_t r=0;r<old;r++){
        if(c[r].op==OP_NOP) continue;
        Ins x=c[r];
        if(branch(x.op)){
            if(x.imm>=old){ free(map); free(next); die("invalid branch target before optimization"); }
            uint32_t target=next[x.imm];
            if(target>=old){ free(map); free(next); die("branch target fell past end"); }
            x.imm=map[target];
        }
        c[map[r]]=x;
    }
    *n=w;
    free(map);
    free(next);
}
static void verify_branch_targets(const Ins*c,size_t n){for(size_t i=0;i<n;i++)if(branch(c[i].op)&&c[i].imm>=n)die("invalid branch target after optimization");}
int main(int ac,char**av){
    if(ac<3){fprintf(stderr,"usage: asmthon-opt in.avm out.avm\n");return 2;}
    FILE*fi=fopen(av[1],"rb");if(!fi)die("cannot open input");unsigned char h[16];if(fread(h,1,16,fi)!=16||memcmp(h,"ASMV",4))die("bad input");uint64_t n64;memcpy(&n64,h+8,8);if(!n64||n64>MAX_CODE)die("too much code");size_t n=(size_t)n64;Ins c[MAX_CODE];if(fread(c,sizeof(Ins),n,fi)!=n)die("short input");fclose(fi);
    for(int pass=0;pass<12;pass++){
        unsigned char leader[MAX_CODE];memset(leader,0,sizeof(leader));find_leaders(c,n,leader);
        size_t start=0;for(size_t i=1;i<=n;i++){if(i==n||leader[i]){optimize_block(c,start,i);start=i;}}
        remove_nops(c,&n);verify_branch_targets(c,n);
        int changed=0;for(size_t i=0;i<n;i++){if(c[i].op==OP_MOV&&c[i].dst==c[i].src){c[i].op=OP_NOP;changed=1;}}
        if(!changed)break;
        remove_nops(c,&n);
    }
    verify_branch_targets(c,n);
    memcpy(h+8,&n,8);FILE*fo=fopen(av[2],"wb");if(!fo)die("cannot open output");fwrite(h,1,16,fo);fwrite(c,sizeof(Ins),n,fo);fclose(fo);return 0;
}
