#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
./build.sh >/dev/null
for n in $(seq 1 200); do
  a=$((n*37-91))
  b=$((n*13+7))
  cat > /tmp/asmthon_stress.asmthon <<SRC
fn main():
    a = $a
    b = $b
    x = a * 3 + b * 2 - 7
    if x >= 0:
        print(x)
    else:
        print(0 - x)
    return 0
SRC
  ./asmthonc /tmp/asmthon_stress.asmthon /tmp/asmthon_stress.avm >/dev/null
  ./asmthon-vm /tmp/asmthon_stress.avm >/tmp/asmthon_stress.out
  ./asmthon-opt /tmp/asmthon_stress.avm /tmp/asmthon_stress_opt.avm >/dev/null
  ./asmthon-vm /tmp/asmthon_stress_opt.avm >/tmp/asmthon_stress_opt.out
  cmp /tmp/asmthon_stress.out /tmp/asmthon_stress_opt.out
done
printf 'STRESS PASS\n'
