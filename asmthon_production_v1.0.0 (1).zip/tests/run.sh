#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
./build.sh
./asmthonc tests/final_smoke.asmthon /tmp/asmthon_test.avm
./asmthon-vm /tmp/asmthon_test.avm > /tmp/asmthon_vm.out
./asmthon-opt /tmp/asmthon_test.avm /tmp/asmthon_opt.avm
./asmthon-vm /tmp/asmthon_opt.avm > /tmp/asmthon_opt.out
cmp /tmp/asmthon_vm.out /tmp/asmthon_opt.out
./asmthon-ssa /tmp/asmthon_opt.avm >/tmp/asmthon.ssa
./asmthon-arm64 /tmp/asmthon_opt.avm /tmp/asmthon.arm64.s
./asmthon-riscv64 /tmp/asmthon_opt.avm /tmp/asmthon.riscv64.s
test "$(cat /tmp/asmthon_vm.out)" = "50"
./asmthonc tests/f64.asmthon /tmp/asmthon_f64.avm
./asmthon-vm /tmp/asmthon_f64.avm > /tmp/asmthon_f64_vm.out
./avm2native /tmp/asmthon_f64.avm /tmp/asmthon_f64.s
cc -nostartfiles -no-pie /tmp/asmthon_f64.s -lc -o /tmp/asmthon_f64.native
/tmp/asmthon_f64.native > /tmp/asmthon_f64_native.out
cmp /tmp/asmthon_f64_vm.out /tmp/asmthon_f64_native.out
./asmthonc tests/ssa_loop.asmthon /tmp/asmthon_ssa_loop.avm
./asmthon-ssa /tmp/asmthon_ssa_loop.avm >/tmp/asmthon_ssa_loop.out
grep -q 'phi %r0' /tmp/asmthon_ssa_loop.out
printf "6\n1\n" | cmp - /tmp/asmthon_f64_vm.out
./asmthonc tests/host_runtime.asmthon /tmp/asmthon_host_runtime.avm
./asmthon-vm /tmp/asmthon_host_runtime.avm tests/host_runtime.asmthon > /tmp/asmthon_host_runtime.out
test "$(cat /tmp/asmthon_host_runtime.out)" = "106"
./asmthonc bootstrap/emit42.asmthon /tmp/asmthon_bootstrap.avm
./asmthon-vm /tmp/asmthon_bootstrap.avm placeholder /tmp/asmthon_generated.avm
./asmthon-vm /tmp/asmthon_generated.avm > /tmp/asmthon_generated.out
test "$(cat /tmp/asmthon_generated.out)" = "42"
printf 'PASS\n'
