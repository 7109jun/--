#!/usr/bin/env bash
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"

cc -std=c11 -O3 -Wall -Wextra -Wpedantic -Werror asmthonc.c -o asmthonc
cc -std=c11 -O3 -Wall -Wextra -Wpedantic -Werror avm2native.c -o avm2native
as --64 asmthon_vm.s -o asmthon_vm.o
gcc -nostartfiles -no-pie asmthon_vm.o -lc -o asmthon-vm

run_case() {
    local name="$1" src="$2"
    local avm="/tmp/asmthon_${name}.avm"
    local asms="/tmp/asmthon_${name}.s"
    local obj="/tmp/asmthon_${name}.o"
    local exe="/tmp/asmthon_${name}.native"
    ./asmthonc "$src" "$avm"
    ./asmthon-vm "$avm" > "/tmp/asmthon_${name}.vm"
    ./avm2native "$avm" "$asms"
    as --64 "$asms" -o "$obj"
    gcc -nostartfiles -no-pie "$obj" -lc -o "$exe"
    "$exe" > "/tmp/asmthon_${name}.native.out"
    diff -u "/tmp/asmthon_${name}.vm" "/tmp/asmthon_${name}.native.out"
    echo "PASS $name"
}

cat >/tmp/asmthon_basic.asmthon <<'SRC'
fn main():
    x = 10 + 20 * 2
    print(x)
    return x
SRC
run_case basic /tmp/asmthon_basic.asmthon

cat >/tmp/asmthon_struct.asmthon <<'SRC'
struct Point:
    dword x
    dword y

fn main():
    struct Point p
    p.x = 10
    p.y = 20
    p.x += 5
    print(p.x + p.y)
    return 0
SRC
run_case struct /tmp/asmthon_struct.asmthon

cat >/tmp/asmthon_ptr.asmthon <<'SRC'
fn main():
    dword a[2]
    a[0] = 7
    ptr p = &a[0]
    *p = 99
    print(a[0])
    return 0
SRC
run_case pointer /tmp/asmthon_ptr.asmthon

cat >/tmp/asmthon_string.asmthon <<'SRC'
fn main():
    string s = "ABC"
    print(s[0])
    print(s[1])
    print(s)
    return 0
SRC
run_case string /tmp/asmthon_string.asmthon

cat >/tmp/asmthon_control.asmthon <<'SRC'
fn main():
    i = 0
    while i < 3:
        print(i)
        i += 1
    if i == 3:
        print(99)
    else:
        print(0)
    return i
SRC
run_case control /tmp/asmthon_control.asmthon

cat >/tmp/asmthon_recursive.asmthon <<'SRC'
fn fact(n):
    if n <= 1:
        return 1
    return n * fact(n - 1)

fn main():
    print(fact(6))
    return 0
SRC
run_case recursion /tmp/asmthon_recursive.asmthon

cat >/tmp/asmthon_typed.asmthon <<'SRC'
fn add(i32 a, qword b):
    return a + b
fn main():
    byte a = 5
    word b = 10
    dword c = 15
    qword d = 20
    bool ok = 1
    print(add(a+b, c+d+ok))
    return 0
SRC
run_case typed /tmp/asmthon_typed.asmthon

cat >/tmp/asmthon_type_error.asmthon <<'SRC'
fn main():
    ptr p = 123
    return 0
SRC
if ./asmthonc /tmp/asmthon_type_error.asmthon /tmp/bad.avm 2>/tmp/bad.log; then
    echo "FAIL type-diagnostic" >&2
    exit 1
fi
grep -Eq '2:5: ptr variable requires an address value' /tmp/bad.log
echo "PASS type-diagnostic"

echo "ALL PASS"


cat >/tmp/asmthon_f64.asmthon <<'SRC'
fn main():
    f64 x = 1.5
    f64 y = 2.25
    f64 z = x + y * 2.0
    print(z)
    return 0
SRC
run_case f64 /tmp/asmthon_f64.asmthon
