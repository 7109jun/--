#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>

#define MAX_CODE 8192
#define MAX_FUNCS 128
#define MAX_VARS 14
#define MAX_ARRAYS 256
#define MAX_STRINGS 256
#define VM_MEMORY_SIZE 65536
#define MAX_NODES 65536
#define INSTR_SIZE 16

enum {OP_NOP,OP_MOVI,OP_MOV,OP_ADD,OP_SUB,OP_MUL,OP_DIV,OP_MOD,OP_AND,OP_OR,OP_XOR,OP_SHL,OP_SHR,OP_CMP,OP_JMP,OP_JZ,OP_JNZ,OP_JG,OP_JL,OP_JGE,OP_JLE,OP_PUSH,OP_POP,OP_LOAD,OP_STORE,OP_CALL,OP_RET,OP_BIT_GET,OP_BIT_SET,OP_BIT_CLR,OP_BIT_TOG,OP_PRINT,OP_PRINT_STR,OP_FMOVI,OP_FMOV,OP_FADD,OP_FSUB,OP_FMUL,OP_FDIV,OP_FCMP,OP_FPRINT,OP_HALT,OP_HOST_ARG,OP_HOST_READ_FILE,OP_HOST_STRLEN,OP_HOST_BC_RESET,OP_HOST_BC_EMIT,OP_HOST_BC_SET_IMM,OP_HOST_BC_SAVE};
enum {K_NUM=1,K_VAR,K_BIN,K_BIT,K_MEM,K_CALL,K_BITS,K_STR,K_ADDR,K_FNUM};

typedef struct Node Node;
struct Node { int k, op, a, b; int64_t v; };

typedef struct { unsigned char op,dst,src,res; uint64_t imm; } Ins;

typedef enum { TY_UNKNOWN=0, TY_BOOL, TY_I8, TY_I16, TY_I32, TY_I64, TY_U8, TY_U16, TY_U32, TY_U64, TY_PTR, TY_STRING, TY_F64 } TypeKind;
typedef struct { TypeKind kind; int pointee; } TypeInfo;
typedef struct { char name[32]; int reg; TypeKind type; } Var;
typedef struct { char name[32]; size_t line; size_t entry; int nparam; char params[8][32]; } Func;
typedef struct { char name[32]; int base, elem, len; } Array;
typedef struct { char *data; size_t len; int base, initialized; } Str;
typedef struct { char name[32]; int off, size, align; } Field;
typedef struct { char name[32]; int size, align, nf; Field fields[32]; } StructDef;
typedef struct { char name[32]; int base, def; } StructVar;

typedef struct { const char *s; size_t p,n; int error_line; int error_col; Node nodes[MAX_NODES]; int nn; Var vars[MAX_VARS]; int nv; Array arrays[MAX_ARRAYS]; int na; Str strings[MAX_STRINGS]; int ns; StructDef structs[64]; int nstructs; StructVar svars[128]; int nsv; int data_cursor; int call_args[MAX_NODES]; int call_argc; Ins code[MAX_CODE]; size_t cc; int labels[MAX_CODE]; size_t nl; int *patch_at,*patch_label; size_t pcnt; int next_label; Func funcs[MAX_FUNCS]; int nf; } Ctx;

static void die(const char *m){ fprintf(stderr,"Asmthon compiler error: %s\n",m); exit(1); }
static void cdie(Ctx*c,const char*m){ if(c&&c->error_line>0) fprintf(stderr,"Asmthon compiler error:%d:%d: %s\n",c->error_line,c->error_col>0?c->error_col:1,m); else fprintf(stderr,"Asmthon compiler error: %s\n",m); exit(1); }
static int align_up(int x,int a){ return (x+a-1)&~(a-1); }
static Node *num(Ctx*,int64_t);
static Node *memn(Ctx*,Node*,int);
static int find_array(Ctx*c,const char*n){ for(int i=0;i<c->na;i++) if(!strcmp(c->arrays[i].name,n)) return i; return -1; }
static int type_size(const char*t){ if(!strcmp(t,"byte"))return 1; if(!strcmp(t,"word"))return 2; if(!strcmp(t,"dword"))return 4; if(!strcmp(t,"qword"))return 8; return 0; }
static TypeKind parse_type_name(const char*t){
    if(!strcmp(t,"bool")) return TY_BOOL;
    if(!strcmp(t,"byte")||!strcmp(t,"i8")) return TY_I8;
    if(!strcmp(t,"word")||!strcmp(t,"i16")) return TY_I16;
    if(!strcmp(t,"dword")||!strcmp(t,"i32")||!strcmp(t,"int")) return TY_I32;
    if(!strcmp(t,"qword")||!strcmp(t,"i64")||!strcmp(t,"uint64")) return TY_I64;
    if(!strcmp(t,"u8")) return TY_U8;
    if(!strcmp(t,"u16")) return TY_U16;
    if(!strcmp(t,"u32")) return TY_U32;
    if(!strcmp(t,"u64")) return TY_U64;
    if(!strcmp(t,"ptr")) return TY_PTR;
    if(!strcmp(t,"string")) return TY_STRING;
    if(!strcmp(t,"f64")||!strcmp(t,"double")) return TY_F64;
    return TY_UNKNOWN;
}
static int type_size_kind(TypeKind t){ switch(t){ case TY_BOOL:case TY_I8:case TY_U8:return 1; case TY_I16:case TY_U16:return 2; case TY_I32:case TY_U32:return 4; case TY_I64:case TY_U64:case TY_PTR:case TY_STRING:case TY_F64:return 8; default:return 8; } }
static int iscmp(int op);
static int type_is_integer(TypeKind t){ return t==TY_BOOL||t==TY_I8||t==TY_I16||t==TY_I32||t==TY_I64||t==TY_U8||t==TY_U16||t==TY_U32||t==TY_U64; }
static TypeKind node_type(Ctx*c,int id){
    Node*n=&c->nodes[id];
    switch(n->k){
        case K_NUM: return TY_I64;
        case K_FNUM: return TY_F64;
        case K_STR: return TY_STRING;
        case K_ADDR: return TY_PTR;
        case K_VAR: return c->vars[n->v].type;
        case K_BIT: case K_BITS: return TY_U64;
        case K_MEM: switch(n->v){case 1:return TY_I8;case 2:return TY_I16;case 4:return TY_I32;default:return TY_I64;}
        case K_CALL: { int f=(int)n->v; if(f==-1||f==-2||f==-3) return TY_PTR; return TY_I64; }
        case K_BIN: if(iscmp(n->op)) return TY_BOOL; { TypeKind a=node_type(c,n->a), b=node_type(c,n->b); return (a==TY_F64||b==TY_F64)?TY_F64:TY_I64; }
        default: return TY_UNKNOWN;
    }
}
static void check_assignment_type(Ctx*c,TypeKind dst,TypeKind src){
    if(dst==TY_UNKNOWN||src==TY_UNKNOWN) return;
    if(dst==TY_STRING){ if(src!=TY_STRING) cdie(c,"string variable requires a string value"); return; }
    if(dst==TY_PTR){ if(src!=TY_PTR) cdie(c,"ptr variable requires an address value"); return; }
    if(dst==TY_F64){ if(src!=TY_F64) cdie(c,"f64 variable requires an f64 value"); return; }
    if(type_is_integer(dst) && type_is_integer(src)) return;
    cdie(c,"incompatible assignment types");
}
static int find_var_raw(Ctx*c,const char*n){ for(int i=0;i<c->nv;i++) if(!strcmp(c->vars[i].name,n)) return c->vars[i].reg; return -1; }
static int declare_var(Ctx*c,const char*n,TypeKind ty){
    int old=find_var_raw(c,n); if(old>=0){ if(c->vars[old].type!=ty && c->vars[old].type!=TY_UNKNOWN && ty!=TY_UNKNOWN) cdie(c,"conflicting variable type"); return old; }
    if(c->nv>=MAX_VARS) cdie(c,"too many variables");
    int r=c->nv++; snprintf(c->vars[r].name,sizeof(c->vars[r].name),"%s",n); c->vars[r].reg=r; c->vars[r].type=ty; return r;
}
static int find_struct(Ctx*c,const char*n){ for(int i=0;i<c->nstructs;i++) if(!strcmp(c->structs[i].name,n)) return i; return -1; }
static int find_struct_field(Ctx*c,int si,const char*n){ if(si<0||si>=c->nstructs)return -1; for(int i=0;i<c->structs[si].nf;i++) if(!strcmp(c->structs[si].fields[i].name,n)) return i; return -1; }
static int find_svar(Ctx*c,const char*n){ for(int i=0;i<c->nsv;i++) if(!strcmp(c->svars[i].name,n)) return i; return -1; }
static int add_struct_var(Ctx*c,const char*n,int si){ if(si<0)die("unknown struct"); if(find_svar(c,n)>=0)die("duplicate struct variable"); if(c->nsv>=128)die("too many struct variables"); StructDef*d=&c->structs[si]; c->data_cursor=align_up(c->data_cursor,d->align); if(c->data_cursor+d->size>VM_MEMORY_SIZE)die("VM memory exhausted"); int i=c->nsv++; size_t NL=strlen(n); if(NL>=sizeof(c->svars[i].name))die("struct variable name too long"); memcpy(c->svars[i].name,n,NL+1); c->svars[i].base=c->data_cursor; c->svars[i].def=si; c->data_cursor+=d->size; return i; }
static Node *struct_field_node(Ctx*c,const char*obj,const char*field){ int vi=find_svar(c,obj); if(vi<0) return NULL; int fi=find_struct_field(c,c->svars[vi].def,field); if(fi<0)die("unknown struct field"); int addr=c->svars[vi].base+c->structs[c->svars[vi].def].fields[fi].off; Node*an=num(c,addr); return memn(c,an,c->structs[c->svars[vi].def].fields[fi].size); }
static int struct_field_addr(Ctx*c,const char*obj,const char*field,int*size_out){ int vi=find_svar(c,obj); if(vi<0)return -1; int fi=find_struct_field(c,c->svars[vi].def,field); if(fi<0)die("unknown struct field"); Field*f=&c->structs[c->svars[vi].def].fields[fi]; if(size_out)*size_out=f->size; return c->svars[vi].base+f->off; }
static int add_array(Ctx*c,const char*n,int elem,int len){
    if(len<=0) die("invalid array length");
    if(c->na>=MAX_ARRAYS) die("too many arrays");
    if(find_array(c,n)>=0) die("duplicate array");
    c->data_cursor=align_up(c->data_cursor,elem);
    if(c->data_cursor+elem*len>VM_MEMORY_SIZE) die("VM memory exhausted");
    int i=c->na++;
    snprintf(c->arrays[i].name,sizeof(c->arrays[i].name),"%s",n);
    c->arrays[i].base=c->data_cursor; c->arrays[i].elem=elem; c->arrays[i].len=len;
    c->data_cursor+=elem*len; return i;
}
static int add_string(Ctx*c,const char*raw,int len){
    char *buf=(char*)malloc((size_t)len+1); if(!buf) die("out of memory"); int j=0;
    for(int i=0;i<len;i++){
        unsigned char ch=(unsigned char)raw[i];
        if(ch=='\\' && i+1<len){ unsigned char e=(unsigned char)raw[++i]; if(e=='n')ch=10;else if(e=='t')ch=9;else if(e=='r')ch=13;else ch=e; }
        buf[j++]=(char)ch;
    }
    buf[j]=0;
    for(int i=0;i<c->ns;i++) if(c->strings[i].len==(size_t)j && !memcmp(c->strings[i].data,buf,(size_t)j+1)){ free(buf); return i; }
    if(c->ns>=MAX_STRINGS) die("too many strings");
    if(c->data_cursor+j+1>VM_MEMORY_SIZE) die("VM memory exhausted");
    int idx=c->ns++; c->strings[idx].data=buf;c->strings[idx].len=(size_t)j;c->strings[idx].base=c->data_cursor;c->strings[idx].initialized=0;c->data_cursor+=j+1; return idx;
}
static Node *node(Ctx*c,int k){ if(c->nn>=MAX_NODES) die("AST overflow"); Node*n=&c->nodes[c->nn++]; memset(n,0,sizeof(*n)); n->k=k; return n; }
static Node *num(Ctx*c,int64_t v){ Node*n=node(c,K_NUM); n->v=v; return n; }
static Node *fnum(Ctx*c,double v){ Node*n=node(c,K_FNUM); uint64_t bits=0; memcpy(&bits,&v,8); n->v=(int64_t)bits; return n; }

static int find_var(Ctx*c,const char*n){ int r=find_var_raw(c,n); return r>=0?r:declare_var(c,n,TY_UNKNOWN); }
static Node *var(Ctx*c,const char*n){ Node*x=node(c,K_VAR); x->v=find_var(c,n); return x; }
static Node *bin(Ctx*c,int op,Node*a,Node*b){ Node*n=node(c,K_BIN); n->op=op; n->a=(int)(a-c->nodes); n->b=(int)(b-c->nodes); return n; }
static Node *bitn(Ctx*c,const char*n,int bit){ Node*x=node(c,K_BIT); x->v=find_var(c,n); x->a=bit; return x; }
static Node *memn(Ctx*c,Node*a,int size){ Node*x=node(c,K_MEM); x->a=(int)(a-c->nodes); x->v=size; return x; }
static Node *strn(Ctx*c,int idx){ Node*x=node(c,K_STR); x->v=idx; return x; }
static Node *addrn(Ctx*c,int base,Node*idx,int elem){ Node*x=node(c,K_ADDR); x->v=base; x->a=(int)(idx-c->nodes); x->b=elem; return x; }
static Node *array_addr_node(Ctx*c,const char*n,Node*idx){ int ai=find_array(c,n); if(ai<0) cdie(c,"unknown array"); return addrn(c,c->arrays[ai].base,idx,c->arrays[ai].elem); }
static int builtin_id(const char*n){
    if(!strcmp(n,"host_arg")) return -1;
    if(!strcmp(n,"host_read_file")) return -2;
    if(!strcmp(n,"host_strlen")) return -3;
    if(!strcmp(n,"host_bc_reset")) return -4;
    if(!strcmp(n,"host_bc_emit")) return -5;
    if(!strcmp(n,"host_bc_set_imm")) return -6;
    if(!strcmp(n,"host_bc_save")) return -7;
    return -9999;
}
static int find_func(Ctx*c,const char*n){ for(int i=0;i<c->nf;i++) if(!strcmp(c->funcs[i].name,n)) return i; return builtin_id(n); }

static void skip(const char*s,size_t*n,size_t end){ while(*n<end && isspace((unsigned char)s[*n])) (*n)++; }
static Node *parse_expr(Ctx*, const char*, size_t*, size_t, int);


static Node *parse_atom(Ctx*c,const char*s,size_t*p,size_t end){
    skip(s,p,end);
    if(*p>=end) die("unexpected end of expression");
    if(s[*p]=='('){ (*p)++; Node*n=parse_expr(c,s,p,end,0); skip(s,p,end); if(*p>=end||s[*p]!=')') die("missing )"); (*p)++; return n; }
    if(s[*p]=='"'){
        size_t st=++(*p); while(*p<end && s[*p]!='"'){ if(s[*p]=='\\' && *p+1<end) (*p)++; (*p)++; }
        if(*p>=end) die("unterminated string");
        int si=add_string(c,s+st,(int)(*p-st)); (*p)++; return strn(c,si);
    }
    if(s[*p]=='&'){
        (*p)++; skip(s,p,end); if(!isalpha((unsigned char)s[*p])&&s[*p]!='_') die("& expects lvalue");
        size_t st=*p; while(*p<end&&(isalnum((unsigned char)s[*p])||s[*p]=='_'))(*p)++; char name[64]; size_t L=*p-st;if(L>63)L=63;memcpy(name,s+st,L);name[L]=0;
        skip(s,p,end);
        if(*p<end&&s[*p]=='['){ (*p)++; size_t ip=*p,close=ip,depth=1; while(close<end&&depth){if(s[close]=='[')depth++;else if(s[close]==']')depth--;close++;} if(depth)die("missing ]"); Node*ix=parse_expr(c,s,&ip,close-1,0); *p=close; return array_addr_node(c,name,ix); }
        if(*p<end&&s[*p]=='.'){ (*p)++; size_t fs=*p; while(*p<end&&(isalnum((unsigned char)s[*p])||s[*p]=='_'))(*p)++; char field[64]; size_t FL=*p-fs;if(FL>63)FL=63;memcpy(field,s+fs,FL);field[FL]=0; int sz=0,addr=struct_field_addr(c,name,field,&sz); if(addr<0)die("unknown address target"); return addrn(c,addr,num(c,0),1); }
        die("& expects array[index] or struct field");
    }
    if(s[*p]=='*'){
        (*p)++; Node*base=parse_atom(c,s,p,end); return memn(c,base,8);
    }
    if(s[*p]=='-' || s[*p]=='~'){
        char op=s[(*p)++]; Node*a=parse_atom(c,s,p,end); if(op=='-') return bin(c,OP_SUB,num(c,0),a); return bin(c,OP_XOR,a,num(c,-1));
    }
    if(isdigit((unsigned char)s[*p])){
        char buf[64]; size_t j=0; int isfloat=0;
        while(*p<end){ char ch=s[*p];
            if(isdigit((unsigned char)ch)||ch=='.'||ch=='e'||ch=='E'||ch=='+'||ch=='-'||ch=='x'||ch=='X'||(ch>='a'&&ch<='f')||(ch>='A'&&ch<='F')){
                if(ch=='.'||ch=='e'||ch=='E') isfloat=1;
                if(j<63) buf[j++]=ch;
                (*p)++;
                if((ch=='+'||ch=='-') && j>1 && buf[j-2]!='e' && buf[j-2]!='E') break;
                continue;
            }
            break;
        }
        buf[j]=0;
        if(isfloat){ char*e; double v=strtod(buf,&e); if(*e) die("bad f64 literal"); return fnum(c,v); }
        char*e; long long v=strtoll(buf,&e,0); if(*e) die("bad number"); return num(c,v);
    }
    if(isalpha((unsigned char)s[*p])||s[*p]=='_'){
        size_t st=*p; while(*p<end && (isalnum((unsigned char)s[*p])||s[*p]=='_'))(*p)++; char name[64]; size_t L=*p-st; if(L>63)L=63; memcpy(name,s+st,L);name[L]=0;
        size_t q=*p; skip(s,&q,end);
        if(strcmp(name,"memory") && q<end && s[q]=='.' && q+1<end && strncmp(s+q,".bit[",5) && strncmp(s+q,".bits[",6)){
            q++; size_t fs=q; while(q<end&&(isalnum((unsigned char)s[q])||s[q]=='_'))q++; char field[64]; size_t FL=q-fs;if(FL>63)FL=63;memcpy(field,s+fs,FL);field[FL]=0; Node*fn=struct_field_node(c,name,field); if(!fn)die("unknown struct object"); *p=q; return fn;
        }
        if(q<end && s[q]=='['){
            size_t ip=q+1,close=ip,depth=1; while(close<end&&depth){if(s[close]=='[')depth++;else if(s[close]==']')depth--;close++;} if(depth)die("missing ]");
            int ai=find_array(c,name); Node*ix=parse_expr(c,s,&ip,close-1,0); *p=close;
            if(ai>=0){ Node*addr=array_addr_node(c,name,ix); return memn(c,addr,c->arrays[ai].elem); }
            int vr=find_var_raw(c,name); if(vr>=0 && c->vars[vr].type==TY_STRING){ Node*base=var(c,name); 
                Node*sum=bin(c,OP_ADD,base,ix); return memn(c,sum,1); }
            cdie(c,"unknown array or string");
        }
        if(q<end && s[q]=='('){
            q++; int start=c->call_argc, count=0; skip(s,&q,end);
            if(q<end && s[q]!=')'){
                while(1){ size_t ap=q; Node*arg=parse_expr(c,s,&ap,end,0); if(c->call_argc>=MAX_NODES)die("too many call arguments"); c->call_args[c->call_argc++]=(int)(arg-c->nodes); count++; q=ap; skip(s,&q,end); if(q<end&&s[q]==','){q++;skip(s,&q,end);continue;} break; }
            }
            if(q>=end||s[q]!=')') { cdie(c,"missing ) after arguments"); } q++; int f=find_func(c,name); if(f==-9999)cdie(c,"unknown function"); if(count>8)cdie(c,"too many call arguments");
            if(f>=0 && count!=c->funcs[f].nparam)cdie(c,"wrong function argument count");
            int want=-1;
            if(f==-1) want=1; else if(f==-2) want=1; else if(f==-3) want=1; else if(f==-4) want=0; else if(f==-5) want=4; else if(f==-6) want=2; else if(f==-7) want=1;
            if(want>=0 && count!=want) cdie(c,"wrong builtin argument count");
            Node*x=node(c,K_CALL);x->v=f;x->a=start;x->b=count;*p=q;return x;
        }
        if(q+5<end && s[q]=='.' && !strncmp(s+q,".bit[",5)){ q+=5; int bit=0; while(q<end&&isdigit((unsigned char)s[q])){bit=bit*10+s[q]-'0';q++;} if(q>=end||s[q]!=']'||bit>63) die("bad bit index"); *p=q+1; return bitn(c,name,bit); }
        if(q+6<end && s[q]=='.' && !strncmp(s+q,".bits[",6)){
            q+=6; int lo=0,hi=0; while(q<end&&isdigit((unsigned char)s[q])){lo=lo*10+s[q]-'0';q++;}
            if(q+1>=end||s[q]!=':') die("bad bits range");
            q++; while(q<end&&isdigit((unsigned char)s[q])){hi=hi*10+s[q]-'0';q++;}
            if(q>=end||s[q]!=']'||lo<0||hi>64||lo>=hi) die("bad bits range");
            Node*x=node(c,K_BITS);x->v=find_var(c,name);x->a=lo;x->b=hi;*p=q+1;return x;
        }
        if(!strcmp(name,"memory")){ size_t r=q; if(r<end&&s[r]=='.'){
                r++; const char*sizes[]={"byte","word","dword","qword"}; int szs[]={1,2,4,8}; int found=0,sz=0; for(int k=0;k<4;k++){size_t L2=strlen(sizes[k]);if(r+L2<end&&!strncmp(s+r,sizes[k],L2)){r+=L2;found=1;sz=szs[k];break;}} if(found&&r<end&&s[r]=='['){r++; size_t close=r,depth=1; while(close<end&&depth){if(s[close]=='[')depth++; else if(s[close]==']')depth--; close++;} if(depth) die("missing ]"); Node*a=parse_expr(c,s,&r,close-1,0); *p=close; return memn(c,a,sz); }
            }
        }
        *p=q; return var(c,name);
    }
    die("invalid expression"); return NULL;
}


static int op_prec(const char *s,size_t p,size_t end,int*op,int*len){
    if(p+2<=end){ if(!strncmp(s+p,"==",2)){*op=1001;*len=2;return 10;} if(!strncmp(s+p,"!=",2)){*op=1002;*len=2;return 10;} if(!strncmp(s+p,"<=",2)){*op=1004;*len=2;return 10;} if(!strncmp(s+p,">=",2)){*op=1006;*len=2;return 10;} if(!strncmp(s+p,"<<",2)){*op=OP_SHL;*len=2;return 50;} if(!strncmp(s+p,">>",2)){*op=OP_SHR;*len=2;return 50;} }
    switch(s[p]){case '<':*op=1003;*len=1;return 10;case '>':*op=1005;*len=1;return 10;case '|':*op=OP_OR;*len=1;return 20;case '^':*op=OP_XOR;*len=1;return 30;case '&':*op=OP_AND;*len=1;return 40;case '+':*op=OP_ADD;*len=1;return 60;case '-':*op=OP_SUB;*len=1;return 60;case '*':*op=OP_MUL;*len=1;return 70;case '/':*op=OP_DIV;*len=1;return 70;case '%':*op=OP_MOD;*len=1;return 70;default:return -1;}
}
static Node *parse_expr(Ctx*c,const char*s,size_t*p,size_t end,int minp){ Node*left=parse_atom(c,s,p,end); for(;;){skip(s,p,end); if(*p>=end)break;int op,len,pr=op_prec(s,*p,end,&op,&len);if(pr<minp)break;*p+=len;Node*right=parse_expr(c,s,p,end,pr+1);left=bin(c,op,left,right);}return left;}

static int iscmp(int op){return op>=1001&&op<=1006;}
static int64_t fold_eval(int op,int64_t a,int64_t b,int*ok){*ok=1;switch(op){case OP_ADD:return a+b;case OP_SUB:return a-b;case OP_MUL:return a*b;case OP_DIV:if(!b){*ok=0;return 0;}return a/b;case OP_MOD:if(!b){*ok=0;return 0;}return a%b;case OP_AND:return a&b;case OP_OR:return a|b;case OP_XOR:return a^b;case OP_SHL:if(b<0||b>63){*ok=0;return 0;}return (uint64_t)a<<b;case OP_SHR:if(b<0||b>63){*ok=0;return 0;}return (uint64_t)a>>b;case 1001:return a==b;case 1002:return a!=b;case 1003:return a<b;case 1004:return a<=b;case 1005:return a>b;case 1006:return a>=b;default:*ok=0;return 0;}}
static int opt(Ctx*c,int id){
    Node*n=&c->nodes[id];
    if(n->k==K_BIN){
        n->a=opt(c,n->a); n->b=opt(c,n->b);
        Node*a=&c->nodes[n->a],*b=&c->nodes[n->b];
        if(a->k==K_NUM&&b->k==K_NUM){int ok;int64_t v=fold_eval(n->op,a->v,b->v,&ok);if(ok){n->k=K_NUM;n->v=v;return id;}}
        if((n->op==OP_ADD||n->op==OP_SUB||n->op==OP_OR||n->op==OP_XOR||n->op==OP_SHL||n->op==OP_SHR)&&b->k==K_NUM&&b->v==0)return n->a;
        if((n->op==OP_MUL||n->op==OP_DIV)&&b->k==K_NUM&&b->v==1)return n->a;
        if((n->op==OP_AND)&&b->k==K_NUM&&b->v==-1)return n->a;
        if(n->op==OP_MUL && b->k==K_NUM && b->v==0){ n->k=K_NUM; n->v=0; return id; }
        if((n->op==OP_ADD||n->op==OP_OR)&&a->k==K_NUM&&a->v==0)return n->b;
        if(n->op==OP_XOR&&a->k==K_NUM&&a->v==0)return n->b;
        if(n->op==1001&&a->k==K_NUM&&b->k==K_NUM)return id;
        if(n->op==1001&&a->k==b->k&&a->k==K_VAR&&a->v==b->v){n->k=K_NUM;n->v=1;return id;}
        if(n->op==1002&&a->k==K_VAR&&b->k==K_VAR&&a->v==b->v){n->k=K_NUM;n->v=0;return id;}
    } else if(n->k==K_MEM || n->k==K_ADDR) {
        n->a=opt(c,n->a);
    } else if(n->k==K_BIT || n->k==K_BITS) {
        return id;
    }
    return id;
}

static size_t emit(Ctx*c,int op,int dst,int src,uint64_t imm){ if(c->cc>=MAX_CODE)die("bytecode overflow"); Ins*i=&c->code[c->cc++];i->op=op;i->dst=dst;i->src=src;i->res=0;i->imm=imm;return c->cc-1; }
static int label(Ctx*c){int id=c->next_label++; if(id>=MAX_CODE)die("too many labels"); c->labels[id]=-1; return id;}
static void mark(Ctx*c,int l){c->labels[l]=(int)c->cc;}
static void patch_add(Ctx*c,size_t at,int l){if(c->pcnt>=MAX_CODE)die("too many patches");c->patch_at=(int*)realloc(c->patch_at,(c->pcnt+1)*sizeof(int));c->patch_label=(int*)realloc(c->patch_label,(c->pcnt+1)*sizeof(int));c->patch_at[c->pcnt]=(int)at;c->patch_label[c->pcnt]=l;c->pcnt++;}

static int scratch(int target){return target==14?15:14;}
static void emit_string_init(Ctx*c,int si){ Str*s=&c->strings[si]; if(s->initialized)return; int ar=14,vr=15; emit(c,OP_MOVI,ar,0,(uint64_t)s->base); for(size_t i=0;i<=s->len;i++){emit(c,OP_MOVI,vr,0,(uint64_t)(unsigned char)s->data[i]);emit(c,OP_STORE,ar,vr,1);if(i<s->len){emit(c,OP_MOVI,vr,0,1);emit(c,OP_ADD,ar,vr,0);}} s->initialized=1; }
static void expr(Ctx*c,int id,int target){Node*n=&c->nodes[id];switch(n->k){case K_NUM:emit(c,OP_MOVI,target,0,(uint64_t)n->v);break;case K_FNUM:emit(c,OP_FMOVI,target,0,(uint64_t)n->v);break;case K_VAR:if((int)n->v!=target){if(c->vars[n->v].type==TY_F64)emit(c,OP_FMOV,target,(int)n->v,0);else emit(c,OP_MOV,target,(int)n->v,0);}break;case K_STR:emit_string_init(c,(int)n->v);emit(c,OP_MOVI,target,0,(uint64_t)c->strings[n->v].base);break;case K_ADDR:{int s=scratch(target);expr(c,n->a,s);if(n->b!=1){emit(c,OP_MOVI,target,0,(uint64_t)n->b);emit(c,OP_MUL,s,target,0);}emit(c,OP_MOVI,target,0,(uint64_t)n->v);emit(c,OP_ADD,target,s,0);break;}case K_BIT:emit(c,OP_BIT_GET,target,(int)n->v,(uint64_t)n->a);break;case K_MEM:{int s=scratch(target);expr(c,n->a,s);emit(c,OP_LOAD,target,s,(uint64_t)n->v);break;}case K_BITS:{int s=scratch(target),w=n->b-n->a;emit(c,OP_MOV,target,(int)n->v,0);if(n->a){emit(c,OP_MOVI,s,0,(uint64_t)n->a);emit(c,OP_SHR,target,s,0);}uint64_t mask=(w>=64)?~0ULL:((1ULL<<w)-1ULL);emit(c,OP_MOVI,s,0,mask);emit(c,OP_AND,target,s,0);break;}case K_CALL:{
    int argc=n->b; int f=(int)n->v;
    for(int i=0;i<argc;i++){expr(c,c->call_args[n->a+i],14);emit(c,OP_PUSH,14,0,0);}
    for(int i=argc-1;i>=0;i--)emit(c,OP_POP,i,0,0);
    if(f<0){
        int op = f==-1?OP_HOST_ARG:f==-2?OP_HOST_READ_FILE:f==-3?OP_HOST_STRLEN:f==-4?OP_HOST_BC_RESET:f==-5?OP_HOST_BC_EMIT:f==-6?OP_HOST_BC_SET_IMM:OP_HOST_BC_SAVE;
        emit(c,op,0,0,0);
    } else emit(c,OP_CALL,argc,0,(uint64_t)f);
    if(target!=0) emit(c,OP_MOV,target,0,0);
    break;}case K_BIN:{int s=scratch(target);expr(c,n->b,s);emit(c,OP_PUSH,s,0,0);expr(c,n->a,target);emit(c,OP_POP,s,0,0);TypeKind la=node_type(c,n->a),lb=node_type(c,n->b);int isfloat=(la==TY_F64||lb==TY_F64);if(iscmp(n->op)){emit(c,isfloat?OP_FCMP:OP_CMP,target,s,0);int tr=label(c),en=label(c),j=OP_JZ;switch(n->op){case 1002:j=OP_JNZ;break;case 1003:j=OP_JL;break;case 1004:j=OP_JLE;break;case 1005:j=OP_JG;break;case 1006:j=OP_JGE;break;}size_t at=emit(c,j,0,0,0);patch_add(c,at,tr);emit(c,OP_MOVI,target,0,0);at=emit(c,OP_JMP,0,0,0);patch_add(c,at,en);mark(c,tr);emit(c,OP_MOVI,target,0,1);mark(c,en);}else if(isfloat){int op=n->op==OP_ADD?OP_FADD:n->op==OP_SUB?OP_FSUB:n->op==OP_MUL?OP_FMUL:OP_FDIV;emit(c,op,target,s,0);}else emit(c,n->op,target,s,0);break;}default:die("bad AST node");}}

static void cond(Ctx*c,int id,int false_label){Node*n=&c->nodes[id]; if(n->k==K_BIN&&iscmp(n->op)){int s=scratch(14);expr(c,n->a,14);expr(c,n->b,s);emit(c,OP_CMP,14,s,0);int j;switch(n->op){case 1001:j=OP_JNZ;break;case 1002:j=OP_JZ;break;case 1003:j=OP_JGE;break;case 1004:j=OP_JG;break;case 1005:j=OP_JLE;break;case 1006:j=OP_JL;break;default:j=OP_JZ;break;}size_t at=emit(c,j,0,0,0);patch_add(c,at,false_label);}else{expr(c,id,14);emit(c,OP_MOVI,15,0,0);emit(c,OP_CMP,14,15,0);size_t at=emit(c,OP_JZ,0,0,0);patch_add(c,at,false_label);}}

static void emit_stmt(Ctx*,const char**,size_t*,size_t*,size_t,int);
static void emit_block(Ctx*c,const char**L,size_t*N,size_t *idx,size_t end,int indent){while(*idx<end){const char*line=L[*idx];int in=0;while(line[in]==' ')in++;if(in<indent)break;if(in>indent)die("unexpected indentation");emit_stmt(c,L,N,idx,end,indent);}}
static int line_trim(const char*s,int*out_start,int*out_end){int a=0,b=(int)strlen(s);while(a<b&&s[a]==' ')a++;while(b>a&&isspace((unsigned char)s[b-1]))b--;*out_start=a;*out_end=b;return a<b;}
static void split_lines(char*src,const char***out,size_t*cnt){
    size_t cap=128,n=0; const char**v=malloc(cap*sizeof(*v));
    char *p=src;
    while(p && *p){
        if(n==cap){cap*=2;v=realloc(v,cap*sizeof(*v));}
        char *e=strpbrk(p,"\r\n");
        if(e){*e=0;}
        /* Asmthon comments start with ';'. */
        int in_string=0;
        for(char *q=p; *q; ++q){
            if(*q=='"' && (q==p || q[-1]!='\\')) in_string=!in_string;
            if(*q==';' && !in_string){*q=0;break;}
        }
        v[n++]=p;
        if(!e) break;
        e++;
        while(*e=='\r'||*e=='\n') e++;
        p=e;
    }
    *out=v;*cnt=n;
}
static Node* parse_full(Ctx*c,const char*s,int a,int b){size_t p=a;while(p<(size_t)b&&isspace((unsigned char)s[p]))p++;Node*n=parse_expr(c,s,&p,b,0);skip(s,&p,b);if(p!=(size_t)b)die("trailing expression text");return n;}

static int find_assign(const char*s,int a,int b,int*kind,int*pos){int depth=0;for(int i=a;i<b;i++){char ch=s[i];if(ch=='('||ch=='[')depth++;if(ch==')'||ch==']')depth--;if(depth)continue;const char*ops[]={"<<=",">>=","+=","-=","*=","/=","%=","&=","|=","^=","="};int ks[]={11,12,3,4,5,6,7,8,9,10,1};for(int k=0;k<11;k++){int L=(k<2?3:(k==10?1:2));if(i+L<=b&&!strncmp(s+i,ops[k],L)){*kind=ks[k];*pos=i;return 1;}}}return 0;}
static int starts(const char*s,int a,int b,const char*t){int L=strlen(t);return b-a>=L&&!strncmp(s+a,t,L);}

static void emit_stmt(Ctx*c,const char**L,size_t*N,size_t*idx,size_t end,int indent){const char*s=L[*idx]; c->error_line=(int)(*idx+1); c->error_col=indent+1;int a,b;if(!line_trim(s,&a,&b)){(*idx)++;return;}
    if(starts(s,a,b,"struct ")){
        int p=a+7; while(p<b&&!isspace((unsigned char)s[p]))p++; char tname[64]; int TL=p-(a+7); if(TL<=0||TL>=64)cdie(c,"bad struct declaration"); memcpy(tname,s+a+7,TL);tname[TL]=0; while(p<b&&isspace((unsigned char)s[p]))p++; char vname[64]; int VL=b-p; if(VL<=0||VL>=64)cdie(c,"bad struct variable"); memcpy(vname,s+p,VL);vname[VL]=0; int si=find_struct(c,tname); if(si<0)cdie(c,"unknown struct"); add_struct_var(c,vname,si); (*idx)++; return;
    }
    /* Typed scalar declarations: bool/byte/word/dword/qword/i8/i16/i32/i64/u8/u16/u32/u64/ptr/string */
    {
        int sp=a; while(sp<b&&!isspace((unsigned char)s[sp])) sp++;
        if(sp>b) sp=b;
        char tn[24]; int tl=sp-a; if(tl>0&&tl<(int)sizeof(tn)){ memcpy(tn,s+a,(size_t)tl); tn[tl]=0; TypeKind ty=parse_type_name(tn);
            if(ty!=TY_UNKNOWN){
                int p=sp; while(p<b&&isspace((unsigned char)s[p])) p++; int ns=p; while(p<b&&(isalnum((unsigned char)s[p])||s[p]=='_')) p++;
                if(p>ns){ char name[32]; int nl=p-ns; if(nl>=32) cdie(c,"variable name too long"); memcpy(name,s+ns,(size_t)nl); name[nl]=0;
                    int r=declare_var(c,name,ty);
                    while(p<b&&isspace((unsigned char)s[p])) p++;
                    if(p<b&&s[p]=='['){
                        int q=p+1, val=0; while(q<b&&isdigit((unsigned char)s[q])){val=val*10+s[q]-'0';q++;} if(q>=b||s[q]!=']'||val<=0) cdie(c,"bad typed array declaration");
                        int elem=type_size_kind(ty); add_array(c,name,elem,val); (*idx)++; return;
                    }
                    if(p<b&&s[p]=='='){ Node*v=parse_full(c,s,p+1,b); v=&c->nodes[opt(c,(int)(v-c->nodes))]; check_assignment_type(c,ty,node_type(c,(int)(v-c->nodes))); expr(c,(int)(v-c->nodes),r); } else { if(ty==TY_F64) emit(c,OP_FMOVI,r,0,0); else emit(c,OP_MOVI,r,0,0); }
                    (*idx)++; return;
                }
            }
        }
    }
    if((starts(s,a,b,"byte ")||starts(s,a,b,"word ")||starts(s,a,b,"dword ")||starts(s,a,b,"qword "))&&strchr(s+a,'[')){
        int elem=1; const char*tp=s+a; if(!strncmp(tp,"word",4))elem=2;else if(!strncmp(tp,"dword",5))elem=4;else if(!strncmp(tp,"qword",5))elem=8;
        const char*sp=strchr(tp,' '); const char*lb=strchr(tp,'['); const char*rb=lb?strchr(lb,']'):NULL; if(!sp||!lb||!rb)die("bad array declaration");
        char name[32]; int nl=(int)(lb-sp-1); if(nl<=0||nl>=32)cdie(c,"bad array name"); memcpy(name,sp+1,(size_t)nl);name[nl]=0; int len=atoi(lb+1); add_array(c,name,elem,len);(*idx)++;return;
    }
    if(starts(s,a,b,"if ")){
        int lbl_end=label(c);
        int lbl_false=label(c);
        Node*n=parse_full(c,s,a+3,b-1);
        n=&c->nodes[opt(c,(int)(n-c->nodes))];
        cond(c,(int)(n-c->nodes),lbl_false);
        (*idx)++;
        if(*idx>=end)die("missing if body");
        int ci=0;while(L[*idx][ci]==' ')ci++;
        emit_block(c,L,N,idx,end,ci);
        size_t at=emit(c,OP_JMP,0,0,0);patch_add(c,at,lbl_end);
        mark(c,lbl_false);
        /* elif chain */
        while(*idx<end){
            int ea,eb; line_trim(L[*idx],&ea,&eb);
            if(ea!=indent || !starts(L[*idx],ea,eb,"elif ")) break;
            int next_false=label(c);
            Node*ec=parse_full(c,L[*idx],ea+5,eb-1);
            ec=&c->nodes[opt(c,(int)(ec-c->nodes))];
            cond(c,(int)(ec-c->nodes),next_false);
            (*idx)++;
            if(*idx>=end)die("missing elif body");
            int ni=0;while(L[*idx][ni]==' ')ni++;
            emit_block(c,L,N,idx,end,ni);
            at=emit(c,OP_JMP,0,0,0);patch_add(c,at,lbl_end);
            mark(c,next_false);
        }
        if(*idx<end){
            int oa,ob; line_trim(L[*idx],&oa,&ob);
            if(oa==indent&&starts(L[*idx],oa,ob,"else:")){
                (*idx)++;
                if(*idx>=end)die("missing else body");
                int ni=0;while(L[*idx][ni]==' ')ni++;
                emit_block(c,L,N,idx,end,ni);
            }
        }
        mark(c,lbl_end);
        return;
    }
    if(starts(s,a,b,"while ")){int ls=label(c),le=label(c);mark(c,ls);Node*n=parse_full(c,s,a+6,b-1);n=&c->nodes[opt(c,(int)(n-c->nodes))];cond(c,(int)(n-c->nodes),le);(*idx)++;int ni=0;while(L[*idx][ni]==' ')ni++;emit_block(c,L,N,idx,end,ni);size_t at=emit(c,OP_JMP,0,0,0);patch_add(c,at,ls);mark(c,le);return;}
    if(starts(s,a,b,"for ")){const char*q=s+a+4;const char*in=strstr(q," in 0..<");if(!in)die("bad for");char name[32];size_t len=(size_t)(in-q);if(len>=sizeof(name))die("for variable too long");memcpy(name,q,len);name[len]=0;int r=find_var(c,name);Node*endexpr=parse_full(c,s,(int)((in-s)+8),b-1);endexpr=&c->nodes[opt(c,(int)(endexpr-c->nodes))];int ls=label(c),le=label(c);emit(c,OP_MOVI,r,0,0);mark(c,ls);Node*vr=var(c,name);Node*cmp=bin(c,1003,vr,endexpr);cond(c,(int)(cmp-c->nodes),le);(*idx)++;int ni=0;while(L[*idx][ni]==' ')ni++;emit_block(c,L,N,idx,end,ni);emit(c,OP_MOVI,15,0,1);emit(c,OP_ADD,r,15,0);size_t at=emit(c,OP_JMP,0,0,0);patch_add(c,at,ls);mark(c,le);return;}
    if(starts(s,a,b,"print(")){int q=b-1;Node*n=parse_full(c,s,a+6,q);n=&c->nodes[opt(c,(int)(n-c->nodes))];if(n->k==K_STR){emit_string_init(c,(int)n->v);emit(c,OP_PRINT_STR,0,0,(uint64_t)c->strings[n->v].base);}else{expr(c,(int)(n-c->nodes),14);if(node_type(c,(int)(n-c->nodes))==TY_F64)emit(c,OP_FPRINT,14,0,0);else emit(c,OP_PRINT,14,0,0);}(*idx)++;return;}
    if(starts(s,a,b,"return")){size_t p=(size_t)a+6;skip(s,&p,(size_t)b);if(p<(size_t)b){Node*n=parse_full(c,s,p,b);n=&c->nodes[opt(c,(int)(n-c->nodes))];expr(c,(int)(n-c->nodes),0);}emit(c,OP_RET,0,0,0);(*idx)++;return;}
    if(starts(s,a,b,"call ")){char name[64];int p=a+5,Ln=0;while(p<b&&!isspace((unsigned char)s[p])){name[Ln++]=s[p++];}name[Ln]=0;int f=find_func(c,name);if(f==-9999)cdie(c,"unknown function");emit(c,OP_CALL,0,0,f);(*idx)++;return;}
    int kind,pos;if(find_assign(s,a,b,&kind,&pos)){
        if(s[a]=='*'){ int ps=a+1;while(ps<pos&&isspace((unsigned char)s[ps]))ps++;int pe=pos;while(pe>ps&&isspace((unsigned char)s[pe-1]))pe--;char name[32];int nl=pe-ps;if(nl<=0||nl>=32)die("bad pointer assignment");memcpy(name,s+ps,(size_t)nl);name[nl]=0;int pr=find_var(c,name);Node*v=parse_full(c,s,pos+1,b);v=&c->nodes[opt(c,(int)(v-c->nodes))];expr(c,(int)(v-c->nodes),15);emit(c,OP_STORE,pr,15,8);(*idx)++;return;}
        if(!strncmp(s+a,"memory.",7)){const char*lb=strchr(s+a,'[');const char*rb=lb?strchr(lb,']'):NULL;const char*eq=strchr(rb?rb+1:s+a,'=');if(!lb||!rb||!eq)die("bad memory assignment");Node*addr=parse_full(c,s,(int)(lb-s)+1,(int)(rb-s));addr=&c->nodes[opt(c,(int)(addr-c->nodes))];Node*val=parse_full(c,s,(int)(eq-s)+1,b);val=&c->nodes[opt(c,(int)(val-c->nodes))];
            int msize=8; const char *mp=s+a+7; 
            if(!strncmp(mp,"byte",4))msize=1; else if(!strncmp(mp,"word",4))msize=2; else if(!strncmp(mp,"dword",5))msize=4; else if(!strncmp(mp,"qword",5))msize=8;
            expr(c,(int)(val-c->nodes),15); emit(c,OP_PUSH,15,0,0); expr(c,(int)(addr-c->nodes),14); emit(c,OP_POP,15,0,0); emit(c,OP_STORE,14,15,msize);(*idx)++;return;}
        const char*dotfield=strchr(s+a,'.');
        if(dotfield&&dotfield<s+pos && strncmp(dotfield,".bit[",5) && strncmp(dotfield,".bits[",6)){
            char obj[32],field[32]; int olen=(int)(dotfield-(s+a)); int fs=(int)(dotfield-s)+1; while(fs<pos&&isspace((unsigned char)s[fs]))fs++; int fe=pos; while(fe>fs&&isspace((unsigned char)s[fe-1]))fe--; int flen=fe-fs; while(olen>0&&isspace((unsigned char)s[a+olen-1]))olen--; if(olen<=0||olen>=32||flen<=0||flen>=32)die("bad struct field lhs"); memcpy(obj,s+a,(size_t)olen);obj[olen]=0; memcpy(field,s+fs,(size_t)flen);field[flen]=0; int fsz=0,addr=struct_field_addr(c,obj,field,&fsz); if(addr<0)die("unknown struct field");
            Node*v=parse_full(c,s,pos+((kind==1)?1:2),b);v=&c->nodes[opt(c,(int)(v-c->nodes))];
            if(kind==1){ expr(c,(int)(v-c->nodes),15); emit(c,OP_PUSH,15,0,0); emit(c,OP_MOVI,14,0,(uint64_t)addr); emit(c,OP_POP,15,0,0); emit(c,OP_STORE,14,15,(uint64_t)fsz); }
            else { emit(c,OP_MOVI,14,0,(uint64_t)addr); emit(c,OP_LOAD,15,14,(uint64_t)fsz); expr(c,(int)(v-c->nodes),13); int op=kind==3?OP_ADD:kind==4?OP_SUB:kind==5?OP_MUL:kind==6?OP_DIV:kind==7?OP_MOD:kind==8?OP_AND:kind==9?OP_OR:kind==10?OP_XOR:kind==11?OP_SHL:OP_SHR; emit(c,op,15,13,0); emit(c,OP_STORE,14,15,(uint64_t)fsz); } (*idx)++; return;
        }
        const char*dot=strstr(s+a,".bit[");if(dot&&dot<s+pos){char name[32];size_t len=(size_t)(dot-(s+a));if(len>=sizeof(name))die("bad bit lhs");memcpy(name,s+a,len);name[len]=0;int bit=atoi(dot+5);if(bit>63)die("bad bit index");Node*v=parse_full(c,s,pos+1,b);v=&c->nodes[opt(c,(int)(v-c->nodes))];expr(c,(int)(v-c->nodes),14);emit(c,OP_MOVI,15,0,0);emit(c,OP_CMP,14,15,0);int setL=label(c),endL=label(c);size_t at=emit(c,OP_JNZ,0,0,0);patch_add(c,at,setL);emit(c,OP_BIT_CLR,find_var(c,name),0,bit);at=emit(c,OP_JMP,0,0,0);patch_add(c,at,endL);mark(c,setL);emit(c,OP_BIT_SET,find_var(c,name),0,bit);mark(c,endL);(*idx)++;return;}
        const char*bdot=strstr(s+a,".bits[");
        if(bdot&&bdot<s+pos){
            char name[32];size_t len=(size_t)(bdot-(s+a));if(len>=sizeof(name))die("bad bits lhs");memcpy(name,s+a,len);name[len]=0;
            const char *lb=strchr(bdot,'['),*cl=lb?strchr(lb,':'):NULL,*rb=cl?strchr(cl,']'):NULL;
            if(!lb||!cl||!rb||cl>rb) die("bad bits lhs");
            int lo=atoi(lb+1),hi=atoi(cl+1);if(lo<0||hi>64||lo>=hi)die("bad bits range");
            Node*v=parse_full(c,s,pos+1,b);v=&c->nodes[opt(c,(int)(v-c->nodes))];int dst=find_var(c,name);
            expr(c,(int)(v-c->nodes),14);int width=hi-lo;uint64_t mask=(width>=64)?~0ULL:((1ULL<<width)-1ULL);
            emit(c,OP_MOVI,15,0,mask);emit(c,OP_AND,14,15,0);if(lo){emit(c,OP_MOVI,15,0,(uint64_t)lo);emit(c,OP_SHL,14,15,0);}
            uint64_t fieldmask=(width>=64)?~0ULL:(((1ULL<<width)-1ULL)<<lo);
            emit(c,OP_MOVI,15,0,~fieldmask);emit(c,OP_AND,dst,15,0);emit(c,OP_OR,dst,14,0);(*idx)++;return;
        }
        const char*lb_lhs=strchr(s+a,'['); if(lb_lhs && lb_lhs<s+pos){ const char*rb_lhs=strchr(lb_lhs,']'); if(!rb_lhs||rb_lhs>s+pos)die("bad array lhs"); char name[32]; int nl=(int)(lb_lhs-(s+a)); if(nl<=0||nl>=32)cdie(c,"bad array name"); memcpy(name,s+a,(size_t)nl); name[nl]=0; int ai=find_array(c,name); if(ai<0)cdie(c,"unknown array"); size_t ip=(size_t)(lb_lhs-s)+1; Node*ix=parse_expr(c,s,&ip,(size_t)(rb_lhs-s),0); Node*addr=array_addr_node(c,name,ix); Node*v=parse_full(c,s,pos+1,b); v=&c->nodes[opt(c,(int)(v-c->nodes))]; expr(c,(int)(v-c->nodes),15); emit(c,OP_PUSH,15,0,0); expr(c,(int)(addr-c->nodes),14); emit(c,OP_POP,15,0,0); emit(c,OP_STORE,14,15,(uint64_t)c->arrays[ai].elem); (*idx)++; return; }
        int lhs_end=pos; while(lhs_end>a && isspace((unsigned char)s[lhs_end-1])) lhs_end--;
        char name[32];int L=lhs_end-a;if(L<=0||L>=(int)sizeof(name))die("variable name too long");memcpy(name,s+a,L);name[L]=0;int dst=find_var(c,name);Node*n=parse_full(c,s,pos+((kind==1)?1:2),b);n=&c->nodes[opt(c,(int)(n-c->nodes))];if(c->vars[dst].type==TY_UNKNOWN)c->vars[dst].type=node_type(c,(int)(n-c->nodes));if(kind==1){check_assignment_type(c,c->vars[dst].type,node_type(c,(int)(n-c->nodes)));expr(c,(int)(n-c->nodes),dst);}else{expr(c,(int)(n-c->nodes),14);int op=kind==3?OP_ADD:kind==4?OP_SUB:kind==5?OP_MUL:kind==6?OP_DIV:kind==7?OP_MOD:kind==8?OP_AND:kind==9?OP_OR:kind==10?OP_XOR:kind==11?OP_SHL:OP_SHR;emit(c,op,dst,14,0);}(*idx)++;return;}
    cdie(c,"unsupported statement");
}

static int indent_of(const char*s){int n=0;while(s[n]==' ')n++;return n;}
static void compile_one_func(Ctx*c,const char**lines,size_t n,int fi){
    Func *f=&c->funcs[fi];
    f->entry=c->cc;
    c->nv=0; c->nsv=0; c->nn=0; c->call_argc=0;
    for(int pi=0;pi<f->nparam;pi++){ declare_var(c,f->params[pi],TY_I64); }
    size_t i=f->line+1;
    if(i>=n) die("empty function");
    int indent=indent_of(lines[i]);
    if(indent<=0) die("function body must be indented");
    while(i<n){
        int a,b; line_trim(lines[i],&a,&b);
        if(a==0 && starts(lines[i],a,b,"fn ")) break;
        if(a<indent) break;
        if(a!=indent) die("invalid indentation");
        emit_stmt(c,lines,NULL,&i,n,indent);
    }
    if(!c->cc || c->code[c->cc-1].op!=OP_RET) emit(c,OP_RET,0,0,0);
}
static void scan_structs(Ctx*c,const char**lines,size_t n){
    for(size_t i=0;i<n;i++){
        int a,b; if(!line_trim(lines[i],&a,&b))continue; if(a!=0 || !starts(lines[i],a,b,"struct ") || b<=0 || lines[i][b-1]!=':')continue;
        int p=a+7; while(p<b&&!isspace((unsigned char)lines[i][p])&&lines[i][p]!=':')p++; int TL=p-(a+7); if(TL<=0||TL>=32)die("bad struct name");
        if(c->nstructs>=64)die("too many struct types");
        StructDef*d=&c->structs[c->nstructs]; memset(d,0,sizeof(*d)); memcpy(d->name,lines[i]+a+7,(size_t)TL);d->name[TL]=0; d->align=1;
        i++; int indent=-1;
        while(i<n){ int x,y; if(!line_trim(lines[i],&x,&y)){ i++; continue; } if(x<=a) {i--;break;} if(indent<0)indent=x; if(x!=indent)die("invalid struct indentation");
            const char *q=lines[i]+x; int tp=0; while(tp<y-x&&!isspace((unsigned char)q[tp]))tp++; char tn[16];if(tp<=0||tp>=16)die("bad struct field type");memcpy(tn,q,(size_t)tp);tn[tp]=0; int sz=type_size(tn);if(!sz)die("unsupported struct field type"); while(tp<y-x&&isspace((unsigned char)q[tp]))tp++; int NL=y-x-tp;if(NL<=0||NL>=32)die("bad struct field"); if(d->nf>=32)die("too many struct fields"); Field*f=&d->fields[d->nf++];snprintf(f->name,sizeof(f->name),"%s",q+tp);f->align=sz;d->size=align_up(d->size,sz);f->off=d->size;f->size=sz;d->size+=sz;if(sz>d->align)d->align=sz;
            i++;
        }
        d->size=align_up(d->size,d->align);
        c->nstructs++;
    }
}

static void compile(Ctx*c,const char**lines,size_t n){
    scan_structs(c,lines,n);
    for(size_t i=0;i<n;i++){
        int a,b; if(!line_trim(lines[i],&a,&b)) continue;
        if(starts(lines[i],a,b,"fn ")){
            if(c->nf>=MAX_FUNCS) die("too many functions");
            const char*p=lines[i]+a+3; const char*q=strchr(p,'('); const char*r=q?strchr(q,')'):NULL; if(!q||!r)cdie(c,"bad function");
            size_t L=(size_t)(q-p); if(L==0||L>=32)die("bad function name");
            memcpy(c->funcs[c->nf].name,p,L); c->funcs[c->nf].name[L]=0; c->funcs[c->nf].nparam=0;
            size_t pp=(size_t)(q-lines[i]+1);
            while(&lines[i][pp]<r){
                while(&lines[i][pp]<r&&isspace((unsigned char)lines[i][pp]))pp++;
                size_t st=pp;
                while(&lines[i][pp]<r&&(isalnum((unsigned char)lines[i][pp])||lines[i][pp]=='_'))pp++;
                if(pp==st) break;
                while(&lines[i][pp]<r&&isspace((unsigned char)lines[i][pp]))pp++;
                size_t nameSt=st;
                if(&lines[i][pp]<r && (isalnum((unsigned char)lines[i][pp])||lines[i][pp]=='_')){
                    nameSt=pp;
                    while(&lines[i][pp]<r&&(isalnum((unsigned char)lines[i][pp])||lines[i][pp]=='_'))pp++;
                }
                size_t PL=pp-nameSt;
                if(PL>=32||c->funcs[c->nf].nparam>=8) cdie(c,"too many parameters");
                memcpy(c->funcs[c->nf].params[c->funcs[c->nf].nparam],lines[i]+nameSt,PL);
                c->funcs[c->nf].params[c->funcs[c->nf].nparam][PL]=0;
                c->funcs[c->nf].nparam++;
                while(&lines[i][pp]<r&&lines[i][pp]!=',')pp++;
                if(&lines[i][pp]<r&&lines[i][pp]==',')pp++;
            }
            c->funcs[c->nf].line=i; c->funcs[c->nf].entry=SIZE_MAX; c->nf++;
        }
    }
    int mainf=find_func(c,"main"); if(mainf<0)die("missing fn main()");
    compile_one_func(c,lines,n,mainf);
    for(int i=0;i<c->nf;i++) if(i!=mainf) compile_one_func(c,lines,n,i);
}

static void peephole(Ctx*c){
    for(size_t i=0;i<c->cc;i++){
        Ins *x=&c->code[i];
        if(x->op==OP_MOV && x->dst==x->src) x->op=OP_NOP;
        if(x->op==OP_JMP && x->imm==i+1) x->op=OP_NOP;
        if(x->op==OP_PUSH && i+1<c->cc && c->code[i+1].op==OP_POP && c->code[i+1].dst==x->dst){ x->op=OP_NOP; c->code[i+1].op=OP_NOP; }
        if(x->op==OP_MOV && i+1<c->cc && c->code[i+1].op==OP_MOV && c->code[i+1].src==x->dst){ c->code[i+1].src=x->src; }
        /* MOVI -> MOV merging is intentionally disabled: without liveness
           analysis it can delete a still-live source register. */
    }
}


/* ---------------- IR + optimizer + linear-scan register allocation ---------------- */
typedef Ins IRIns;
typedef struct { size_t first,last; int active; int phys; } Interval;

static int ir_reads(const IRIns *x,int r){
    switch(x->op){
        case OP_MOV: case OP_ADD: case OP_SUB: case OP_MUL: case OP_DIV: case OP_MOD:
        case OP_AND: case OP_OR: case OP_XOR: case OP_SHL: case OP_SHR: case OP_CMP:
            return x->src==r || (x->op!=OP_CMP && x->dst==r);
        case OP_PUSH: case OP_PRINT: case OP_POP: case OP_BIT_GET: return x->src==r || x->dst==r;
        case OP_STORE: return x->dst==r || x->src==r;
        case OP_LOAD: return x->src==r;
        default: return 0;
    }
}
static int ir_writes(const IRIns *x,int r){
    switch(x->op){
        case OP_MOVI: case OP_MOV: case OP_ADD: case OP_SUB: case OP_MUL: case OP_DIV: case OP_MOD:
        case OP_AND: case OP_OR: case OP_XOR: case OP_SHL: case OP_SHR: case OP_LOAD:
        case OP_POP: case OP_BIT_GET: case OP_BIT_SET: case OP_BIT_CLR: case OP_BIT_TOG:
            return x->dst==r;
        default: return 0;
    }
}
static void ir_local_opt(IRIns *ir,size_t *n){
    size_t N=*n;
    for(int pass=0;pass<6;pass++){
        for(size_t i=0;i<N;i++){
            IRIns *x=&ir[i];
            if(x->op==OP_MOV && x->dst==x->src) x->op=OP_NOP;
            if(x->op==OP_JMP && x->imm==i+1) x->op=OP_NOP;
            if(i+1<N && x->op==OP_PUSH && ir[i+1].op==OP_POP && x->dst==ir[i+1].dst){x->op=OP_NOP;ir[i+1].op=OP_NOP;}
        }
        /* Keep control-flow-sensitive liveness out of the local pass. */
    }
    *n=N;
}
static void linear_scan_allocate(IRIns *ir,size_t n){
    /* The VM has a fixed calling convention: r0..r15 are architectural
       registers and r0..r(argc-1) carry function arguments. A lexical
       interval is not sufficient across CFG back-edges, so only perform
       physical renaming for straight-line, call-free regions. Control-flow
       functions keep ABI register identities. */
    int complex=0;
    for(size_t i=0;i<n;i++){
        switch(ir[i].op){
            case OP_JMP: case OP_JZ: case OP_JNZ: case OP_JG: case OP_JL: case OP_JGE: case OP_JLE:
            case OP_CALL:
            case OP_HOST_ARG: case OP_HOST_READ_FILE: case OP_HOST_STRLEN:
            case OP_HOST_BC_RESET: case OP_HOST_BC_EMIT: case OP_HOST_BC_SET_IMM: case OP_HOST_BC_SAVE:
                complex=1; break;
            default: break;
        }
    }
    if(complex) return;
    Interval in[14];
    for(int r=0;r<14;r++){in[r].first=SIZE_MAX;in[r].last=0;in[r].active=0;in[r].phys=-1;}
    for(size_t i=0;i<n;i++){
        IRIns*x=&ir[i];
        for(int r=0;r<14;r++) if(ir_reads(x,r)||ir_writes(x,r)){
            if(in[r].first==SIZE_MAX) in[r].first=i;
            in[r].last=i;
        }
    }
    int order[14],m=0; for(int r=0;r<14;r++) if(in[r].first!=SIZE_MAX) order[m++]=r;
    for(int i=1;i<m;i++){int k=order[i],j=i;while(j>0&&in[order[j-1]].first>in[k].first){order[j]=order[j-1];j--;}order[j]=k;}
    int active[14],ac=0,used[14]={0};
    for(int oi=0;oi<m;oi++){
        int v=order[oi];
        for(int j=0;j<ac;){int a=active[j];if(in[a].last<in[v].first){used[in[a].phys]=0;active[j]=active[--ac];}else j++;}
        int p;for(p=0;p<14;p++)if(!used[p])break;
        if(p>=14) return;
        in[v].phys=p;used[p]=1;active[ac++]=v;
    }
    for(size_t i=0;i<n;i++){
        IRIns*x=&ir[i];
        if(x->dst<14&&in[x->dst].phys>=0)x->dst=(unsigned char)in[x->dst].phys;
        if(x->src<14&&in[x->src].phys>=0)x->src=(unsigned char)in[x->src].phys;
    }
}
static void lower_to_ir(Ctx*c,IRIns*ir,size_t*n){*n=c->cc;memcpy(ir,c->code,c->cc*sizeof(IRIns));ir_local_opt(ir,n);linear_scan_allocate(ir,*n);}
static void commit_ir(Ctx*c,const IRIns*ir,size_t n){c->cc=n;memcpy(c->code,ir,n*sizeof(Ins));}

static void write_avm(const char*path,Ctx*c){
    IRIns ir[MAX_CODE]; size_t irn=0; lower_to_ir(c,ir,&irn); commit_ir(c,ir,irn); peephole(c);
    for(size_t i=0;i<c->pcnt;i++){size_t at=c->patch_at[i];int lab=c->patch_label[i];if(lab<0||lab>=c->next_label||c->labels[lab]<0)die("unresolved label");c->code[at].imm=(uint64_t)c->labels[lab];}
    for(size_t i=0;i<c->cc;i++) if(c->code[i].op==OP_CALL){uint64_t f=c->code[i].imm; if(f>=(uint64_t)c->nf)die("bad call relocation"); c->code[i].imm=c->funcs[f].entry;}
    FILE*f=fopen(path,"wb");if(!f)die("cannot open output");unsigned char h[16]={ 'A','S','M','V',3,0,0,0 };uint64_t n=c->cc;memcpy(h+8,&n,8);fwrite(h,1,16,f);fwrite(c->code,sizeof(Ins),c->cc,f);fclose(f);
}

static char *dupstr_local(const char *s){
    size_t n=strlen(s)+1; char *p=(char*)malloc(n); if(!p) die("out of memory"); memcpy(p,s,n); return p;
}
static char *read_text_file(const char *path){
    FILE *f=fopen(path,"rb"); if(!f) return NULL;
    if(fseek(f,0,SEEK_END)!=0){fclose(f);return NULL;}
    long sz=ftell(f); if(sz<0){fclose(f);return NULL;}
    if(fseek(f,0,SEEK_SET)!=0){fclose(f);return NULL;}
    char *buf=(char*)malloc((size_t)sz+1); if(!buf){fclose(f);die("out of memory");}
    if(fread(buf,1,(size_t)sz,f)!=(size_t)sz){free(buf);fclose(f);return NULL;}
    fclose(f); buf[sz]=0; return buf;
}
static int import_seen(char **seen,size_t n,const char *path){for(size_t i=0;i<n;i++)if(!strcmp(seen[i],path))return 1;return 0;}
static char *join_source_with_imports(const char *path,int depth,char **seen,size_t *seen_n){
    if(depth>32) die("import nesting too deep");
    char canonical[4096];
    if(!realpath(path,canonical)) snprintf(canonical,sizeof(canonical),"%s",path);
    char *src=read_text_file(canonical); if(!src){fprintf(stderr,"Asmthon compiler error: cannot open %s\n",canonical);exit(1);}
    if(import_seen(seen,*seen_n,canonical)){free(src);return dupstr_local("");}
    if(*seen_n>=64) die("too many imported modules");
    seen[(*seen_n)++]=dupstr_local(canonical);
    size_t cap=strlen(src)+1, len=0; char *out=(char*)malloc(cap); if(!out)die("out of memory"); out[0]=0;
    char *cur=src;
    while(cur && *cur){
        char *nl=strchr(cur,'\n');
        if(nl) *nl=0;
        size_t ll=strlen(cur);
        char *q=cur; while(*q==' '||*q=='\t')q++;
        if(!strncmp(q,"import ",7)){
            q+=7; while(*q==' '||*q=='\t')q++;
            if(*q!='\"') die("import expects quoted path");
            q++; char *e=strrchr(q,'\"'); if(!e) die("unterminated import path"); *e=0;
            char child[4096];
            const char *slash=strrchr(canonical,'/');
            if(slash){size_t d=(size_t)(slash-canonical); if(d+1+strlen(q)>=sizeof(child))die("import path too long"); memcpy(child,canonical,d);child[d]='/';strcpy(child+d+1,q);}
            else {snprintf(child,sizeof(child),"%s",q);}
            char *sub=join_source_with_imports(child,depth+1,seen,seen_n); size_t sl=strlen(sub);
            if(len+sl+2>cap){while(len+sl+2>cap)cap*=2;out=(char*)realloc(out,cap);if(!out)die("out of memory");}
            memcpy(out+len,sub,sl);len+=sl;out[len++]='\n';out[len]=0;free(sub);
        } else {
            if(len+ll+2>cap){while(len+ll+2>cap)cap*=2;out=(char*)realloc(out,cap);if(!out)die("out of memory");}
            memcpy(out+len,cur,ll);len+=ll;out[len++]='\n';out[len]=0;
        }
        if(!nl) break;
        cur=nl+1;
    }
    free(src); return out;
}
int main(int argc,char**argv){
    if(argc<3){fprintf(stderr,"usage: asmthonc source.asmthon output.avm\\n");return 2;}
    char *seen[64]={0}; size_t seen_n=0;
    char entry_path[4096];
    if(!realpath(argv[1],entry_path)) snprintf(entry_path,sizeof(entry_path),"%s",argv[1]);
    char *src=join_source_with_imports(entry_path,0,seen,&seen_n);
    const char**lines; size_t n; split_lines(src,&lines,&n);
    Ctx c={0}; compile(&c,lines,n); write_avm(argv[2],&c);
    free(c.patch_at);free(c.patch_label);free(lines);free(src);
    for(size_t i=0;i<seen_n;i++)free(seen[i]);
    return 0;
}
