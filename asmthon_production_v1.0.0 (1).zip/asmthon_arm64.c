#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct { uint8_t op,dst,src,res; uint64_t imm; } Ins;
enum {OP_NOP,OP_MOVI,OP_MOV,OP_ADD,OP_SUB,OP_MUL,OP_DIV,OP_MOD,OP_AND,OP_OR,OP_XOR,OP_SHL,OP_SHR,OP_CMP,OP_JMP,OP_JZ,OP_JNZ,OP_JG,OP_JL,OP_JGE,OP_JLE,OP_PUSH,OP_POP,OP_LOAD,OP_STORE,OP_CALL,OP_RET,OP_BIT_GET,OP_BIT_SET,OP_BIT_CLR,OP_BIT_TOG,OP_PRINT,OP_PRINT_STR,OP_FMOVI,OP_FMOV,OP_FADD,OP_FSUB,OP_FMUL,OP_FDIV,OP_FCMP,OP_FPRINT,OP_HALT};
static void die(const char*s){fprintf(stderr,"arm64: %s\n",s);exit(1);} 
static void reg(FILE*f,int r){if(r<16)fprintf(f,"x%d",r);else fprintf(f,"x16");}
static void freg(FILE*f,int r){if(r<16)fprintf(f,"d%d",r);else fprintf(f,"d16");}
static void wreg(FILE*f,int r){if(r<16)fprintf(f,"w%d",r);else fprintf(f,"w16");}
static int load(const char*p,Ins*c,size_t*m){FILE*f=fopen(p,"rb");if(!f)return 0;uint8_t h[16];if(fread(h,1,16,f)!=16||memcmp(h,"ASMV",4)){fclose(f);return 0;}uint32_t v;memcpy(&v,h+4,4);if(v!=3){fclose(f);return 0;}uint64_t n;memcpy(&n,h+8,8);if(n>*m){fclose(f);return 0;}if(fread(c,sizeof(*c),n,f)!=n){fclose(f);return 0;}*m=(size_t)n;fclose(f);return 1;}
static void emit(FILE*f,const Ins*x){
 switch(x->op){
 case OP_NOP: break;
 case OP_MOVI: fprintf(f,"    mov ");reg(f,x->dst);fprintf(f,", #%llu\n",(unsigned long long)x->imm);break;
 case OP_MOV: fprintf(f,"    mov ");reg(f,x->dst);fprintf(f,", ");reg(f,x->src);fputc('\n',f);break;
 case OP_ADD: case OP_SUB: case OP_MUL: {const char*n=x->op==OP_ADD?"add":x->op==OP_SUB?"sub":"mul";fprintf(f,"    %s ",n);reg(f,x->dst);fprintf(f,", ");reg(f,x->dst);fprintf(f,", ");reg(f,x->src);fputc('\n',f);break;}
 case OP_AND: case OP_OR: case OP_XOR:{const char*n=x->op==OP_AND?"and":x->op==OP_OR?"orr":"eor";fprintf(f,"    %s ",n);reg(f,x->dst);fprintf(f,", ");reg(f,x->dst);fprintf(f,", ");reg(f,x->src);fputc('\n',f);break;}
 case OP_SHL: case OP_SHR:{const char*n=x->op==OP_SHL?"lsl":"lsr";fprintf(f,"    %s ",n);reg(f,x->dst);fprintf(f,", ");reg(f,x->dst);fprintf(f,", ");reg(f,x->src);fputc('\n',f);break;}
 case OP_DIV: case OP_MOD: fprintf(f,"    sdiv x16, ");reg(f,x->dst);fprintf(f,", ");reg(f,x->src);if(x->op==OP_DIV){fprintf(f,"\n    mov ");reg(f,x->dst);fprintf(f,", x16\n");}else{fprintf(f,"\n    msub x16, x16, ");reg(f,x->src);fprintf(f,", ");reg(f,x->dst);fprintf(f,", ");reg(f,x->dst);fputc('\n',f);}break;
 case OP_CMP: fprintf(f,"    cmp ");reg(f,x->dst);fprintf(f,", ");reg(f,x->src);fputc('\n',f);break;
 case OP_JMP: fprintf(f,"    b I%llu\n",(unsigned long long)x->imm);break;
 case OP_JZ: fprintf(f,"    b.eq I%llu\n",(unsigned long long)x->imm);break;
 case OP_JNZ: fprintf(f,"    b.ne I%llu\n",(unsigned long long)x->imm);break;
 case OP_JG: fprintf(f,"    b.gt I%llu\n",(unsigned long long)x->imm);break;
 case OP_JL: fprintf(f,"    b.lt I%llu\n",(unsigned long long)x->imm);break;
 case OP_JGE: fprintf(f,"    b.ge I%llu\n",(unsigned long long)x->imm);break;
 case OP_JLE: fprintf(f,"    b.le I%llu\n",(unsigned long long)x->imm);break;
 case OP_PUSH: fprintf(f,"    sub sp, sp, #8\n    str ");reg(f,x->dst);fprintf(f,", [sp]\n");break;
 case OP_POP: fprintf(f,"    ldr ");reg(f,x->dst);fprintf(f,", [sp]\n    add sp, sp, #8\n");break;
 case OP_LOAD: fprintf(f,"    add x16, x18, ");reg(f,x->src);fprintf(f,"\n"); if(x->imm==1)fputs("    ldrb ",f); else if(x->imm==2)fputs("    ldrh ",f); else if(x->imm==4)fputs("    ldr ",f); else if(x->imm==8)fputs("    ldr ",f); else die("invalid load size"); if(x->imm==4||x->imm==2||x->imm==1)wreg(f,x->dst); else reg(f,x->dst);fputs(", [x16]\n",f);break;
 case OP_STORE: fprintf(f,"    add x16, x18, ");reg(f,x->dst);fprintf(f,"\n"); if(x->imm==1)fputs("    strb ",f); else if(x->imm==2)fputs("    strh ",f); else if(x->imm==4)fputs("    str ",f); else if(x->imm==8)fputs("    str ",f); else die("invalid store size"); if(x->imm==4||x->imm==2||x->imm==1)wreg(f,x->src); else reg(f,x->src);fputs(", [x16]\n",f);break;
 case OP_CALL: fprintf(f,"    bl I%llu\n",(unsigned long long)x->imm);break;
 case OP_RET: fprintf(f,"    ret\n");break;
 case OP_BIT_GET: fprintf(f,"    ubfx ");reg(f,x->dst);fprintf(f,", ");reg(f,x->src);fprintf(f,", #%llu, #1\n",(unsigned long long)x->imm);break;
 case OP_BIT_SET: fprintf(f,"    mov x16, #1\n    lsl x16, x16, #%llu\n    orr ", (unsigned long long)x->imm);reg(f,x->dst);fprintf(f,", ");reg(f,x->dst);fprintf(f,", x16\n");break;
 case OP_BIT_CLR: fprintf(f,"    mov x16, #1\n    lsl x16, x16, #%llu\n    bic ",(unsigned long long)x->imm);reg(f,x->dst);fprintf(f,", ");reg(f,x->dst);fprintf(f,", x16\n");break;
 case OP_BIT_TOG: fprintf(f,"    mov x16, #1\n    lsl x16, x16, #%llu\n    eor ",(unsigned long long)x->imm);reg(f,x->dst);fprintf(f,", ");reg(f,x->dst);fprintf(f,", x16\n");break;
 case OP_FMOVI: fprintf(f,"    mov x16, #%llu\n    fmov ",(unsigned long long)x->imm);freg(f,x->dst);fprintf(f,", x16\n");break;
 case OP_FMOV: fprintf(f,"    fmov ");freg(f,x->dst);fprintf(f,", ");freg(f,x->src);fputc('\n',f);break;
 case OP_FADD: case OP_FSUB: case OP_FMUL: case OP_FDIV:{const char*n=x->op==OP_FADD?"fadd":x->op==OP_FSUB?"fsub":x->op==OP_FMUL?"fmul":"fdiv";fprintf(f,"    %s ",n);freg(f,x->dst);fprintf(f,", ");freg(f,x->dst);fprintf(f,", ");freg(f,x->src);fputc('\n',f);break;}
 case OP_FCMP: fprintf(f,"    fcmp ");freg(f,x->dst);fprintf(f,", ");freg(f,x->src);fputc('\n',f);break;
 case OP_PRINT: fprintf(f,"    bl asmthon_print_i64\n");break;
 case OP_PRINT_STR: fprintf(f,"    add x0, x18, #%llu\n    bl asmthon_print_str\n",(unsigned long long)x->imm);break;
 case OP_FPRINT: fprintf(f,"    bl asmthon_print_f64\n");break;
 case OP_HALT: fprintf(f,"    ret\n");break;
 default: die("unsupported opcode");
 }}
int main(int ac,char**av){if(ac<3){fprintf(stderr,"usage: asmthon-arm64 in.avm out.s\n");return 2;}Ins*c=calloc(8192,sizeof(*c));size_t n=8192;if(!c||!load(av[1],c,&n))die("invalid avm");FILE*f=fopen(av[2],"w");if(!f)die("cannot open output");fputs(".bss\n.align 4\nvm_memory: .skip 65536\n.text\n.global asmthon_main\n.extern asmthon_print_i64\n.extern asmthon_print_f64\n.extern asmthon_print_str\nasmthon_main:\n    adrp x18, vm_memory\n    add x18, x18, :lo12:vm_memory\n",f);for(size_t i=0;i<n;i++){fprintf(f,"I%zu:\n",i);emit(f,&c[i]);}fputs("    ret\n",f);fclose(f);free(c);return 0;}
