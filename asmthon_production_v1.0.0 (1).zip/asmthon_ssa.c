#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define MAX_CODE 8192
#define MAX_REG 16
#define MAX_B 8192
#define WORDS(n) (((n)+63u)/64u)

typedef struct { unsigned char op,dst,src,res; uint64_t imm; } Ins;
typedef struct { int start,end,npred,nsucc; int pred[64],succ[2]; } Block;
typedef struct { int has; int orig; int version; int narg; int arg[64]; } Phi;

enum {OP_NOP,OP_MOVI,OP_MOV,OP_ADD,OP_SUB,OP_MUL,OP_DIV,OP_MOD,OP_AND,OP_OR,OP_XOR,OP_SHL,OP_SHR,OP_CMP,OP_JMP,OP_JZ,OP_JNZ,OP_JG,OP_JL,OP_JGE,OP_JLE,OP_PUSH,OP_POP,OP_LOAD,OP_STORE,OP_CALL,OP_RET,OP_BIT_GET,OP_BIT_SET,OP_BIT_CLR,OP_BIT_TOG,OP_PRINT,OP_PRINT_STR,OP_FMOVI,OP_FMOV,OP_FADD,OP_FSUB,OP_FMUL,OP_FDIV,OP_FCMP,OP_FPRINT,OP_HALT,OP_COUNT};

enum { F_EQ=1,F_GT=2,F_LT=4 };
static Ins code[MAX_CODE]; static size_t n;
static Block blocks[MAX_B]; static int nb,bmap[MAX_CODE];
static Phi *phis;
static uint64_t *dom,*df;
static int *idom,*dom_child_start,*dom_child_next;
static int stacks[MAX_REG][MAX_CODE], stack_n[MAX_REG], next_version[MAX_REG];
static void die(const char*s){fprintf(stderr,"asmthon-ssa: %s\n",s);exit(1);}
static int bit_get(const uint64_t*a,int x){return (a[x>>6]>>(x&63))&1;}
static void bit_set(uint64_t*a,int x){a[x>>6]|=1ULL<<(x&63);}
static void bit_copy(uint64_t*d,const uint64_t*s,size_t w){memcpy(d,s,w*8);}
static void bit_and(uint64_t*d,const uint64_t*s,size_t w){for(size_t i=0;i<w;i++)d[i]&=s[i];}
static int bit_equal(const uint64_t*a,const uint64_t*b,size_t w){return memcmp(a,b,w*8)==0;}
static int popcount_bits(const uint64_t*a,size_t w){int c=0;for(size_t i=0;i<w;i++)c+=__builtin_popcountll(a[i]);return c;}
static int target(const Ins*x){return x->op>=OP_JMP&&x->op<=OP_JLE?(int)x->imm:-1;}
static int nofall(const Ins*x){return x->op==OP_JMP||x->op==OP_RET||x->op==OP_HALT;}
static int defines(const Ins*x,int r){switch(x->op){case OP_MOVI:case OP_MOV:case OP_ADD:case OP_SUB:case OP_MUL:case OP_DIV:case OP_MOD:case OP_AND:case OP_OR:case OP_XOR:case OP_SHL:case OP_SHR:case OP_LOAD:case OP_POP:case OP_BIT_GET:case OP_BIT_SET:case OP_BIT_CLR:case OP_BIT_TOG:case OP_FMOVI:case OP_FMOV:case OP_FADD:case OP_FSUB:case OP_FMUL:case OP_FDIV:return x->dst==r;default:return 0;}}
static int uses_reg(const Ins*x,int r){switch(x->op){case OP_MOV:case OP_ADD:case OP_SUB:case OP_MUL:case OP_DIV:case OP_MOD:case OP_AND:case OP_OR:case OP_XOR:case OP_SHL:case OP_SHR:case OP_CMP:case OP_FMOV:case OP_FADD:case OP_FSUB:case OP_FMUL:case OP_FDIV:case OP_FCMP:return x->src==r;case OP_PUSH:case OP_PRINT:case OP_PRINT_STR:case OP_FPRINT:return x->dst==r;case OP_POP:return 0;case OP_LOAD: return x->src==r;case OP_STORE:return x->dst==r||x->src==r;case OP_BIT_GET:return x->src==r;default:return 0;}}
static int twouse(const Ins*x,int r){switch(x->op){case OP_ADD:case OP_SUB:case OP_MUL:case OP_DIV:case OP_MOD:case OP_AND:case OP_OR:case OP_XOR:case OP_SHL:case OP_SHR:case OP_FADD:case OP_FSUB:case OP_FMUL:case OP_FDIV:return x->dst==r||x->src==r;case OP_CMP:case OP_FCMP:return x->dst==r||x->src==r;default:return 0;}}
static void add_pred(int b,int p){if(blocks[b].npred>=64)die("too many predecessors");blocks[b].pred[blocks[b].npred++]=p;}
static void build_cfg(void){
    unsigned char *leader=calloc(n,1); if(!leader)die("oom"); leader[0]=1;
    for(size_t i=0;i<n;i++){int t=target(&code[i]);if(t>=0&&t<(int)n){leader[t]=1;if(i+1<n)leader[i+1]=1;}}
    for(size_t i=0;i<n;i++)if(leader[i]){if(nb>=MAX_B)die("too many blocks");blocks[nb].start=(int)i;bmap[i]=nb++;}
    memset(blocks,0,sizeof(blocks));
    nb=0; memset(bmap,0xff,sizeof(bmap));
    for(size_t i=0;i<n;i++)if(leader[i]){blocks[nb].start=(int)i;bmap[i]=nb++;}
    free(leader);
    for(int b=0;b<nb;b++)blocks[b].end=(b+1<nb?blocks[b+1].start:(int)n)-1;
    for(int b=0;b<nb;b++){
        Ins*x=&code[blocks[b].end]; int t=target(x);
        if(t>=0){int tb=bmap[t];blocks[b].succ[blocks[b].nsucc++]=tb;add_pred(tb,b);if(x->op!=OP_JMP&&b+1<nb){blocks[b].succ[blocks[b].nsucc++]=b+1;add_pred(b+1,b);}}
        else if(!nofall(x)&&b+1<nb){blocks[b].succ[blocks[b].nsucc++]=b+1;add_pred(b+1,b);}
    }
}
static void compute_dom(void){
    size_t w=WORDS(nb); dom=calloc((size_t)nb*w,8); if(!dom)die("oom");
    for(int b=0;b<nb;b++){if(b==0)bit_set(dom+b*w,0);else for(size_t j=0;j<w;j++)dom[b*w+j]=~0ULL;}
    for(int b=0;b<nb;b++) if(nb%64 && b!=0) dom[b*w+w-1]&=((1ULL<<(nb%64))-1);
    int changed=1; while(changed){changed=0;for(int b=1;b<nb;b++){
        uint64_t tmp[MAX_B/64+1]; if(w>MAX_B/64+1)die("dom words overflow"); for(size_t j=0;j<w;j++)tmp[j]=~0ULL;
        if(nb%64)tmp[w-1]&=((1ULL<<(nb%64))-1);
        if(!blocks[b].npred) memset(tmp,0,w*8); else for(int p=0;p<blocks[b].npred;p++)bit_and(tmp,dom+blocks[b].pred[p]*w,w);
        bit_set(tmp,b); if(!bit_equal(tmp,dom+b*w,w)){bit_copy(dom+b*w,tmp,w);changed=1;}
    }}
    idom=calloc(nb,sizeof(int)); if(!idom)die("oom"); for(int b=0;b<nb;b++)idom[b]=-1; idom[0]=-1;
    for(int b=1;b<nb;b++){int best=-1,bestc=-1;for(int d=0;d<nb;d++)if(d!=b&&bit_get(dom+b*w,d)){int c=popcount_bits(dom+d*w,w);if(c>bestc){bestc=c;best=d;}}idom[b]=best;}
}
static void compute_df(void){
    size_t w=WORDS(nb); df=calloc((size_t)nb*w,8); if(!df)die("oom");
    for(int b=0;b<nb;b++){
        if(blocks[b].npred>=2)for(int pi=0;pi<blocks[b].npred;pi++){int r=blocks[b].pred[pi];while(r>=0&&r!=idom[b]){bit_set(df+r*w,b);r=idom[r];}}
    }
}
static void place_phis(void){
    phis=calloc((size_t)nb*MAX_REG,sizeof(*phis)); if(!phis)die("oom");
    for(int r=0;r<MAX_REG;r++){
        unsigned char *has=calloc(nb,1),*inwork=calloc(nb,1);int *work=malloc(nb*sizeof(int));if(!has||!inwork||!work)die("oom");int wn=0;
        for(int b=0;b<nb;b++)for(int i=blocks[b].start;i<=blocks[b].end;i++)if(defines(&code[i],r)){work[wn++]=b;break;}
        while(wn){int x=work[--wn];for(int y=0;y<nb;y++)if(bit_get(df+x*WORDS(nb),y)&&!has[y]){has[y]=1;Phi*p=&phis[y*MAX_REG+r];p->has=1;p->orig=r;p->narg=blocks[y].npred;if(p->narg>64)die("phi arg overflow");if(!inwork[y]){inwork[y]=1;work[wn++]=y;}}}
        free(has);free(inwork);free(work);
    }
}
static void domtree_build(void){
    dom_child_start=calloc(nb,sizeof(int));dom_child_next=calloc(nb,sizeof(int));int *tail=calloc(nb,sizeof(int));if(!dom_child_start||!dom_child_next||!tail)die("oom");for(int i=0;i<nb;i++)dom_child_start[i]=-1;
    for(int b=1;b<nb;b++){int p=idom[b];dom_child_next[b]=dom_child_start[p];dom_child_start[p]=b;}
    free(tail);
}
static int curver(int r){return stack_n[r]?stacks[r][stack_n[r]-1]:0;}
static int newver(int r){int v=++next_version[r];stacks[r][stack_n[r]++]=v;return v;}
static void rename_block(int b){
    int pushed[MAX_REG]={0};
    for(int r=0;r<MAX_REG;r++)if(phis[b*MAX_REG+r].has){int v=newver(r);phis[b*MAX_REG+r].version=v;pushed[r]++;}
    for(int i=blocks[b].start;i<=blocks[b].end;i++){
        Ins*x=&code[i];
        if(twouse(x,x->dst)){fprintf(stdout,"  %%r%d = op%d %%r%d.%d, %%r%d.%d\n",x->dst,x->op,x->dst,curver(x->dst),x->src,curver(x->src));int v=newver(x->dst);fprintf(stdout,"    ; def %%r%d.%d\n",x->dst,v);pushed[x->dst]++;continue;}
        if(uses_reg(x,x->src)){
            if(defines(x,x->dst)){int dv=curver(x->dst),sv=curver(x->src);fprintf(stdout,"  %%r%d.%d = op%d %%r%d.%d\n",x->dst,dv,x->op,x->src,sv);int v=newver(x->dst);fprintf(stdout,"    ; def %%r%d.%d\n",x->dst,v);pushed[x->dst]++;}
            else fprintf(stdout,"  op%d %%r%d.%d\n",x->op,x->src,curver(x->src));
        }else if(defines(x,x->dst)){
            int v=newver(x->dst);fprintf(stdout,"  %%r%d.%d = op%d\n",x->dst,v,x->op);pushed[x->dst]++;
        }else if(x->op==OP_MOVI||x->op==OP_FMOVI){int v=newver(x->dst);fprintf(stdout,"  %%r%d.%d = const %llu\n",x->dst,v,(unsigned long long)x->imm);pushed[x->dst]++;}
        else fprintf(stdout,"  op%d\n",x->op);
    }
    for(int s=0;s<blocks[b].nsucc;s++){
        int y=blocks[b].succ[s];int pi=-1;for(int k=0;k<blocks[y].npred;k++)if(blocks[y].pred[k]==b){pi=k;break;}
        for(int r=0;r<MAX_REG;r++)if(phis[y*MAX_REG+r].has)phis[y*MAX_REG+r].arg[pi]=curver(r);
    }
    for(int child=dom_child_start[b];child>=0;child=dom_child_next[child])rename_block(child);
    for(int r=0;r<MAX_REG;r++)while(pushed[r]--)--stack_n[r];
}
int main(int argc,char**argv){
    if(argc<2){fprintf(stderr,"usage: asmthon-ssa program.avm\n");return 2;}
    FILE*f=fopen(argv[1],"rb");if(!f)die("cannot open input");unsigned char h[16];if(fread(h,1,16,f)!=16)die("short header");if(memcmp(h,"ASMV",4)!=0)die("bad magic");uint32_t ver;memcpy(&ver,h+4,4);if(ver!=3)die("unsupported bytecode version");memcpy(&n,h+8,8);if(n>MAX_CODE)die("too many instructions");if(fread(code,sizeof(Ins),n,f)!=n)die("short code");fclose(f);
    build_cfg();compute_dom();compute_df();place_phis();domtree_build();
    printf("; SSA for %zu instructions, %d blocks\n",n,nb);
    for(int b=0;b<nb;b++){
        printf("B%d (idom=%d)",b,idom[b]);if(blocks[b].npred){printf(" pred=");for(int i=0;i<blocks[b].npred;i++)printf("B%d%s",blocks[b].pred[i],i+1<blocks[b].npred?",":"");}printf("\n");
        for(int r=0;r<MAX_REG;r++)if(phis[b*MAX_REG+r].has)printf("  phi %%r%d = (pending)\n",r);
    }
    puts("\n; Renamed SSA");rename_block(0);
    for(int b=0;b<nb;b++)for(int r=0;r<MAX_REG;r++)if(phis[b*MAX_REG+r].has){printf("; B%d phi %%r%d.%d <-",b,r,phis[b*MAX_REG+r].version);for(int i=0;i<phis[b*MAX_REG+r].narg;i++)printf(" %%r%d.%d",r,phis[b*MAX_REG+r].arg[i]);puts("");}
    free(dom);free(df);free(idom);free(phis);free(dom_child_start);free(dom_child_next);return 0;
}
